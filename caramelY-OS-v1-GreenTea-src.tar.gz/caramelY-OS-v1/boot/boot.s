/* boot.s — CaramelUK OS v7.5 "Honeycomb"
 * Multiboot1, строго по спецификации:
 * FLAGS=0x3 (bit0=align, bit1=memmap) — БЕЗ bit2 video
 * VBE запрашивается через GRUB grub.cfg, не через multiboot header
 * Это самый надёжный способ — грузится на любом железе/QEMU
 */
.set MAGIC,    0x1BADB002
.set FLAGS,    0x00000003   /* align + memmap ТОЛЬКО — без video request */
.set CHECKSUM, -(MAGIC + FLAGS)

.section .multiboot
.align 4
.long MAGIC
.long FLAGS
.long CHECKSUM

/* Stack 32KB */
.section .bss
.align 16
stack_bottom:
.skip 32768
stack_top:

.section .text
.global _start
.type _start, @function
_start:
    mov $stack_top, %esp
    push $0
    popf
    push %ebx       /* multiboot info ptr */
    push %eax       /* multiboot magic */
    call kernel_main
    cli
.Lhalt:
    hlt
    jmp .Lhalt

.global gdt_flush
gdt_flush:
    mov 4(%esp), %eax
    lgdt (%eax)
    mov $0x10, %ax
    mov %ax, %ds
    mov %ax, %es
    mov %ax, %fs
    mov %ax, %gs
    mov %ax, %ss
    ljmp $0x08, $.Lgdt2
.Lgdt2: ret

.global idt_flush
idt_flush:
    mov 4(%esp), %eax
    lidt (%eax)
    ret

.global context_switch
context_switch:
    mov 4(%esp), %eax
    mov %edi,  0(%eax); mov %esi,  4(%eax); mov %ebp,  8(%eax)
    mov %esp, 12(%eax); mov %ebx, 16(%eax); mov %edx, 20(%eax)
    mov %ecx, 24(%eax); movl $0, 28(%eax)
    mov (%esp), %ecx;   mov %ecx, 32(%eax)
    pushfl; pop %ecx;   mov %ecx, 36(%eax)
    mov 8(%esp), %eax
    mov 36(%eax), %ecx; push %ecx; popfl
    mov  0(%eax), %edi; mov  4(%eax), %esi; mov  8(%eax), %ebp
    mov 16(%eax), %ebx; mov 20(%eax), %edx; mov 24(%eax), %ecx
    mov 12(%eax), %esp
    mov 32(%eax), %eax; push %eax; ret

.macro ISR_NOERRCODE num
.global isr\num
isr\num: cli; push $0; push $\num; jmp isr_common_stub
.endm
.macro ISR_ERRCODE num
.global isr\num
isr\num: cli; push $\num; jmp isr_common_stub
.endm
.macro IRQ num idt_num
.global irq\num
irq\num: cli; push $0; push $\idt_num; jmp irq_common_stub
.endm

ISR_NOERRCODE 0;  ISR_NOERRCODE 1;  ISR_NOERRCODE 2;  ISR_NOERRCODE 3
ISR_NOERRCODE 4;  ISR_NOERRCODE 5;  ISR_NOERRCODE 6;  ISR_NOERRCODE 7
ISR_ERRCODE   8;  ISR_NOERRCODE 9;  ISR_ERRCODE  10;  ISR_ERRCODE  11
ISR_ERRCODE  12;  ISR_ERRCODE  13;  ISR_ERRCODE  14;  ISR_NOERRCODE 15
ISR_NOERRCODE 16; ISR_NOERRCODE 17; ISR_NOERRCODE 18; ISR_NOERRCODE 19
ISR_NOERRCODE 20; ISR_NOERRCODE 21; ISR_NOERRCODE 22; ISR_NOERRCODE 23
ISR_NOERRCODE 24; ISR_NOERRCODE 25; ISR_NOERRCODE 26; ISR_NOERRCODE 27
ISR_NOERRCODE 28; ISR_NOERRCODE 29; ISR_NOERRCODE 30; ISR_NOERRCODE 31

.global isr128
isr128: cli; push $0; push $128; jmp isr_common_stub

IRQ 0,32;  IRQ 1,33;  IRQ 2,34;  IRQ 3,35;  IRQ 4,36;  IRQ 5,37
IRQ 6,38;  IRQ 7,39;  IRQ 8,40;  IRQ 9,41;  IRQ 10,42; IRQ 11,43
IRQ 12,44; IRQ 13,45; IRQ 14,46; IRQ 15,47

.extern isr_handler
isr_common_stub:
    pusha; mov %ds,%ax; push %eax
    mov $0x10,%ax; mov %ax,%ds; mov %ax,%es; mov %ax,%fs; mov %ax,%gs
    call isr_handler
    pop %eax; mov %ax,%ds; mov %ax,%es; mov %ax,%fs; mov %ax,%gs
    popa; add $8,%esp; sti; iret

.extern irq_handler
irq_common_stub:
    pusha; mov %ds,%ax; push %eax
    mov $0x10,%ax; mov %ax,%ds; mov %ax,%es; mov %ax,%fs; mov %ax,%gs
    call irq_handler
    pop %eax; mov %ax,%ds; mov %ax,%es; mov %ax,%fs; mov %ax,%gs
    popa; add $8,%esp; sti; iret

.section .note.GNU-stack,"",@progbits
