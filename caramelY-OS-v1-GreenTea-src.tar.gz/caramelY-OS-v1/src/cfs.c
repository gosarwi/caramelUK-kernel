/* cfs.c — CaramelFS: persistent flat-block filesystem for CaramelUK v4 */
#include "cfs.h"
#include "disk.h"
#include "kmalloc.h"
#include "util.h"
#include <stdint.h>
#include <stddef.h>

cfs_state_t cfs = {0};

/* Sector layout constants */
#define SB_LBA          0
#define INODE_LBA       1          /* sectors 1..8 (8 sectors = 128 inodes × 32B) */
#define BITMAP_LBA      9          /* sector 9 (512 bytes = 4096 bits) */
#define DATA_LBA        16         /* sectors 16+ = data blocks */

/* ── Bitmap helpers ───────────────────────────────────────── */
static int  bm_test(uint32_t b){ return (cfs.bitmap[b/8] >> (b%8)) & 1; }
static void bm_set (uint32_t b){ cfs.bitmap[b/8] |=  (1u << (b%8)); }
static void bm_clr (uint32_t b){ cfs.bitmap[b/8] &= ~(1u << (b%8)); }

static int bm_alloc(void) {
    for (uint32_t i = 0; i < CFS_BLOCKS_MAX; i++)
        if (!bm_test(i)) { bm_set(i); return (int)i; }
    return -1;
}

/* LBA of a data block index */
static uint32_t block_lba(uint32_t blk) { return DATA_LBA + blk; }

/* ── Sync to disk ─────────────────────────────────────────── */
int cfs_sync(void) {
    if (!cfs.mounted) return -1;
    int d = cfs.disk_drive;

    /* Superblock */
    uint8_t sec[SECTOR_SIZE];
    kmemset(sec, 0, SECTOR_SIZE);
    kmemcpy(sec, &cfs.sb, sizeof(cfs_super_t));
    if (disk_write_sector(d, SB_LBA, sec) < 0) return -1;

    /* Inode table: 128 inodes × 32 bytes = 4096 bytes = 8 sectors */
    for (int s = 0; s < 8; s++) {
        kmemset(sec, 0, SECTOR_SIZE);
        /* 16 inodes per sector (16 × 32 = 512) */
        kmemcpy(sec, &cfs.inodes[s * 16], 16 * sizeof(cfs_inode_t));
        if (disk_write_sector(d, (uint32_t)(INODE_LBA + s), sec) < 0) return -1;
    }

    /* Bitmap */
    kmemset(sec, 0, SECTOR_SIZE);
    kmemcpy(sec, cfs.bitmap, sizeof(cfs.bitmap));
    if (disk_write_sector(d, BITMAP_LBA, sec) < 0) return -1;

    return 0;
}

/* ── Format ───────────────────────────────────────────────── */
int cfs_format(int drive, const char *label) {
    if (drive < 0 || !disk_drives[drive].present) return -1;

    kmemset(&cfs, 0, sizeof(cfs));
    cfs.disk_drive = drive;

    /* Superblock */
    cfs.sb.magic           = CFS_MAGIC;
    cfs.sb.version         = 1;
    cfs.sb.total_blocks    = CFS_BLOCKS_MAX;
    cfs.sb.free_blocks     = CFS_BLOCKS_MAX;
    cfs.sb.inode_count     = CFS_INODE_MAX;
    cfs.sb.free_inodes     = CFS_INODE_MAX;
    cfs.sb.data_start_lba  = DATA_LBA;
    cfs.sb.bitmap_lba      = BITMAP_LBA;
    cfs.sb.inode_table_lba = INODE_LBA;
    kstrcpy(cfs.sb.label, label ? label : "caramelfs");

    /* Root inode (index 0) */
    cfs_inode_t *root = &cfs.inodes[0];
    kstrcpy(root->name, "/");
    root->type   = CFS_TYPE_DIR;
    root->perms  = 0x7;
    root->size   = 0;
    root->parent = -1;
    cfs.sb.free_inodes--;

    cfs.mounted = 1;
    return cfs_sync();
}

/* ── Mount ────────────────────────────────────────────────── */
int cfs_mount(int drive) {
    if (drive < 0 || !disk_drives[drive].present) return -1;

    uint8_t sec[SECTOR_SIZE];
    if (disk_read_sector(drive, SB_LBA, sec) < 0) return -1;
    kmemcpy(&cfs.sb, sec, sizeof(cfs_super_t));

    if (cfs.sb.magic != CFS_MAGIC) return -1;  /* not formatted */

    /* Load inode table */
    for (int s = 0; s < 8; s++) {
        if (disk_read_sector(drive, (uint32_t)(INODE_LBA + s), sec) < 0) return -1;
        kmemcpy(&cfs.inodes[s * 16], sec, 16 * sizeof(cfs_inode_t));
    }

    /* Load bitmap */
    if (disk_read_sector(drive, BITMAP_LBA, sec) < 0) return -1;
    kmemcpy(cfs.bitmap, sec, sizeof(cfs.bitmap));

    cfs.disk_drive = drive;
    cfs.mounted    = 1;
    return 0;
}

/* ── Path helpers ─────────────────────────────────────────── */
static void split_last(const char *path, char *dir, char *base) {
    const char *last = path;
    for (const char *p = path; *p; p++) if (*p == '/') last = p;
    if (last == path) {
        kstrcpy(dir, "/"); kstrcpy(base, path + 1);
    } else {
        size_t n = (size_t)(last - path);
        kmemcpy(dir, path, n); dir[n] = 0;
        kstrcpy(base, last + 1);
    }
}

/* Find inode by path (walk from root) */
int cfs_lookup(const char *path) {
    if (!cfs.mounted) return -1;
    if (path[0] == '/' && path[1] == 0) return 0; /* root */

    /* Find root first */
    int cur = 0;
    if (cfs.inodes[0].type != CFS_TYPE_DIR) return -1;

    /* Walk components */
    char comp[CFS_NAME_MAX];
    const char *p = (path[0] == '/') ? path + 1 : path;

    while (*p) {
        int ci = 0;
        while (*p && *p != '/') comp[ci++] = *p++;
        comp[ci] = 0;
        if (*p == '/') p++;
        if (ci == 0) continue;

        /* Find child named comp in cur dir */
        int found = -1;
        for (int i = 1; i < CFS_INODE_MAX; i++) {
            if (cfs.inodes[i].type == CFS_TYPE_FREE) continue;
            if (cfs.inodes[i].parent == cur &&
                kstrcmp(cfs.inodes[i].name, comp) == 0) {
                found = i; break;
            }
        }
        if (found < 0) return -1;
        cur = found;
    }
    return cur;
}

int cfs_create(const char *path, uint8_t type) {
    if (!cfs.mounted) return -1;

    /* Get parent */
    char dir[64], base[CFS_NAME_MAX];
    split_last(path, dir, base);
    int parent = cfs_lookup(dir);
    if (parent < 0) return -1;
    if (cfs_lookup(path) >= 0) return -1; /* already exists */

    /* Find free inode */
    for (int i = 1; i < CFS_INODE_MAX; i++) {
        if (cfs.inodes[i].type == CFS_TYPE_FREE) {
            kmemset(&cfs.inodes[i], 0, sizeof(cfs_inode_t));
            kstrcpy(cfs.inodes[i].name, base);
            cfs.inodes[i].type   = type;
            cfs.inodes[i].perms  = 0x6;
            cfs.inodes[i].parent = parent;
            cfs.sb.free_inodes--;
            cfs_sync();
            return i;
        }
    }
    return -1; /* no free inodes */
}

int cfs_unlink(int idx) {
    if (!cfs.mounted || idx <= 0 || idx >= CFS_INODE_MAX) return -1;
    cfs_inode_t *in = &cfs.inodes[idx];
    if (in->type == CFS_TYPE_FREE) return -1;

    /* Free data blocks */
    for (int i = 0; i < CFS_DIRECT_BLOCKS; i++) {
        if (in->blocks[i]) { bm_clr(in->blocks[i]); cfs.sb.free_blocks++; }
    }
    kmemset(in, 0, sizeof(cfs_inode_t));
    cfs.sb.free_inodes++;
    cfs_sync();
    return 0;
}

int cfs_read(int idx, uint32_t offset, uint8_t *buf, uint32_t len) {
    if (!cfs.mounted || idx < 0 || idx >= CFS_INODE_MAX) return -1;
    cfs_inode_t *in = &cfs.inodes[idx];
    if (in->type == CFS_TYPE_FREE) return -1;
    if (offset >= in->size) return 0;
    if (offset + len > in->size) len = in->size - offset;

    uint32_t read = 0;
    uint8_t  tmp[SECTOR_SIZE];

    while (read < len) {
        uint32_t blk_i  = (offset + read) / CFS_BLOCK_SIZE;
        uint32_t blk_off = (offset + read) % CFS_BLOCK_SIZE;
        if (blk_i >= CFS_DIRECT_BLOCKS || !in->blocks[blk_i]) break;

        disk_read_sector(cfs.disk_drive, block_lba(in->blocks[blk_i]), tmp);

        uint32_t avail = CFS_BLOCK_SIZE - blk_off;
        uint32_t chunk = len - read;
        if (chunk > avail) chunk = avail;
        kmemcpy(buf + read, tmp + blk_off, chunk);
        read += chunk;
    }
    return (int)read;
}

int cfs_write(int idx, uint32_t offset, const uint8_t *buf, uint32_t len) {
    if (!cfs.mounted || idx < 0 || idx >= CFS_INODE_MAX) return -1;
    cfs_inode_t *in = &cfs.inodes[idx];
    if (in->type == CFS_TYPE_FREE || in->type == CFS_TYPE_DIR) return -1;

    uint32_t written = 0;
    uint8_t  tmp[SECTOR_SIZE];

    while (written < len) {
        uint32_t blk_i  = (offset + written) / CFS_BLOCK_SIZE;
        uint32_t blk_off = (offset + written) % CFS_BLOCK_SIZE;

        if (blk_i >= CFS_DIRECT_BLOCKS) break; /* file too big */

        /* Allocate block if needed */
        if (!in->blocks[blk_i]) {
            int nb = bm_alloc();
            if (nb < 0) break;
            in->blocks[blk_i] = (uint32_t)nb;
            cfs.sb.free_blocks--;
            kmemset(tmp, 0, SECTOR_SIZE);
        } else {
            disk_read_sector(cfs.disk_drive,
                             block_lba(in->blocks[blk_i]), tmp);
        }

        uint32_t avail = CFS_BLOCK_SIZE - blk_off;
        uint32_t chunk = len - written;
        if (chunk > avail) chunk = avail;
        kmemcpy(tmp + blk_off, buf + written, chunk);
        disk_write_sector(cfs.disk_drive, block_lba(in->blocks[blk_i]), tmp);
        written += chunk;
    }

    uint32_t end = offset + written;
    if (end > in->size) in->size = end;
    cfs_sync();
    return (int)written;
}

int cfs_listdir(int dir_idx, char names[][CFS_NAME_MAX], int *count) {
    if (!cfs.mounted) return -1;
    *count = 0;
    for (int i = 0; i < CFS_INODE_MAX; i++) {
        if (cfs.inodes[i].type == CFS_TYPE_FREE) continue;
        if (cfs.inodes[i].parent != dir_idx) continue;
        kstrcpy(names[*count], cfs.inodes[i].name);
        if (cfs.inodes[i].type == CFS_TYPE_DIR)
            kstrcat(names[*count], "/");
        (*count)++;
    }
    return 0;
}

/* High-level path API */
int cfs_path_read(const char *path, uint32_t off, uint8_t *buf, uint32_t len) {
    int idx = cfs_lookup(path);
    if (idx < 0) return -1;
    return cfs_read(idx, off, buf, len);
}

int cfs_path_write(const char *path, uint32_t off, const uint8_t *buf, uint32_t len) {
    int idx = cfs_lookup(path);
    if (idx < 0) idx = cfs_create(path, CFS_TYPE_FILE);
    if (idx < 0) return -1;
    return cfs_write(idx, off, buf, len);
}

int cfs_path_create(const char *path) { return cfs_create(path, CFS_TYPE_FILE); }
int cfs_path_mkdir (const char *path) { return cfs_create(path, CFS_TYPE_DIR);  }
int cfs_path_unlink(const char *path) {
    int idx = cfs_lookup(path);
    return cfs_unlink(idx);
}
int cfs_path_size(const char *path) {
    int idx = cfs_lookup(path);
    if (idx < 0) return -1;
    return (int)cfs.inodes[idx].size;
}

