#ifndef STORE_H
#define STORE_H
/* store.h — Caramel Store v1.0 — CaramelUK v8 */
#include <stdint.h>
void store_run(void);
#endif
