/*  net.c — RTL8139 NIC driver for CaramelUK OS v3
 *
 *  Detects RTL8139 via PCI config space scan (vendor=0x10EC, dev=0x8139).
 *  Initializes TX/RX, handles basic Ethernet framing.
 *  Supports: raw send/recv, ARP request, static IP config.
 *
 *  QEMU emulates RTL8139 with: -netdev user,id=n0 -device rtl8139,netdev=n0
 */
#include "net.h"
#include "kmalloc.h"
#include "util.h"
#include "vga.h"
#include "idt.h"
#include <stdint.h>
#include <stddef.h>

net_state_t net = {0};

/* ── Port I/O helpers ─────────────────────────────────────── */
/* ── PCI config helpers ───────────────────────────────────── */
#define PCI_CONFIG_ADDR  0xCF8
#define PCI_CONFIG_DATA  0xCFC

static uint32_t pci_read(uint8_t bus, uint8_t dev, uint8_t fn, uint8_t reg) {
    uint32_t addr = (1u<<31) | ((uint32_t)bus<<16) |
                    ((uint32_t)(dev&0x1F)<<11) |
                    ((uint32_t)(fn&0x07)<<8)   |
                    (reg & 0xFC);
    outl(PCI_CONFIG_ADDR, addr);
    return inl(PCI_CONFIG_DATA);
}

static void pci_write(uint8_t bus, uint8_t dev, uint8_t fn, uint8_t reg, uint32_t val) {
    uint32_t addr = (1u<<31) | ((uint32_t)bus<<16) |
                    ((uint32_t)(dev&0x1F)<<11) |
                    ((uint32_t)(fn&0x07)<<8)   |
                    (reg & 0xFC);
    outl(PCI_CONFIG_ADDR, addr);
    outl(PCI_CONFIG_DATA, val);
}

#define RTL_VENDOR  0x10EC
#define RTL_DEVID   0x8139

/* Scan PCI bus 0 for RTL8139, return I/O base or 0 */
static uint16_t pci_find_rtl8139(void) {
    for (uint8_t dev = 0; dev < 32; dev++) {
        uint32_t id = pci_read(0, dev, 0, 0x00);
        if ((id & 0xFFFF) == RTL_VENDOR &&
            ((id >> 16) & 0xFFFF) == RTL_DEVID) {
            /* Enable bus master + I/O space */
            uint32_t cmd = pci_read(0, dev, 0, 0x04);
            cmd |= 0x05;
            pci_write(0, dev, 0, 0x04, cmd);
            /* BAR0 = I/O base */
            uint32_t bar0 = pci_read(0, dev, 0, 0x10);
            return (uint16_t)(bar0 & ~0x3);
        }
    }
    return 0;
}

/* ── RTL8139 init ─────────────────────────────────────────── */
int net_init(void) {
    uint16_t io = pci_find_rtl8139();
    if (!io) return -1;   /* no RTL8139 found */

    net.io_base = io;

    /* Power on */
    outb(io + RTL_CONFIG1, 0x00);

    /* Software reset */
    outb(io + RTL_CR, RTL_CR_RESET);
    int timeout = 10000;
    while ((inb(io + RTL_CR) & RTL_CR_RESET) && --timeout) {
        __asm__ volatile("pause");
    }
    if (!timeout) return -2;

    /* Read MAC */
    for (int i = 0; i < ETH_ALEN; i++)
        net.mac[i] = inb(io + RTL_MAC0 + i);

    /* Allocate RX ring buffer */
    net.rx_buf = (uint8_t *)kmalloc(RTL_RX_BUF_SIZE);
    if (!net.rx_buf) return -3;
    kmemset(net.rx_buf, 0, RTL_RX_BUF_SIZE);

    /* Allocate TX buffers */
    for (int i = 0; i < RTL_TX_BUFS; i++) {
        net.tx_bufs[i] = (uint8_t *)kmalloc(RTL_TX_BUF_SIZE);
        if (!net.tx_bufs[i]) return -4;
    }
    net.tx_cur = 0;
    net.rx_read_ptr = 0;

    /* Set RX buffer address */
    outl(io + RTL_RBSTART, (uint32_t)(uintptr_t)net.rx_buf);

    /* TX buffer addresses */
    for (int i = 0; i < RTL_TX_BUFS; i++)
        outl(io + RTL_TSAD0 + i*4, (uint32_t)(uintptr_t)net.tx_bufs[i]);

    /* Enable interrupts: ROK + TOK + RER + TER */
    outw(io + RTL_IMR, RTL_INT_ROK | RTL_INT_TOK |
                       RTL_INT_RER | RTL_INT_TER);

    /* RX config: accept broadcast + multicast + physical */
    outl(io + RTL_RCR,
         RTL_RCR_AB | RTL_RCR_AM | RTL_RCR_APM |
         RTL_RCR_MXDMA | RTL_RCR_WRAP | RTL_RCR_RBLEN8K);

    /* TX config */
    outl(io + RTL_TCR, 0x03000700);

    /* Enable RX + TX */
    outb(io + RTL_CR, RTL_CR_RE | RTL_CR_TE);

    /* Install IRQ handler (IRQ 11 → INT 43 after PIC remap) */
    irq_install_handler(11, (irq_handler_t)net_irq_handler);

    net.initialized = 1;
    return 0;
}

/* ── Send ─────────────────────────────────────────────────── */
int net_send(const uint8_t *buf, uint16_t len) {
    if (!net.initialized || len > RTL_TX_BUF_SIZE) return -1;
    if (len < ETH_MIN) len = ETH_MIN;

    uint16_t io = net.io_base;
    int cur = net.tx_cur;

    /* Copy to TX buffer */
    for (int i = 0; i < len; i++)
        net.tx_bufs[cur][i] = buf[i];

    /* Wait for TX idle */
    int timeout = 100000;
    while (!(inl(io + RTL_TSD0 + cur*4) & (1<<13)) && --timeout)
        __asm__ volatile("pause");

    /* Set length and start TX */
    outl(io + RTL_TSD0 + cur*4, (uint32_t)len);

    net.tx_cur = (cur + 1) & (RTL_TX_BUFS - 1);
    net.tx_packets++;
    net.tx_bytes += len;
    return 0;
}

/* ── Receive (non-blocking poll) ─────────────────────────── */
int net_recv(uint8_t *buf, uint16_t maxlen) {
    if (!net.initialized) return 0;
    uint16_t io = net.io_base;

    /* Check if buffer empty */
    if (inb(io + RTL_CR) & RTL_CR_BUFE) return 0;

    /* Read packet from RX ring */
    uint32_t rptr = net.rx_read_ptr;
    uint8_t  status_lo = net.rx_buf[rptr % RTL_RX_BUF_SIZE];
    uint8_t  status_hi = net.rx_buf[(rptr+1) % RTL_RX_BUF_SIZE];
    uint16_t pkt_len = (uint16_t)(
        net.rx_buf[(rptr+2) % RTL_RX_BUF_SIZE] |
        ((uint16_t)net.rx_buf[(rptr+3) % RTL_RX_BUF_SIZE] << 8)
    );

    (void)status_lo; (void)status_hi;

    if (pkt_len == 0 || pkt_len > maxlen) {
        /* advance past bad packet */
        net.rx_read_ptr = (rptr + 4 + pkt_len + 3) & ~3;
        outw(io + RTL_CAPR, (uint16_t)(net.rx_read_ptr - 16));
        return 0;
    }

    /* Copy payload */
    for (uint16_t i = 0; i < pkt_len; i++)
        buf[i] = net.rx_buf[(rptr + 4 + i) % RTL_RX_BUF_SIZE];

    /* Advance read pointer (aligned to 4 bytes) */
    net.rx_read_ptr = (rptr + 4 + pkt_len + 3) & ~3;
    outw(io + RTL_CAPR, (uint16_t)(net.rx_read_ptr - 16));

    net.rx_packets++;
    net.rx_bytes += pkt_len;
    return (int)pkt_len;
}

/* ── IRQ handler ──────────────────────────────────────────── */
void net_irq_handler(void *regs) {
    (void)regs;
    if (!net.initialized) return;
    uint16_t io = net.io_base;
    uint16_t isr = inw(io + RTL_ISR);
    /* Acknowledge */
    outw(io + RTL_ISR, isr);
    /* RX OK: packets handled via polling (net_recv) */
}

/* ── ARP request ──────────────────────────────────────────── */
void net_arp_request(uint8_t target_ip[4]) {
    uint8_t frame[ETH_HLEN + sizeof(arp_packet_t)];
    eth_header_t *eth = (eth_header_t *)frame;
    arp_packet_t *arp = (arp_packet_t *)(frame + ETH_HLEN);

    /* Broadcast destination */
    for (int i = 0; i < ETH_ALEN; i++) {
        eth->dst[i] = 0xFF;
        eth->src[i] = net.mac[i];
    }
    eth->ethertype = 0x0608; /* 0x0806 big-endian swap */

    arp->htype     = 0x0100; /* Ethernet BE */
    arp->ptype     = 0x0008; /* IPv4 BE */
    arp->hlen      = 6;
    arp->plen      = 4;
    arp->operation = 0x0100; /* request BE */
    for (int i = 0; i < 6; i++) arp->sha[i] = net.mac[i];
    for (int i = 0; i < 4; i++) arp->spa[i] = net.ip[i];
    for (int i = 0; i < 6; i++) arp->tha[i] = 0;
    for (int i = 0; i < 4; i++) arp->tpa[i] = target_ip[i];

    net_send(frame, sizeof(frame));
}

/* ── Static IP ────────────────────────────────────────────── */
void net_set_ip(uint8_t a, uint8_t b, uint8_t c, uint8_t d) {
    net.ip[0] = a; net.ip[1] = b;
    net.ip[2] = c; net.ip[3] = d;
}

/* ── Info / stats ─────────────────────────────────────────── */
static char mac_buf[20];
const char *net_mac_str(void) {
    uint8_t *m = net.mac;
    /* format: XX:XX:XX:XX:XX:XX */
    const char *hex = "0123456789ABCDEF";
    for (int i = 0; i < 6; i++) {
        mac_buf[i*3]   = hex[m[i] >> 4];
        mac_buf[i*3+1] = hex[m[i] & 0xF];
        mac_buf[i*3+2] = (i < 5) ? ':' : 0;
    }
    mac_buf[17] = 0;
    return mac_buf;
}

void net_print_info(void) {
    char buf[16];
    if (!net.initialized) {
        terminal_writeln("  eth0: No RTL8139 detected");
        terminal_writeln("  (Use QEMU: -netdev user,id=n0 -device rtl8139,netdev=n0)");
        return;
    }
    terminal_write("  eth0:  MAC="); terminal_writeln(net_mac_str());
    terminal_write("  IO:    0x");
    kuitoa(net.io_base, buf, 16); terminal_writeln(buf);
    terminal_write("  IP:    ");
    if (net.ip[0]) {
        kuitoa(net.ip[0],buf,10); terminal_write(buf); terminal_write(".");
        kuitoa(net.ip[1],buf,10); terminal_write(buf); terminal_write(".");
        kuitoa(net.ip[2],buf,10); terminal_write(buf); terminal_write(".");
        kuitoa(net.ip[3],buf,10); terminal_writeln(buf);
    } else {
        terminal_writeln("not configured (use 'ifconfig eth0 <ip>')");
    }
}

void net_print_stats(void) {
    char buf[24];
    terminal_writeln("=== Network Statistics ===");
    terminal_write("  RX packets: "); kuitoa((uint32_t)net.rx_packets, buf, 10); terminal_writeln(buf);
    terminal_write("  TX packets: "); kuitoa((uint32_t)net.tx_packets, buf, 10); terminal_writeln(buf);
    terminal_write("  RX bytes:   "); kuitoa((uint32_t)net.rx_bytes,   buf, 10); terminal_writeln(buf);
    terminal_write("  TX bytes:   "); kuitoa((uint32_t)net.tx_bytes,   buf, 10); terminal_writeln(buf);
}
