/* disk.c — ATA PIO disk driver for CaramelUK OS v4
 *
 *  Detects up to 4 ATA drives (primary/secondary × master/slave).
 *  Uses LBA28 PIO mode — no DMA, but universal compatibility with QEMU.
 *  QEMU default: -hda disk.img creates a primary-master ATA drive.
 */
#include "disk.h"
#include "util.h"
#include "vga.h"
#include <stdint.h>
#include <stddef.h>

disk_drive_t disk_drives[DISK_MAX_DRIVES];
int          disk_count = 0;

static void ata_400ns_delay(uint16_t io) {
    inb(io + ATA_ALT_STATUS); inb(io + ATA_ALT_STATUS);
    inb(io + ATA_ALT_STATUS); inb(io + ATA_ALT_STATUS);
}

static int ata_wait_ready(uint16_t io, int timeout_k) {
    while (timeout_k-- > 0) {
        uint8_t st = inb(io + ATA_STATUS);
        if (st & ATA_SR_ERR)  return -1;
        if (!(st & ATA_SR_BSY) && (st & ATA_SR_DRDY)) return 0;
    }
    return -2; /* timeout */
}

static int ata_wait_drq(uint16_t io, int timeout_k) {
    while (timeout_k-- > 0) {
        uint8_t st = inb(io + ATA_STATUS);
        if (st & ATA_SR_ERR) return -1;
        if (st & ATA_SR_DRQ) return 0;
    }
    return -2;
}

/* Send IDENTIFY and populate drive info */
static int ata_identify(disk_drive_t *drv) {
    uint16_t io = drv->io_base;

    /* Select drive */
    outb(io + ATA_DRIVE_SEL, drv->drive_sel);
    ata_400ns_delay(io);

    /* Zero sector count / LBA regs */
    outb(io + ATA_SECCOUNT, 0);
    outb(io + ATA_LBA_LO,   0);
    outb(io + ATA_LBA_MID,  0);
    outb(io + ATA_LBA_HI,   0);

    /* Send IDENTIFY */
    outb(io + ATA_COMMAND, ATA_CMD_IDENTIFY);
    ata_400ns_delay(io);

    uint8_t st = inb(io + ATA_STATUS);
    if (st == 0x00 || st == 0xFF) return -1; /* no drive */

    /* Wait for BSY clear */
    int timeout = 100000;
    while ((inb(io + ATA_STATUS) & ATA_SR_BSY) && --timeout);
    if (!timeout) return -1;

    /* Check if ATA (not ATAPI) */
    if (inb(io + ATA_LBA_MID) != 0 || inb(io + ATA_LBA_HI) != 0)
        return -1; /* ATAPI — skip */

    if (ata_wait_drq(io, 100000) < 0) return -1;

    /* Read 256 words of IDENTIFY data */
    uint16_t identify[256];
    for (int i = 0; i < 256; i++) identify[i] = inw(io + ATA_DATA);

    /* Word 60-61: LBA28 sector count */
    drv->sectors = ((uint32_t)identify[61] << 16) | identify[60];

    /* Words 27-46: model string (byte-swapped) */
    for (int i = 0; i < 20; i++) {
        drv->model[i*2]   = (char)(identify[27+i] >> 8);
        drv->model[i*2+1] = (char)(identify[27+i] & 0xFF);
    }
    drv->model[40] = 0;
    /* Trim trailing spaces */
    for (int i = 39; i >= 0 && drv->model[i] == ' '; i--) drv->model[i] = 0;

    drv->present = 1;
    return 0;
}

/* ── Public API ─────────────────────────────────────────────── */
void disk_init(void) {
    disk_count = 0;
    kmemset(disk_drives, 0, sizeof(disk_drives));

    struct { uint16_t io; uint16_t ctrl; uint8_t sel; } probes[] = {
        {ATA_PRIMARY_IO,   ATA_PRIMARY_CTRL, ATA_MASTER},
        {ATA_PRIMARY_IO,   ATA_PRIMARY_CTRL, ATA_SLAVE },
        {ATA_SECONDARY_IO, 0x376,            ATA_MASTER},
        {ATA_SECONDARY_IO, 0x376,            ATA_SLAVE },
    };

    for (int i = 0; i < DISK_MAX_DRIVES; i++) {
        disk_drives[i].io_base   = probes[i].io;
        disk_drives[i].ctrl_base = probes[i].ctrl;
        disk_drives[i].drive_sel = probes[i].sel;
        if (ata_identify(&disk_drives[i]) == 0) {
            disk_count++;
        }
    }
}

int disk_read_sector(int drv_idx, uint32_t lba, uint8_t *buf) {
    if (drv_idx < 0 || drv_idx >= DISK_MAX_DRIVES) return -1;
    disk_drive_t *drv = &disk_drives[drv_idx];
    if (!drv->present) return -1;

    uint16_t io = drv->io_base;

    if (ata_wait_ready(io, 100000) < 0) return -1;

    /* LBA28 setup */
    outb(io + ATA_DRIVE_SEL, (uint8_t)(drv->drive_sel | 0x40 |
                              ((lba >> 24) & 0x0F)));
    ata_400ns_delay(io);
    outb(io + ATA_SECCOUNT, 1);
    outb(io + ATA_LBA_LO,  (uint8_t)(lba & 0xFF));
    outb(io + ATA_LBA_MID, (uint8_t)((lba >> 8)  & 0xFF));
    outb(io + ATA_LBA_HI,  (uint8_t)((lba >> 16) & 0xFF));
    outb(io + ATA_COMMAND, ATA_CMD_READ_PIO);
    ata_400ns_delay(io);

    if (ata_wait_drq(io, 200000) < 0) return -1;

    /* Read 256 words */
    uint16_t *w = (uint16_t *)buf;
    for (int i = 0; i < 256; i++) w[i] = inw(io + ATA_DATA);
    return 0;
}

int disk_write_sector(int drv_idx, uint32_t lba, const uint8_t *buf) {
    if (drv_idx < 0 || drv_idx >= DISK_MAX_DRIVES) return -1;
    disk_drive_t *drv = &disk_drives[drv_idx];
    if (!drv->present) return -1;

    uint16_t io = drv->io_base;

    if (ata_wait_ready(io, 100000) < 0) return -1;

    outb(io + ATA_DRIVE_SEL, (uint8_t)(drv->drive_sel | 0x40 |
                              ((lba >> 24) & 0x0F)));
    ata_400ns_delay(io);
    outb(io + ATA_SECCOUNT, 1);
    outb(io + ATA_LBA_LO,  (uint8_t)(lba & 0xFF));
    outb(io + ATA_LBA_MID, (uint8_t)((lba >> 8)  & 0xFF));
    outb(io + ATA_LBA_HI,  (uint8_t)((lba >> 16) & 0xFF));
    outb(io + ATA_COMMAND, ATA_CMD_WRITE_PIO);
    ata_400ns_delay(io);

    if (ata_wait_drq(io, 200000) < 0) return -1;

    /* Write 256 words */
    const uint16_t *w = (const uint16_t *)buf;
    for (int i = 0; i < 256; i++) outw(io + ATA_DATA, w[i]);

    /* Flush cache */
    outb(io + ATA_COMMAND, ATA_CMD_FLUSH);
    ata_wait_ready(io, 100000);
    return 0;
}

int disk_read(int drv, uint32_t lba, uint32_t count, uint8_t *buf) {
    for (uint32_t i = 0; i < count; i++) {
        if (disk_read_sector(drv, lba + i, buf + i * SECTOR_SIZE) < 0)
            return -1;
    }
    return 0;
}

int disk_write(int drv, uint32_t lba, uint32_t count, const uint8_t *buf) {
    for (uint32_t i = 0; i < count; i++) {
        if (disk_write_sector(drv, lba + i, buf + i * SECTOR_SIZE) < 0)
            return -1;
    }
    return 0;
}

void disk_print_info(void) {
    char buf[16];
    if (disk_count == 0) {
        terminal_writeln("  No ATA drives detected");
        terminal_writeln("  (Use QEMU: -hda disk.img to add a drive)");
        return;
    }
    for (int i = 0; i < DISK_MAX_DRIVES; i++) {
        disk_drive_t *d = &disk_drives[i];
        if (!d->present) continue;
        terminal_write("  hd");
        terminal_putchar('a' + i);
        terminal_write(": ");
        terminal_write(d->model[0] ? d->model : "ATA Disk");
        terminal_write("  ");
        kuitoa(d->sectors / 2048, buf, 10);
        terminal_write(buf);
        terminal_writeln(" MB");
    }
}
