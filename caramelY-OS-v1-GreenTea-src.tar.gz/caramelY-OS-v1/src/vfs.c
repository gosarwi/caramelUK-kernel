/*  vfs.c — Virtual Filesystem Layer + RAM filesystem backend
 *
 *  Architecture:
 *    vfs_lookup() → walks path components, respects mount points
 *    ramfs → in-memory tree, stores file content in kmalloc'd buffers
 *    /dev   → character device nodes (keyboard, null, zero)
 *    /proc  → synthetic read-only files
 */
#include "vfs.h"
#include "kmalloc.h"
#include "util.h"
#include "pit.h"
#include <stdint.h>
#include <stddef.h>

/* ═══════════════════════════════════════════════════════════
 *  RAM filesystem
 * ═══════════════════════════════════════════════════════════ */
#define RAMFS_MAX_NODES  128
#define RAMFS_MAX_CONTENT 4096

typedef struct ramfs_inode {
    char     name[VFS_NAME_MAX];
    uint8_t  type;
    uint8_t  perms;
    uint8_t *data;
    uint32_t size;
    uint32_t capacity;
    uint32_t inode_no;
    int      used;
    int      parent;  /* index of parent inode */
} ramfs_inode_t;

static ramfs_inode_t ramfs_nodes[RAMFS_MAX_NODES];
static uint32_t      ramfs_next_inode = 1;

static int ramfs_alloc(void) {
    for (int i = 0; i < RAMFS_MAX_NODES; i++)
        if (!ramfs_nodes[i].used) { ramfs_nodes[i].used = 1; return i; }
    return -1;
}

static int ramfs_find_child(int parent, const char *name) {
    for (int i = 0; i < RAMFS_MAX_NODES; i++) {
        if (!ramfs_nodes[i].used) continue;
        if (ramfs_nodes[i].parent != parent) continue;
        if (kstrcmp(ramfs_nodes[i].name, name) == 0) return i;
    }
    return -1;
}

/* VFS node pool (one per ramfs inode) */
static vfs_node_t vfs_node_pool[RAMFS_MAX_NODES];

/* Forward declare ops */
static vfs_ops_t ramfs_ops;

static vfs_node_t *ramfs_idx_to_node(int idx) {
    if (idx < 0 || idx >= RAMFS_MAX_NODES) return NULL;
    vfs_node_t *n = &vfs_node_pool[idx];
    ramfs_inode_t *ri = &ramfs_nodes[idx];
    kstrcpy(n->name, ri->name);
    n->inode = ri->inode_no;
    n->size  = ri->size;
    n->type  = ri->type;
    n->perms = ri->perms;
    n->ops   = &ramfs_ops;
    n->impl  = (void *)(uintptr_t)idx;
    n->mount = NULL;
    return n;
}

/* ── ramfs ops ──────────────────────────────────────────── */
static uint32_t ramfs_read(vfs_node_t *n, uint32_t off, uint32_t sz, uint8_t *buf) {
    int idx = (int)(uintptr_t)n->impl;
    ramfs_inode_t *ri = &ramfs_nodes[idx];
    if (!ri->data || off >= ri->size) return 0;
    uint32_t avail = ri->size - off;
    if (sz > avail) sz = avail;
    for (uint32_t i = 0; i < sz; i++) buf[i] = ri->data[off + i];
    return sz;
}

static uint32_t ramfs_write(vfs_node_t *n, uint32_t off, uint32_t sz, const uint8_t *buf) {
    int idx = (int)(uintptr_t)n->impl;
    ramfs_inode_t *ri = &ramfs_nodes[idx];
    uint32_t need = off + sz;
    if (need > ri->capacity) {
        uint32_t newcap = need + 256;
        if (newcap > RAMFS_MAX_CONTENT) newcap = RAMFS_MAX_CONTENT;
        if (need > RAMFS_MAX_CONTENT) sz = RAMFS_MAX_CONTENT - off;
        uint8_t *newbuf = (uint8_t *)kmalloc(newcap);
        if (!newbuf) return 0;
        if (ri->data) {
            for (uint32_t i = 0; i < ri->size; i++) newbuf[i] = ri->data[i];
            kfree(ri->data);
        }
        ri->data = newbuf;
        ri->capacity = newcap;
    }
    for (uint32_t i = 0; i < sz; i++) ri->data[off + i] = buf[i];
    if (off + sz > ri->size) ri->size = off + sz;
    n->size = ri->size;
    return sz;
}

static struct vfs_dirent *ramfs_readdir(vfs_node_t *n, uint32_t index) {
    int parent = (int)(uintptr_t)n->impl;
    uint32_t cnt = 0;
    for (int i = 0; i < RAMFS_MAX_NODES; i++) {
        if (!ramfs_nodes[i].used) continue;
        if (ramfs_nodes[i].parent != parent) continue;
        if (cnt == index) {
            static vfs_dirent_t de;
            kstrcpy(de.name, ramfs_nodes[i].name);
            de.inode = ramfs_nodes[i].inode_no;
            de.type  = ramfs_nodes[i].type;
            return &de;
        }
        cnt++;
    }
    return NULL;
}

static vfs_node_t *ramfs_finddir(vfs_node_t *n, const char *name) {
    int parent = (int)(uintptr_t)n->impl;
    int idx = ramfs_find_child(parent, name);
    if (idx < 0) return NULL;
    return ramfs_idx_to_node(idx);
}

static int ramfs_create_node(vfs_node_t *parent_node, const char *name, uint8_t type) {
    int parent = (int)(uintptr_t)parent_node->impl;
    if (ramfs_find_child(parent, name) >= 0) return -1;  /* exists */
    int idx = ramfs_alloc();
    if (idx < 0) return -1;
    ramfs_inode_t *ri = &ramfs_nodes[idx];
    kstrcpy(ri->name, name);
    ri->type     = type;
    ri->perms    = PERM_R | PERM_W;
    ri->parent   = parent;
    ri->inode_no = ramfs_next_inode++;
    ri->data     = NULL;
    ri->size     = 0;
    ri->capacity = 0;
    return 0;
}

static int ramfs_unlink_node(vfs_node_t *parent_node, const char *name) {
    int parent = (int)(uintptr_t)parent_node->impl;
    int idx = ramfs_find_child(parent, name);
    if (idx < 0) return -1;
    ramfs_inode_t *ri = &ramfs_nodes[idx];
    if (ri->data) { kfree(ri->data); ri->data = NULL; }
    kmemset(ri, 0, sizeof(*ri));
    return 0;
}

static int ramfs_mkdir_op(vfs_node_t *parent_node, const char *name) {
    return ramfs_create_node(parent_node, name, VFS_DIR);
}

static int ramfs_stat(vfs_node_t *n, vfs_stat_t *st) {
    st->inode = n->inode;
    st->size  = n->size;
    st->type  = n->type;
    st->perms = n->perms;
    st->uid = st->gid = 0;
    return 0;
}

static vfs_ops_t ramfs_ops = {
    .read    = ramfs_read,
    .write   = ramfs_write,
    .open    = NULL,
    .close   = NULL,
    .readdir = ramfs_readdir,
    .finddir = ramfs_finddir,
    .create  = ramfs_create_node,
    .unlink  = ramfs_unlink_node,
    .stat    = ramfs_stat,
    .mkdir   = ramfs_mkdir_op,
};

/* ── ramfs_create_root ─────────────────────────────────────── */
vfs_node_t *ramfs_create_root(void) {
    kmemset(ramfs_nodes, 0, sizeof(ramfs_nodes));
    kmemset(vfs_node_pool, 0, sizeof(vfs_node_pool));
    ramfs_next_inode = 1;

    int idx = ramfs_alloc();   /* idx=0 = root */
    ramfs_inode_t *ri = &ramfs_nodes[idx];
    kstrcpy(ri->name, "/");
    ri->type     = VFS_DIR;
    ri->perms    = PERM_R | PERM_W | PERM_X;
    ri->parent   = -1;   /* root has no parent */
    ri->inode_no = ramfs_next_inode++;
    return ramfs_idx_to_node(idx);
}

/* ═══════════════════════════════════════════════════════════
 *  VFS global state
 * ═══════════════════════════════════════════════════════════ */
#define MOUNT_MAX 16
typedef struct { char path[128]; vfs_node_t *node; } mount_entry_t;
static mount_entry_t mount_table[MOUNT_MAX];
static int           mount_count = 0;
static vfs_node_t   *fs_root = NULL;
static fd_t          fd_table[FD_MAX];

/* ── vfs_init ─────────────────────────────────────────────── */

/* Helper: write a string into a ramfs file */
static void ramfs_write_str(vfs_node_t *dir, const char *fname,
                            const char *content)
{
    ramfs_create_node(dir, fname, VFS_FILE);
    vfs_node_t *f = ramfs_finddir(dir, fname);
    if (f) ramfs_write(f, 0, (uint32_t)kstrlen(content), (const uint8_t *)content);
}

static void populate_proc(vfs_node_t *proc_dir);

void vfs_init(void) {
    kmemset(mount_table, 0, sizeof(mount_table));
    kmemset(fd_table, 0, sizeof(fd_table));
    mount_count = 0;

    fs_root = ramfs_create_root();

    /* Standard directory tree */
    const char *dirs[] = {
        "bin","boot","dev","etc","home","lib",
        "mnt","proc","root","tmp","usr","var", NULL
    };
    for (int i = 0; dirs[i]; i++)
        ramfs_create_node(fs_root, dirs[i], VFS_DIR);

    /* /etc config files (Ubuntu-style) */
    vfs_node_t *etc = ramfs_finddir(fs_root, "etc");
    if (etc) {
        ramfs_write_str(etc, "os-release",
            "NAME=\"CaramelUK\"\n"
            "VERSION=\"3.0\"\n"
            "ID=carameluk\n"
            "ID_LIKE=ubuntu\n"
            "PRETTY_NAME=\"CaramelUK OS 3.0\"\n"
            "VERSION_ID=\"3.0\"\n"
            "HOME_URL=\"https://carameluk.os\"\n"
            "SUPPORT_URL=\"https://carameluk.os/support\"\n"
            "BUG_REPORT_URL=\"https://carameluk.os/bugs\"\n");

        ramfs_write_str(etc, "hostname", "carameluk\n");
        ramfs_write_str(etc, "timezone", "UTC\n");
        ramfs_write_str(etc, "motd",
            "Welcome to CaramelUK OS 3.0!\n"
            "Type 'help' for commands.\n");

        /* /etc/network/interfaces style */
        ramfs_create_node(etc, "network", VFS_DIR);
        vfs_node_t *net = ramfs_finddir(etc, "network");
        if (net) {
            ramfs_write_str(net, "interfaces",
                "# CaramelUK network interfaces\n"
                "# This file describes the network interfaces\n"
                "\n"
                "auto lo\n"
                "iface lo inet loopback\n"
                "\n"
                "auto eth0\n"
                "iface eth0 inet dhcp\n"
                "\thostname carameluk\n");
        }

        /* /etc/fstab */
        ramfs_write_str(etc, "fstab",
            "# CaramelUK fstab\n"
            "# <device>  <mountpoint>  <type>  <options>    <dump> <pass>\n"
            "ramfs       /             ramfs   defaults       0      0\n"
            "proc        /proc         proc    defaults       0      0\n"
            "devfs       /dev          devfs   defaults       0      0\n");

        /* /etc/carameluk.conf — main system config */
        ramfs_write_str(etc, "carameluk.conf",
            "# CaramelUK System Configuration\n"
            "# /etc/carameluk.conf\n"
            "\n"
            "[system]\n"
            "hostname=carameluk\n"
            "timezone=UTC\n"
            "locale=en_US.UTF-8\n"
            "kernel_version=3.0.0\n"
            "\n"
            "[console]\n"
            "theme=caramel\n"
            "font_size=16\n"
            "mode=vbe\n"
            "resolution=800x600\n"
            "\n"
            "[scheduler]\n"
            "algorithm=round_robin\n"
            "quantum_ms=20\n"
            "max_tasks=16\n"
            "\n"
            "[memory]\n"
            "heap_base=0x400000\n"
            "heap_size=4M\n"
            "\n"
            "[network]\n"
            "driver=rtl8139\n"
            "dhcp=yes\n"
            "mac=auto\n");

        /* /etc/passwd (minimal) */
        ramfs_write_str(etc, "passwd",
            "root:x:0:0:root:/root:/bin/sh\n"
            "caramel:x:1000:1000::/home/caramel:/bin/sh\n");

        /* /etc/group */
        ramfs_write_str(etc, "group",
            "root:x:0:\n"
            "sudo:x:27:caramel\n"
            "caramel:x:1000:\n");

        /* /etc/hosts */
        ramfs_write_str(etc, "hosts",
            "127.0.0.1  localhost\n"
            "127.0.1.1  carameluk\n"
            "::1        localhost ip6-localhost\n");

        /* /etc/resolv.conf */
        ramfs_write_str(etc, "resolv.conf",
            "# CaramelUK DNS resolver config\n"
            "nameserver 8.8.8.8\n"
            "nameserver 8.8.4.4\n"
            "search local\n");

        /* /etc/apt directory (Ubuntu-style) */
        ramfs_create_node(etc, "apt", VFS_DIR);
        vfs_node_t *apt = ramfs_finddir(etc, "apt");
        if (apt) {
            ramfs_write_str(apt, "sources.list",
                "# CaramelUK package sources\n"
                "deb http://archive.carameluk.os/packages/ caramel main\n"
                "deb http://archive.carameluk.os/packages/ caramel universe\n");
        }
    }

    /* /home */
    vfs_node_t *home = ramfs_finddir(fs_root, "home");
    if (home) {
        ramfs_create_node(home, "caramel", VFS_DIR);
        vfs_node_t *uhome = ramfs_finddir(home, "caramel");
        if (uhome) {
            ramfs_write_str(uhome, ".bashrc",
                "# ~/.bashrc: executed by bash(1) for non-login shells.\n"
                "export PS1='\\u@\\h:\\w\\$ '\n"
                "alias ll='ls -la'\n"
                "alias la='ls -A'\n");
            ramfs_write_str(uhome, ".profile",
                "# ~/.profile\n"
                "if [ -f ~/.bashrc ]; then\n"
                "  . ~/.bashrc\n"
                "fi\n");
            ramfs_write_str(uhome, "readme.txt",
                "Welcome to your CaramelUK home directory!\n"
                "Type 'help' for available commands.\n");
        }
    }

    /* /root */
    vfs_node_t *root_home = ramfs_finddir(fs_root, "root");
    if (root_home) {
        ramfs_write_str(root_home, ".bashrc",
            "# /root/.bashrc\n"
            "export PS1='\\[\\033[01;31m\\]\\u@\\h\\[\\033[00m\\]:\\w# '\n");
    }

    /* /tmp */
    vfs_node_t *tmp = ramfs_finddir(fs_root, "tmp");
    if (tmp)
        ramfs_write_str(tmp, ".keep", "# tmpfs placeholder\n");

    /* /proc synthetic files */
    vfs_node_t *proc = ramfs_finddir(fs_root, "proc");
    if (proc) populate_proc(proc);

    /* /dev nodes */
    vfs_node_t *dev = ramfs_finddir(fs_root, "dev");
    if (dev) {
        ramfs_create_node(dev, "null",   VFS_CHARDEV);
        ramfs_create_node(dev, "zero",   VFS_CHARDEV);
        ramfs_create_node(dev, "random", VFS_CHARDEV);
        ramfs_create_node(dev, "tty0",   VFS_CHARDEV);
        ramfs_create_node(dev, "eth0",   VFS_CHARDEV);
    }
}

static void populate_proc(vfs_node_t *proc_dir) {
    ramfs_write_str(proc_dir, "version",
        "CaramelUK version 3.0.0 (carameluk@carameluk) "
        "(gcc 13.0) #1 SMP x86\n");
    ramfs_write_str(proc_dir, "cmdline", "carameluk quiet splash\n");
    ramfs_write_str(proc_dir, "uptime",  "0.00 0.00\n");
    ramfs_write_str(proc_dir, "meminfo",
        "MemTotal:       65536 kB\n"
        "MemFree:        60000 kB\n"
        "MemAvailable:   58000 kB\n"
        "Buffers:            0 kB\n"
        "Cached:          1024 kB\n"
        "SwapTotal:          0 kB\n"
        "SwapFree:           0 kB\n");
    ramfs_write_str(proc_dir, "cpuinfo",
        "processor\t: 0\n"
        "vendor_id\t: CaramelUK\n"
        "cpu family\t: 6\n"
        "model name\t: CaramelUK Virtual CPU @ 100MHz\n"
        "cpu MHz\t\t: 100.000\n"
        "cache size\t: 256 KB\n"
        "flags\t\t: fpu pse pae tsc msr\n");
    ramfs_write_str(proc_dir, "mounts",
        "ramfs / ramfs rw 0 0\n"
        "proc /proc proc ro 0 0\n"
        "devfs /dev devfs rw 0 0\n");
}

/* ═══════════════════════════════════════════════════════════
 *  VFS API
 * ═══════════════════════════════════════════════════════════ */
vfs_node_t *vfs_root(void) { return fs_root; }

void vfs_mount(const char *path, vfs_node_t *node) {
    if (mount_count >= MOUNT_MAX) return;
    kstrcpy(mount_table[mount_count].path, path);
    mount_table[mount_count].node = node;
    mount_count++;
}

/* Walk path from root, returns node or NULL */
vfs_node_t *vfs_lookup(const char *path) {
    if (!path || path[0] != '/') return NULL;
    if (path[0] == '/' && path[1] == '\0') return fs_root;

    vfs_node_t *cur = fs_root;
    char component[VFS_NAME_MAX];
    const char *p = path + 1;

    while (*p) {
        /* Extract next component */
        int i = 0;
        while (*p && *p != '/' && i < (int)VFS_NAME_MAX-1)
            component[i++] = *p++;
        component[i] = 0;
        if (*p == '/') p++;
        if (i == 0) continue;

        if (!cur->ops || !cur->ops->finddir) return NULL;
        cur = cur->ops->finddir(cur, component);
        if (!cur) return NULL;

        /* Handle mount points */
        if (cur->mount) cur = cur->mount;
    }
    return cur;
}

/* ── Path splitting helper ───────────────────────────────── */
static void split_last(const char *path, char *dir, char *base) {
    const char *last = path;
    for (const char *p = path; *p; p++) if (*p == '/') last = p;
    if (last == path) {
        kstrcpy(dir, "/");
        kstrcpy(base, path + 1);
    } else {
        size_t dlen = (size_t)(last - path);
        for (size_t i = 0; i < dlen; i++) dir[i] = path[i];
        dir[dlen] = 0;
        kstrcpy(base, last + 1);
    }
}

/* ── fd allocation ───────────────────────────────────────── */
static int alloc_fd(void) {
    for (int i = 3; i < FD_MAX; i++)   /* 0,1,2 = stdin/out/err */
        if (!fd_table[i].used) return i;
    return -1;
}

int vfs_open(const char *path, uint32_t flags) {
    vfs_node_t *n = vfs_lookup(path);
    if (!n) {
        if (!(flags & O_CREAT)) return -1;
        /* create file */
        char dir[128], base[VFS_NAME_MAX];
        split_last(path, dir, base);
        vfs_node_t *parent = vfs_lookup(dir);
        if (!parent || !parent->ops->create) return -1;
        if (parent->ops->create(parent, base, VFS_FILE) < 0) return -1;
        n = parent->ops->finddir(parent, base);
        if (!n) return -1;
    }
    int fd = alloc_fd();
    if (fd < 0) return -1;
    fd_table[fd].node   = n;
    fd_table[fd].offset = 0;
    fd_table[fd].flags  = flags;
    fd_table[fd].used   = 1;
    if (flags & O_TRUNC && n->ops && n->ops->write)
        n->size = 0;
    if (flags & O_APPEND && n->ops)
        fd_table[fd].offset = n->size;
    return fd;
}

void vfs_close(int fd) {
    if (fd < 0 || fd >= FD_MAX) return;
    fd_table[fd].used = 0;
    fd_table[fd].node = NULL;
}

int vfs_read(int fd, void *buf, uint32_t size) {
    if (fd < 0 || fd >= FD_MAX || !fd_table[fd].used) return -1;
    fd_t *f = &fd_table[fd];
    if (!f->node->ops || !f->node->ops->read) return -1;
    uint32_t n = f->node->ops->read(f->node, f->offset, size, (uint8_t *)buf);
    f->offset += n;
    return (int)n;
}

int vfs_write(int fd, const void *buf, uint32_t size) {
    if (fd < 0 || fd >= FD_MAX || !fd_table[fd].used) return -1;
    fd_t *f = &fd_table[fd];
    if (!f->node->ops || !f->node->ops->write) return -1;
    uint32_t n = f->node->ops->write(f->node, f->offset, size, (const uint8_t *)buf);
    f->offset += n;
    return (int)n;
}

int vfs_stat(const char *path, vfs_stat_t *st) {
    vfs_node_t *n = vfs_lookup(path);
    if (!n) return -1;
    if (n->ops && n->ops->stat) return n->ops->stat(n, st);
    st->inode = n->inode;
    st->size  = n->size;
    st->type  = n->type;
    st->perms = n->perms;
    return 0;
}

int vfs_mkdir(const char *path) {
    char dir[128], base[VFS_NAME_MAX];
    split_last(path, dir, base);
    vfs_node_t *parent = vfs_lookup(dir);
    if (!parent || !parent->ops || !parent->ops->mkdir) return -1;
    return parent->ops->mkdir(parent, base);
}

int vfs_create(const char *path) {
    char dir[128], base[VFS_NAME_MAX];
    split_last(path, dir, base);
    vfs_node_t *parent = vfs_lookup(dir);
    if (!parent || !parent->ops || !parent->ops->create) return -1;
    return parent->ops->create(parent, base, VFS_FILE);
}

int vfs_unlink(const char *path) {
    char dir[128], base[VFS_NAME_MAX];
    split_last(path, dir, base);
    vfs_node_t *parent = vfs_lookup(dir);
    if (!parent || !parent->ops || !parent->ops->unlink) return -1;
    return parent->ops->unlink(parent, base);
}

int vfs_listdir(const char *path, char names[][VFS_NAME_MAX], int *count) {
    vfs_node_t *dir = vfs_lookup(path);
    if (!dir || !(dir->type & VFS_DIR)) return -1;
    if (!dir->ops || !dir->ops->readdir) return -1;
    *count = 0;
    for (uint32_t i = 0; ; i++) {
        vfs_dirent_t *de = dir->ops->readdir(dir, i);
        if (!de) break;
        kstrcpy(names[*count], de->name);
        if (de->type == VFS_DIR)
            kstrcat(names[*count], "/");
        (*count)++;
        if (*count >= RAMFS_MAX_NODES) break;
    }
    return 0;
}

vfs_dirent_t *vfs_readdir(const char *path, uint32_t index) {
    vfs_node_t *dir = vfs_lookup(path);
    if (!dir || !(dir->type & VFS_DIR)) return NULL;
    if (!dir->ops || !dir->ops->readdir) return NULL;
    return dir->ops->readdir(dir, index);
}
