/*  elf.c — ELF32 loader for CaramelUK OS v3
 *
 *  Supports loading ET_EXEC (executable) ELF32 binaries.
 *  PT_LOAD segments are copied from the file buffer into memory.
 *  Zero-initializes BSS (memsz > filesz).
 */
#include "elf.h"
#include "kmalloc.h"
#include "util.h"
#include "vga.h"
#include <stdint.h>
#include <stddef.h>

/* ── Validation ──────────────────────────────────────────── */
int elf_validate(const uint8_t *buf, uint32_t size) {
    if (size < sizeof(Elf32_Ehdr)) return 0;
    const Elf32_Ehdr *hdr = (const Elf32_Ehdr *)buf;
    if (hdr->e_ident[EI_MAG0] != ELF_MAGIC0) return 0;
    if (hdr->e_ident[EI_MAG1] != ELF_MAGIC1) return 0;
    if (hdr->e_ident[EI_MAG2] != ELF_MAGIC2) return 0;
    if (hdr->e_ident[EI_MAG3] != ELF_MAGIC3) return 0;
    if (hdr->e_ident[EI_CLASS] != 1)         return 0; /* ELF32 */
    if (hdr->e_ident[EI_DATA]  != 1)         return 0; /* little-endian */
    if (hdr->e_machine != EM_386)             return 0;
    return 1;
}

/* ── Load ─────────────────────────────────────────────────── */
elf_load_result_t elf_load(const uint8_t *buf, uint32_t size) {
    elf_load_result_t res = {0};

    if (!elf_validate(buf, size)) {
        kstrcpy(res.error, "Not a valid ELF32 x86 binary");
        return res;
    }

    const Elf32_Ehdr *hdr = (const Elf32_Ehdr *)buf;

    if (hdr->e_type != ET_EXEC) {
        kstrcpy(res.error, "Only ET_EXEC supported");
        return res;
    }
    if (hdr->e_phnum == 0) {
        kstrcpy(res.error, "No program headers");
        return res;
    }

    res.load_base = 0xFFFFFFFF;
    res.load_end  = 0;

    /* Walk PT_LOAD segments */
    for (int i = 0; i < hdr->e_phnum; i++) {
        uint32_t ph_off = hdr->e_phoff + (uint32_t)i * hdr->e_phentsize;
        if (ph_off + sizeof(Elf32_Phdr) > size) break;

        const Elf32_Phdr *ph = (const Elf32_Phdr *)(buf + ph_off);
        if (ph->p_type != PT_LOAD) continue;
        if (ph->p_memsz == 0) continue;

        /* Safety: don't allow loading into low memory or kernel space */
        if (ph->p_vaddr < 0x100000) {
            kstrcpy(res.error, "ELF vaddr too low (<1MB)");
            return res;
        }

        /* Copy file data */
        uint8_t *dest = (uint8_t *)(uintptr_t)ph->p_vaddr;
        uint32_t filesz = ph->p_filesz;
        if (filesz > size - ph->p_offset) filesz = size - ph->p_offset;

        for (uint32_t j = 0; j < filesz; j++)
            dest[j] = buf[ph->p_offset + j];

        /* Zero BSS (memsz - filesz) */
        for (uint32_t j = filesz; j < ph->p_memsz; j++)
            dest[j] = 0;

        if (ph->p_vaddr < res.load_base) res.load_base = ph->p_vaddr;
        uint32_t end = ph->p_vaddr + ph->p_memsz;
        if (end > res.load_end) res.load_end = end;
    }

    res.entry = hdr->e_entry;
    res.valid = 1;
    return res;
}

/* ── elf_info — print ELF metadata ─────────────────────────── */
static const char *elf_type_str(uint16_t t) {
    switch (t) {
        case ET_REL:  return "REL (relocatable)";
        case ET_EXEC: return "EXEC (executable)";
        case ET_DYN:  return "DYN (shared object)";
        default:      return "UNKNOWN";
    }
}

void elf_info(const uint8_t *buf, uint32_t size) {
    if (!elf_validate(buf, size)) {
        terminal_writeln("  Not a valid ELF32 binary");
        return;
    }
    const Elf32_Ehdr *hdr = (const Elf32_Ehdr *)buf;
    char tmp[16];

    terminal_write("  Type:        "); terminal_writeln(elf_type_str(hdr->e_type));
    terminal_write("  Machine:     ");
    terminal_writeln(hdr->e_machine == EM_386 ? "x86 (i386)" : "unknown");
    terminal_write("  Entry:       0x");
    kuitoa(hdr->e_entry, tmp, 16); terminal_writeln(tmp);
    terminal_write("  PH count:    ");
    kuitoa(hdr->e_phnum, tmp, 10); terminal_writeln(tmp);
    terminal_write("  SH count:    ");
    kuitoa(hdr->e_shnum, tmp, 10); terminal_writeln(tmp);

    /* Print program headers */
    terminal_writeln("  Program headers:");
    for (int i = 0; i < hdr->e_phnum; i++) {
        uint32_t ph_off = hdr->e_phoff + (uint32_t)i * hdr->e_phentsize;
        if (ph_off + sizeof(Elf32_Phdr) > size) break;
        const Elf32_Phdr *ph = (const Elf32_Phdr *)(buf + ph_off);
        const char *ptype = (ph->p_type == PT_LOAD) ? "LOAD" :
                            (ph->p_type == PT_NOTE) ? "NOTE" : "OTHER";
        terminal_write("    [");
        kuitoa((uint32_t)i, tmp, 10); terminal_write(tmp);
        terminal_write("] ");
        terminal_write(ptype);
        terminal_write("  vaddr=0x");
        kuitoa(ph->p_vaddr, tmp, 16); terminal_write(tmp);
        terminal_write("  filesz=");
        kuitoa(ph->p_filesz, tmp, 10); terminal_write(tmp);
        terminal_write("  memsz=");
        kuitoa(ph->p_memsz, tmp, 10); terminal_writeln(tmp);
    }
}
