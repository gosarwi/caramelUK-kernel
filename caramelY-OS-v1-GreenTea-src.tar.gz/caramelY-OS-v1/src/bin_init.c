/* bin_init.c — caramelY OS v1 — /bin/ stubs */
#include "vfs.h"
#include "util.h"

static void bw(const char *p, const char *c){
    int fd=vfs_open(p,O_WRONLY|O_CREAT|O_TRUNC);
    if(fd>=0){vfs_write(fd,c,(uint32_t)kstrlen(c));vfs_close(fd);}
}

void bin_init(void){
    vfs_mkdir("/bin");
    bw("/bin/ls","#!/bin/caramelsh\nls $A\n");
    bw("/bin/ll","#!/bin/caramelsh\nls -l $A\n");
    bw("/bin/cat","#!/bin/caramelsh\ncat $A\n");
    bw("/bin/grep","#!/bin/caramelsh\ngrep $A\n");
    bw("/bin/find","#!/bin/caramelsh\nfind $A\n");
    bw("/bin/head","#!/bin/caramelsh\nhead $A\n");
    bw("/bin/tail","#!/bin/caramelsh\ntail $A\n");
    bw("/bin/wc","#!/bin/caramelsh\nwc $A\n");
    bw("/bin/sort","#!/bin/caramelsh\nsort $A\n");
    bw("/bin/echo","#!/bin/caramelsh\necho $A\n");
    bw("/bin/mkdir","#!/bin/caramelsh\nmkdir $A\n");
    bw("/bin/rm","#!/bin/caramelsh\nrm $A\n");
    bw("/bin/cp","#!/bin/caramelsh\ncp $A\n");
    bw("/bin/mv","#!/bin/caramelsh\nmv $A\n");
    bw("/bin/touch","#!/bin/caramelsh\ntouch $A\n");
    bw("/bin/chmod","#!/bin/caramelsh\nchmod $A\n");
    bw("/bin/stat","#!/bin/caramelsh\nstat $A\n");
    bw("/bin/pwd","#!/bin/caramelsh\npwd\n");
    bw("/bin/ps","#!/bin/caramelsh\nps\n");
    bw("/bin/kill","#!/bin/caramelsh\nkill $A\n");
    bw("/bin/clear","#!/bin/caramelsh\nclear\n");
    bw("/bin/date","#!/bin/caramelsh\ndate\n");
    bw("/bin/uptime","#!/bin/caramelsh\nuptime\n");
    bw("/bin/free","#!/bin/caramelsh\nfree\n");
    bw("/bin/uname","#!/bin/caramelsh\nuname $A\n");
    bw("/bin/ping","#!/bin/caramelsh\nping $A\n");
    bw("/bin/tess","#!/bin/caramelsh\ntess $A\n");
    bw("/bin/vi","#!/bin/caramelsh\ntess $A\n");
    bw("/bin/ai","#!/bin/caramelsh\nai $A\n");
    bw("/bin/kmod","#!/bin/caramelsh\nkmod $A\n");
    bw("/bin/which","#!/bin/caramelsh\nwhich $A\n");
    bw("/bin/man","#!/bin/caramelsh\nman $A\n");
}
