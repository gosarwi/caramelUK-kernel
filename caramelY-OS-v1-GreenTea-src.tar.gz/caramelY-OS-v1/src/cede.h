#ifndef CEDE_H
#define CEDE_H

/*  cede.h — CaramelUK Executable/Distribution Environment (.cede) v2
 *
 *  Улучшенный формат пакетов v7 "Cupcake":
 *    - Magic 0xCEDE0005 (v2)
 *    - 8 типов секций (было 5)
 *    - Поддержка иконок, man-страниц, ресурсов
 *    - Зависимости, лицензия, homepage
 *    - pkg create / pkg remove
 *    - Контрольная сумма CRC32-like
 *    - Флаги: compress (zlib-stub), exec, hidden
 *
 *  Структура файла:
 *    [cede_header_t  512 байт]
 *    [cede_section_t × n_sections  (64 байта каждая)]
 *    [данные секций, подряд, выровнены по 16 байт]
 */

#include <stdint.h>
#include <stddef.h>

#define CEDE_MAGIC      0xCEDE0005   /* v2 magic */
#define CEDE_MAGIC_V1   0xCEDE0004   /* старый v1, для совместимости */
#define CEDE_VERSION    2

/* ── Типы секций ─────────────────────────────────────────── */
#define CEDE_SEC_ELF    1   /* ELF32 исполняемый файл         */
#define CEDE_SEC_DATA   2   /* произвольный файл данных       */
#define CEDE_SEC_CONF   3   /* конфиг → /uiu/etc/             */
#define CEDE_SEC_INIT   4   /* скрипт установки (shell)       */
#define CEDE_SEC_LIB    5   /* разделяемая библиотека         */
#define CEDE_SEC_ICON   6   /* иконка (raw RGB 16x16 или txt) */
#define CEDE_SEC_MAN    7   /* man-страница → /uiu/etc/man/   */
#define CEDE_SEC_RES    8   /* ресурсы (шрифты, звуки, etc.)  */
#define CEDE_SEC_DYNLIB 9   /* динамическая библиотека (.so)   */
#define CEDE_SEC_SAVEDATA 10 /* сохранения игры / данные приложения */
#define CEDE_SEC_SCRIPT 11  /* скрипт запуска (shell)          */

/* ── Флаги секции ────────────────────────────────────────── */
#define CEDE_FLAG_EXEC      (1<<0)  /* секция исполняема        */
#define CEDE_FLAG_COMPRESS  (1<<1)  /* данные сжаты (stub)      */
#define CEDE_FLAG_HIDDEN    (1<<2)  /* не показывать в info     */
#define CEDE_FLAG_OPTIONAL  (1<<3)  /* можно пропустить         */

/* ── Заголовок пакета (512 байт) ─────────────────────────── */
typedef struct __attribute__((packed)) {
    uint32_t magic;                 /* CEDE_MAGIC               */
    uint32_t cede_version;          /* версия формата = 2       */
    char     pkg_name[64];          /* "myapp"                  */
    char     pkg_version[32];       /* "1.2.3"                  */
    char     pkg_author[64];        /* "Vasya Pupkin"           */
    char     pkg_description[128];  /* однострочное описание    */
    char     pkg_depends[64];       /* "libc libvbe" (пробелы)  */
    char     pkg_license[32];       /* "MIT", "GPL", "custom"   */
    char     pkg_homepage[64];      /* "caramel://myapp"        */
    uint32_t n_sections;            /* кол-во секций            */
    uint32_t install_size;          /* байт после установки     */
    uint32_t checksum;              /* XOR32 всего файла        */
    uint32_t build_date;            /* unix timestamp (uptime)  */
    uint8_t  _pad[512 - 4*4 - 64-32-64-128-64-32-64];
} cede_header_t;

/* ── Дескриптор секции (64 байта) ────────────────────────── */
typedef struct __attribute__((packed)) {
    uint8_t  type;             /* CEDE_SEC_*                    */
    uint8_t  flags;            /* CEDE_FLAG_*                   */
    uint16_t _reserved;
    char     name[16];         /* имя секции ("main", "data1")  */
    char     dest_path[36];    /* путь установки                */
    uint32_t offset;           /* смещение данных в файле       */
    uint32_t size;             /* размер секции                 */
    uint32_t orig_size;        /* несжатый размер (если compress)*/
    uint32_t entry_offset;     /* для ELF: точка входа          */
} cede_section_t;

/* ── Загруженный пакет (in-memory) ──────────────────────── */
typedef struct {
    cede_header_t  hdr;
    cede_section_t sections[16];
    const uint8_t *data;
    uint32_t       data_size;
    int            v1_compat;  /* 1 если загружен v1 пакет     */
} cede_pkg_t;

/* ── API ──────────────────────────────────────────────────── */
/* Разбор .cede файла из памяти (поддерживает v1 и v2) */
int cede_parse(cede_pkg_t *pkg, const uint8_t *buf, uint32_t size);

/* Установка пакета (извлекает файлы, запускает INIT) */
int cede_install(const cede_pkg_t *pkg);

/* Удаление пакета по имени */
int cede_remove(const char *pkg_name);

/* Запуск ELF-секции из пакета */
int cede_exec(const cede_pkg_t *pkg, int section_idx);

/* Вывод информации о пакете */
void cede_info(const cede_pkg_t *pkg);

/* Создание .cede пакета из ELF файла */
int cede_wrap_elf(const uint8_t *elf_data, uint32_t elf_size,
                  const char *name, const char *version,
                  uint8_t *out_buf, uint32_t out_sz);

/* Сохранение/загрузка данных секции SAVEDATA */
int cede_savedata_write(const char *pkg_name, const void *data, uint32_t size);
int cede_savedata_read(const char *pkg_name, void *data, uint32_t maxsize);

/* Загрузка динамической библиотеки из CEDE_SEC_DYNLIB */
int cede_dynlib_load(const cede_pkg_t *pkg, int section_idx);

/* Вычисление контрольной суммы */
uint32_t cede_checksum(const uint8_t *data, uint32_t size);

#endif
