#ifndef BROWSER_H
#define BROWSER_H
/* browser.h — CaramelFox Browser v1.0 — CaramelUK v7 */

#include <stdint.h>
#include <stddef.h>

/* Размеры уменьшены чтобы не раздувать BSS */
#define BR_MAX_TABS      4
#define BR_MAX_URL      128
#define BR_MAX_TITLE     64
#define BR_MAX_NODES    128
#define BR_MAX_TEXT    2048
#define BR_PAGE_BUF    4096

typedef enum {
    NODE_TEXT=0, NODE_H1, NODE_H2, NODE_H3,
    NODE_P, NODE_B, NODE_I, NODE_U, NODE_A,
    NODE_LI, NODE_BR, NODE_HR, NODE_CODE,
    NODE_PRE, NODE_BLOCKQUOTE, NODE_IMG,
} node_type_t;

typedef struct {
    node_type_t type;
    char        text[96];
    char        href[48];
    char        alt[24];
    uint8_t     bold, italic, indent;
    uint32_t    fg, bg;
} br_node_t;

typedef struct {
    char        url[BR_MAX_URL];
    char        title[BR_MAX_TITLE];
    br_node_t   nodes[BR_MAX_NODES];
    int         node_count;
    int         scroll;
    int         active;
    char        page_buf[BR_PAGE_BUF];
    int         page_len;
} br_tab_t;

typedef struct {
    br_tab_t    tabs[BR_MAX_TABS];
    int         tab_count;
    int         cur_tab;
    char        url_bar[BR_MAX_URL];
    int         url_editing;
    int         running;
} br_state_t;

void browser_run(void);
void browser_open_url(const char *url);

#endif
