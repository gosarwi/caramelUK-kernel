/* wincompat.c — WineCompat: слой совместимости с Windows PE32
 * CaramelUK v7 "Cupcake"
 *
 * Архитектура:
 *   1. pe_validate()  — проверить MZ+PE сигнатуры
 *   2. pe_load()      — загрузить секции по VirtualAddress
 *   3. resolve_imports() — заполнить IAT (Import Address Table)
 *      встроенными заглушками CaramelUK-функций
 *   4. Вызвать entry point (cdecl, argc/argv/envp)
 */
#include "wincompat.h"
#include "vfs.h"
#include "vga.h"
#include "util.h"
#include "ossdk.h"
#include "kmalloc.h"
#include "pit.h"
#include "sched.h"
#include <stdint.h>
#include <stddef.h>

/* ─── PE32 структуры ──────────────────────────────────────── */

typedef struct __attribute__((packed)) {
    uint16_t e_magic;      /* MZ */
    uint8_t  _skip[58];
    uint32_t e_lfanew;     /* смещение PE заголовка */
} mz_header_t;

typedef struct __attribute__((packed)) {
    uint16_t Machine;
    uint16_t NumberOfSections;
    uint32_t TimeDateStamp;
    uint32_t PointerToSymbolTable;
    uint32_t NumberOfSymbols;
    uint16_t SizeOfOptionalHeader;
    uint16_t Characteristics;
} pe_file_header_t;

typedef struct __attribute__((packed)) {
    uint16_t Magic;                  /* 0x010B для PE32 */
    uint8_t  MajorLinkerVersion;
    uint8_t  MinorLinkerVersion;
    uint32_t SizeOfCode;
    uint32_t SizeOfInitializedData;
    uint32_t SizeOfUninitializedData;
    uint32_t AddressOfEntryPoint;    /* RVA точки входа */
    uint32_t BaseOfCode;
    uint32_t BaseOfData;
    uint32_t ImageBase;              /* предпочтительный адрес загрузки */
    uint32_t SectionAlignment;
    uint32_t FileAlignment;
    uint16_t MajorOSVersion;
    uint16_t MinorOSVersion;
    uint16_t MajorImageVersion;
    uint16_t MinorImageVersion;
    uint16_t MajorSubsystemVersion;
    uint16_t MinorSubsystemVersion;
    uint32_t Win32VersionValue;
    uint32_t SizeOfImage;
    uint32_t SizeOfHeaders;
    uint32_t CheckSum;
    uint16_t Subsystem;
    uint16_t DllCharacteristics;
    uint32_t SizeOfStackReserve;
    uint32_t SizeOfStackCommit;
    uint32_t SizeOfHeapReserve;
    uint32_t SizeOfHeapCommit;
    uint32_t LoaderFlags;
    uint32_t NumberOfRvaAndSizes;
} pe_opt_header_t;

typedef struct __attribute__((packed)) {
    uint32_t VirtualAddress;
    uint32_t Size;
} pe_data_dir_t;

typedef struct __attribute__((packed)) {
    char     Name[8];
    uint32_t VirtualSize;
    uint32_t VirtualAddress;
    uint32_t SizeOfRawData;
    uint32_t PointerToRawData;
    uint32_t PointerToRelocations;
    uint32_t PointerToLinenumbers;
    uint16_t NumberOfRelocations;
    uint16_t NumberOfLinenumbers;
    uint32_t Characteristics;
} pe_section_t;

typedef struct __attribute__((packed)) {
    uint32_t OriginalFirstThunk;
    uint32_t TimeDateStamp;
    uint32_t ForwarderChain;
    uint32_t Name;             /* RVA к имени DLL */
    uint32_t FirstThunk;       /* RVA к IAT */
} pe_import_desc_t;

/* ─── Заглушки Win32 API ──────────────────────────────────── */
/* Эти функции вызываются вместо реальных DLL */

static uint32_t g_last_error = 0;
static uint8_t *g_image_base = NULL;  /* база загруженного образа */

/* Вспомогательная: вывод строки */
static void wc_puts(const char *s) { terminal_writeln(s ? s : ""); }
static void wc_put(const char *s)  { terminal_write(s ? s : ""); }
static void wc_putchar(char c)     { terminal_putchar(c); }

/* ── kernel32.dll ── */

/* HANDLE GetStdHandle(DWORD nStdHandle) */
static uint32_t stub_GetStdHandle(uint32_t h) {
    (void)h;
    return 1;  /* фиктивный дескриптор */
}

/* BOOL WriteConsoleA(HANDLE, const char*, DWORD, LPDWORD, LPVOID) */
static uint32_t stub_WriteConsoleA(uint32_t h, const char *buf,
                                   uint32_t n, uint32_t *written, void *r) {
    (void)h; (void)r;
    for (uint32_t i = 0; i < n; i++) terminal_putchar(buf[i]);
    if (written) *written = n;
    return 1;
}

/* BOOL WriteFile(HANDLE, const void*, DWORD, LPDWORD, LPOVERLAPPED) */
static uint32_t stub_WriteFile(uint32_t h, const uint8_t *buf,
                               uint32_t n, uint32_t *written, void *ov) {
    (void)h; (void)ov;
    for (uint32_t i = 0; i < n; i++) terminal_putchar((char)buf[i]);
    if (written) *written = n;
    return 1;
}

/* void ExitProcess(UINT uExitCode) */
static void stub_ExitProcess(uint32_t code) {
    terminal_set_color(VGA_YELLOW, VGA_BLACK);
    char nb[12]; kuitoa(code, nb, 10);
    terminal_write("[WineCompat] ExitProcess("); terminal_write(nb); terminal_writeln(")");
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
    /* Мягкий выход — просто возвращаем в оболочку */
    /* На реальном железе нужна longjmp/setjmp, здесь halt */
    while (1) __asm__ volatile("hlt");
}

/* void Sleep(DWORD dwMilliseconds) */
static void stub_Sleep(uint32_t ms) {
    sdk_sleep_ms(ms);
}

/* DWORD GetTickCount(void) */
static uint32_t stub_GetTickCount(void) {
    return sched_uptime_ticks() * 10; /* 100Hz → ms */
}

/* DWORD GetLastError(void) */
static uint32_t stub_GetLastError(void) { return g_last_error; }

/* void SetLastError(DWORD) */
static void stub_SetLastError(uint32_t e) { g_last_error = e; }

/* LPSTR GetCommandLineA(void) */
static uint32_t stub_GetCommandLineA(void) {
    return (uint32_t)(uintptr_t)"program.exe";
}

/* HANDLE HeapCreate / GetProcessHeap */
static uint32_t stub_GetProcessHeap(void) { return 0xDEAD1234; }

/* LPVOID HeapAlloc(HANDLE, DWORD, SIZE_T) */
static uint32_t stub_HeapAlloc(uint32_t heap, uint32_t flags, uint32_t size) {
    (void)heap; (void)flags;
    return (uint32_t)(uintptr_t)kmalloc(size);
}

/* BOOL HeapFree(HANDLE, DWORD, LPVOID) */
static uint32_t stub_HeapFree(uint32_t heap, uint32_t flags, uint32_t ptr) {
    (void)heap; (void)flags;
    if (ptr) kfree((void*)(uintptr_t)ptr);
    return 1;
}

/* ── msvcrt.dll ── */

/* int printf(const char*, ...) — упрощённо */
static uint32_t stub_printf(const char *fmt, ...) {
    /* Простая реализация без va_args (работает для puts-like вызовов) */
    terminal_write(fmt);
    return (uint32_t)kstrlen(fmt);
}

/* int puts(const char*) */
static uint32_t stub_puts(const char *s) {
    terminal_writeln(s ? s : "");
    return 1;
}

/* int putchar(int c) */
static uint32_t stub_putchar(uint32_t c) {
    terminal_putchar((char)c);
    return c;
}

/* void* malloc(size_t) */
static uint32_t stub_malloc(uint32_t size) {
    return (uint32_t)(uintptr_t)kmalloc(size);
}

/* void free(void*) */
static void stub_free(uint32_t ptr) {
    if (ptr) kfree((void*)(uintptr_t)ptr);
}

/* void* realloc(void*, size_t) — stub */
static uint32_t stub_realloc(uint32_t ptr, uint32_t size) {
    void *np = kmalloc(size);
    if (ptr && np) {
        /* Копируем старые данные (не знаем размер — копируем size байт) */
        kmemcpy(np, (void*)(uintptr_t)ptr, size);
        kfree((void*)(uintptr_t)ptr);
    }
    return (uint32_t)(uintptr_t)np;
}

/* size_t strlen(const char*) */
static uint32_t stub_strlen(const char *s) {
    return (uint32_t)kstrlen(s ? s : "");
}

/* int strcmp(const char*, const char*) */
static uint32_t stub_strcmp(const char *a, const char *b) {
    return (uint32_t)(int32_t)kstrcmp(a ? a : "", b ? b : "");
}

/* char* strcpy(char*, const char*) */
static uint32_t stub_strcpy(char *dst, const char *src) {
    if (dst && src) kstrcpy(dst, src);
    return (uint32_t)(uintptr_t)dst;
}

/* char* strcat(char*, const char*) */
static uint32_t stub_strcat(char *dst, const char *src) {
    if (dst && src) kstrcat(dst, src);
    return (uint32_t)(uintptr_t)dst;
}

/* void* memcpy(void*, const void*, size_t) */
static uint32_t stub_memcpy(void *dst, const void *src, uint32_t n) {
    if (dst && src) kmemcpy(dst, src, n);
    return (uint32_t)(uintptr_t)dst;
}

/* void* memset(void*, int, size_t) */
static uint32_t stub_memset(void *dst, uint32_t c, uint32_t n) {
    if (dst) kmemset(dst, (uint8_t)c, n);
    return (uint32_t)(uintptr_t)dst;
}

/* int memcmp(const void*, const void*, size_t) */
static uint32_t stub_memcmp(const void *a, const void *b, uint32_t n) {
    if (!a || !b) return 0;
    const uint8_t *pa = (const uint8_t*)a, *pb = (const uint8_t*)b;
    for (uint32_t i = 0; i < n; i++) {
        if (pa[i] != pb[i]) return (uint32_t)(int32_t)(pa[i] - pb[i]);
    }
    return 0;
}

/* void exit(int) */
static void stub_exit(uint32_t code) { stub_ExitProcess(code); }
static void stub_abort(void) {
    terminal_set_color(VGA_LIGHT_RED, VGA_BLACK);
    terminal_writeln("[WineCompat] abort() called");
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
    stub_ExitProcess(3);
}

/* ── user32.dll ── */

/* int MessageBoxA(HWND, LPCSTR, LPCSTR, UINT) */
static uint32_t stub_MessageBoxA(uint32_t hwnd, const char *text,
                                  const char *caption, uint32_t type) {
    (void)hwnd; (void)type;
    terminal_set_color(VGA_LIGHT_CYAN, VGA_BLACK);
    terminal_write("[MessageBox] ");
    if (caption) { terminal_write(caption); terminal_write(": "); }
    terminal_writeln(text ? text : "");
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
    return 1; /* IDOK */
}

/* ─── Таблица импортов ────────────────────────────────────── */
typedef struct {
    const char *dll;
    const char *func;
    uint32_t   stub_addr;  /* адрес заглушки */
} import_stub_t;

/* Макрос для удобного заполнения */
#define STUB(dll, fn) { dll, #fn, (uint32_t)(uintptr_t)stub_##fn }

static const import_stub_t import_table[] = {
    /* kernel32 */
    STUB("kernel32.dll", GetStdHandle),
    STUB("kernel32.dll", WriteConsoleA),
    STUB("kernel32.dll", WriteFile),
    STUB("kernel32.dll", ExitProcess),
    STUB("kernel32.dll", Sleep),
    STUB("kernel32.dll", GetTickCount),
    STUB("kernel32.dll", GetLastError),
    STUB("kernel32.dll", SetLastError),
    STUB("kernel32.dll", GetCommandLineA),
    STUB("kernel32.dll", GetProcessHeap),
    STUB("kernel32.dll", HeapAlloc),
    STUB("kernel32.dll", HeapFree),
    /* msvcrt */
    STUB("msvcrt.dll", printf),
    STUB("msvcrt.dll", puts),
    STUB("msvcrt.dll", putchar),
    STUB("msvcrt.dll", malloc),
    STUB("msvcrt.dll", free),
    STUB("msvcrt.dll", realloc),
    STUB("msvcrt.dll", strlen),
    STUB("msvcrt.dll", strcmp),
    STUB("msvcrt.dll", strcpy),
    STUB("msvcrt.dll", strcat),
    STUB("msvcrt.dll", memcpy),
    STUB("msvcrt.dll", memset),
    STUB("msvcrt.dll", memcmp),
    STUB("msvcrt.dll", exit),
    STUB("msvcrt.dll", abort),
    /* user32 */
    STUB("user32.dll", MessageBoxA),
    /* Дополнительные алиасы */
    { "kernel32.dll", "WriteConsoleW",    (uint32_t)(uintptr_t)stub_WriteConsoleA },
    { "kernel32.dll", "WriteFileW",       (uint32_t)(uintptr_t)stub_WriteFile },
    { "msvcrt.dll",   "_puts",            (uint32_t)(uintptr_t)stub_puts },
    { "msvcrt.dll",   "_printf",          (uint32_t)(uintptr_t)stub_printf },
    { "msvcrt.dll",   "_malloc",          (uint32_t)(uintptr_t)stub_malloc },
    { "msvcrt.dll",   "_free",            (uint32_t)(uintptr_t)stub_free },
    { "msvcrt.dll",   "_exit",            (uint32_t)(uintptr_t)stub_exit },
    { "user32.dll",   "MessageBoxW",      (uint32_t)(uintptr_t)stub_MessageBoxA },
    { NULL, NULL, 0 }
};
#undef STUB

/* ─── Поиск заглушки ─────────────────────────────────────── */
static uint32_t find_stub(const char *dll, const char *func) {
    for (int i = 0; import_table[i].dll; i++) {
        if (!kstrcmp(import_table[i].dll, dll) &&
            !kstrcmp(import_table[i].func, func))
            return import_table[i].stub_addr;
    }
    /* Возвращаем заглушку-заглушку которая просто возвращает 0 */
    return 0;
}

/* ─── Валидация PE32 ─────────────────────────────────────── */
int pe_validate(const uint8_t *buf, uint32_t size) {
    if (size < 64) return 0;
    const mz_header_t *mz = (const mz_header_t *)buf;
    if (mz->e_magic != 0x5A4D) return 0;         /* "MZ" */
    if (mz->e_lfanew + 4 > size) return 0;
    uint32_t pe_sig;
    kmemcpy(&pe_sig, buf + mz->e_lfanew, 4);
    if (pe_sig != PE_MAGIC) return 0;             /* "PE\0\0" */
    const pe_file_header_t *fh = (const pe_file_header_t *)(buf + mz->e_lfanew + 4);
    if (fh->Machine != PE_MACHINE_I386) return 0; /* только x86 */
    const pe_opt_header_t *oh = (const pe_opt_header_t *)(buf + mz->e_lfanew + 4 + sizeof(pe_file_header_t));
    if (oh->Magic != PE_OPT_MAGIC_PE32) return 0; /* только PE32, не PE32+ */
    return 1;
}

/* ─── Загрузка PE32 ──────────────────────────────────────── */
pe_load_result_t pe_load(const uint8_t *buf, uint32_t size) {
    pe_load_result_t res; kmemset(&res, 0, sizeof(res));

    if (!pe_validate(buf, size)) {
        kstrcpy(res.error, "Не валидный PE32 x86 файл");
        return res;
    }

    const mz_header_t *mz = (const mz_header_t *)buf;
    uint32_t pe_off = mz->e_lfanew;
    const pe_file_header_t *fh = (const pe_file_header_t *)(buf + pe_off + 4);
    const pe_opt_header_t  *oh = (const pe_opt_header_t *) (buf + pe_off + 4 + sizeof(pe_file_header_t));

    uint32_t image_size = oh->SizeOfImage;
    uint32_t image_base = oh->ImageBase;

    /* Аллоцируем память под образ */
    /* Используем фиксированный адрес 0x600000 (6MB) если ImageBase слишком низкий */
    uint32_t load_addr = image_base;
    if (load_addr < 0x400000 || load_addr > 0x1000000) load_addr = 0x600000;

    g_image_base = (uint8_t*)(uintptr_t)load_addr;
    kmemset(g_image_base, 0, image_size < 4*1024*1024 ? image_size : 4*1024*1024);

    /* Копируем заголовки */
    uint32_t hdr_size = oh->SizeOfHeaders;
    if (hdr_size > size) hdr_size = size;
    kmemcpy(g_image_base, buf, hdr_size);

    /* Загружаем секции */
    const pe_section_t *secs = (const pe_section_t *)(
        buf + pe_off + 4 + sizeof(pe_file_header_t) + fh->SizeOfOptionalHeader);

    for (int i = 0; i < fh->NumberOfSections; i++) {
        const pe_section_t *sec = &secs[i];
        if (sec->VirtualAddress + sec->VirtualSize > image_size) continue;
        if (sec->PointerToRawData + sec->SizeOfRawData > size) continue;

        uint8_t *dst = g_image_base + sec->VirtualAddress;
        if (sec->SizeOfRawData > 0) {
            kmemcpy(dst, buf + sec->PointerToRawData, sec->SizeOfRawData);
        }
        /* Обнуляем остаток VirtualSize (BSS) */
        if (sec->VirtualSize > sec->SizeOfRawData) {
            kmemset(dst + sec->SizeOfRawData, 0,
                    sec->VirtualSize - sec->SizeOfRawData);
        }
    }

    /* ── Разрешаем импорты (IAT) ── */
    /* DataDirectory[1] = Import Table */
    if (oh->NumberOfRvaAndSizes > 1) {
        const pe_data_dir_t *dd = (const pe_data_dir_t *)(
            (const uint8_t*)oh + sizeof(pe_opt_header_t));
        /* dd[0]=export, dd[1]=import */
        uint32_t import_rva  = dd[1].VirtualAddress;
        uint32_t import_size = dd[1].Size;

        if (import_rva && import_size) {
            pe_import_desc_t *imp = (pe_import_desc_t *)(g_image_base + import_rva);

            while (imp->Name != 0) {
                const char *dll_name = (const char *)(g_image_base + imp->Name);

                /* IAT (FirstThunk) — массив адресов функций */
                uint32_t *iat = (uint32_t *)(g_image_base + imp->FirstThunk);
                /* INT (OriginalFirstThunk) — массив Hint/Name RVA */
                uint32_t *hint_arr = (uint32_t *)(g_image_base +
                    (imp->OriginalFirstThunk ? imp->OriginalFirstThunk : imp->FirstThunk));

                while (*hint_arr) {
                    uint32_t entry = *hint_arr;
                    const char *func_name = NULL;

                    if (entry & 0x80000000) {
                        /* Import by ordinal — не поддерживаем, ставим 0 */
                        *iat = 0;
                    } else {
                        /* Import by name: entry = RVA к Hint/Name */
                        /* Структура: 2 байта hint + имя функции */
                        const uint8_t *hn = g_image_base + entry;
                        func_name = (const char *)(hn + 2);  /* пропускаем hint */
                        uint32_t stub = find_stub(dll_name, func_name);
                        *iat = stub;  /* 0 если не найдено */
                    }
                    iat++;
                    hint_arr++;
                }
                imp++;
            }
        }
    }

    /* ── Применяем релокации (если base не совпадает) ── */
    uint32_t delta = load_addr - image_base;
    if (delta && oh->NumberOfRvaAndSizes > 5) {
        const pe_data_dir_t *dd = (const pe_data_dir_t *)(
            (const uint8_t*)oh + sizeof(pe_opt_header_t));
        uint32_t reloc_rva  = dd[5].VirtualAddress;
        uint32_t reloc_size = dd[5].Size;

        if (reloc_rva && reloc_size) {
            uint8_t *reloc_base = g_image_base + reloc_rva;
            uint8_t *reloc_end  = reloc_base + reloc_size;
            uint8_t *p = reloc_base;
            while (p < reloc_end - 8) {
                uint32_t page_rva;
                uint32_t block_size;
                kmemcpy(&page_rva,    p, 4); p += 4;
                kmemcpy(&block_size,  p, 4); p += 4;
                if (!block_size) break;
                int entries = (int)(block_size - 8) / 2;
                for (int e = 0; e < entries; e++) {
                    uint16_t entry;
                    kmemcpy(&entry, p, 2); p += 2;
                    uint8_t type = (entry >> 12) & 0xF;
                    uint32_t offset = entry & 0xFFF;
                    if (type == 3) {  /* IMAGE_REL_BASED_HIGHLOW */
                        uint32_t *target = (uint32_t *)(g_image_base + page_rva + offset);
                        *target += delta;
                    }
                }
            }
        }
    }

    res.valid      = 1;
    res.entry      = load_addr + oh->AddressOfEntryPoint;
    res.image_base = load_addr;
    res.image_size = image_size;
    return res;
}

/* ─── Информация о PE32 ──────────────────────────────────── */
void wincompat_info(const uint8_t *buf, uint32_t size) {
    if (!pe_validate(buf, size)) {
        terminal_writeln("  Не валидный PE32 файл (нет MZ/PE сигнатуры или не x86)");
        return;
    }
    const mz_header_t *mz = (const mz_header_t *)buf;
    uint32_t pe_off = mz->e_lfanew;
    const pe_file_header_t *fh = (const pe_file_header_t *)(buf + pe_off + 4);
    const pe_opt_header_t  *oh = (const pe_opt_header_t *) (buf + pe_off + 4 + sizeof(pe_file_header_t));

    char tmp[16];
    terminal_set_color(VGA_LIGHT_CYAN, VGA_BLACK);
    terminal_writeln("╔══ PE32 Info ════════════════════════════════╗");
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);

    terminal_write("║  Machine:     ");
    terminal_writeln(fh->Machine == PE_MACHINE_I386 ? "i386 (x86 32-bit)" : "unknown");
    terminal_write("║  Sections:    ");
    kuitoa(fh->NumberOfSections, tmp, 10); terminal_writeln(tmp);
    terminal_write("║  ImageBase:   0x");
    kuitoa(oh->ImageBase, tmp, 16); terminal_writeln(tmp);
    terminal_write("║  ImageSize:   ");
    kuitoa(oh->SizeOfImage/1024, tmp, 10);
    terminal_write(tmp); terminal_writeln(" KB");
    terminal_write("║  EntryPoint:  0x");
    kuitoa(oh->AddressOfEntryPoint, tmp, 16); terminal_writeln(tmp);
    terminal_write("║  Subsystem:   ");
    if (oh->Subsystem == 3) terminal_writeln("Console");
    else if (oh->Subsystem == 2) terminal_writeln("Windows GUI");
    else { kuitoa(oh->Subsystem, tmp, 10); terminal_writeln(tmp); }

    /* Секции */
    terminal_set_color(VGA_LIGHT_CYAN, VGA_BLACK);
    terminal_writeln("╠══ Sections ════════════════════════════════╣");
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);

    const pe_section_t *secs = (const pe_section_t *)(
        buf + pe_off + 4 + sizeof(pe_file_header_t) + fh->SizeOfOptionalHeader);

    for (int i = 0; i < fh->NumberOfSections && i < 10; i++) {
        char name[9]; kmemcpy(name, secs[i].Name, 8); name[8]=0;
        terminal_write("║  "); terminal_write(name);
        for (int j = (int)kstrlen(name); j < 10; j++) terminal_putchar(' ');
        terminal_write("VA=0x"); kuitoa(secs[i].VirtualAddress, tmp, 16); terminal_write(tmp);
        terminal_write("  size="); kuitoa(secs[i].VirtualSize/1024, tmp, 10);
        terminal_write(tmp); terminal_writeln("KB");
    }

    terminal_set_color(VGA_LIGHT_CYAN, VGA_BLACK);
    terminal_writeln("╚════════════════════════════════════════════╝");
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
}

/* ─── Запуск PE32 из VFS ─────────────────────────────────── */
int wincompat_run(const char *path, int argc, char *argv[]) {
    terminal_set_color(VGA_YELLOW, VGA_BLACK);
    terminal_write("[WineCompat] Запуск: "); terminal_writeln(path);
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);

    /* Читаем файл */
    int fd = vfs_open((char*)path, O_RDONLY);
    if (fd < 0) {
        terminal_set_color(VGA_LIGHT_RED, VGA_BLACK);
        terminal_write("[WineCompat] Файл не найден: ");
        terminal_writeln(path);
        terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
        return -1;
    }

    /* Читаем файл — выделяем буфер через кучу, не static */
    /* Максимум 2MB на .exe */
    #define PE_MAX_SIZE (2*1024*1024)
    uint8_t *pe_buf = (uint8_t*)kmalloc(PE_MAX_SIZE);
    if (!pe_buf) {
        terminal_set_color(VGA_LIGHT_RED, VGA_BLACK);
        terminal_writeln("[WineCompat] Нет памяти для загрузки .exe");
        terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
        return -1;
    }
    int n = vfs_read(fd, pe_buf, PE_MAX_SIZE-1);
    vfs_close(fd);

    if (n <= 0) {
        terminal_set_color(VGA_LIGHT_RED, VGA_BLACK);
        terminal_writeln("[WineCompat] Ошибка чтения файла");
        terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
        kfree(pe_buf);
        return -2;
    }

    /* Валидация */
    if (!pe_validate(pe_buf, (uint32_t)n)) {
        terminal_set_color(VGA_LIGHT_RED, VGA_BLACK);
        terminal_writeln("[WineCompat] Не валидный PE32 файл");
        terminal_writeln("  Поддерживаются только x86 32-bit .exe (не x64, не .NET)");
        terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
        kfree(pe_buf);
        return -3;
    }

    /* Загрузка */
    pe_load_result_t res = pe_load(pe_buf, (uint32_t)n);
    kfree(pe_buf);  /* буфер больше не нужен после загрузки */
    if (!res.valid) {
        terminal_set_color(VGA_LIGHT_RED, VGA_BLACK);
        terminal_write("[WineCompat] Ошибка загрузки: ");
        terminal_writeln(res.error);
        terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
        return -4;
    }

    char tmp[16];
    terminal_write("[WineCompat] Образ загружен: 0x");
    kuitoa(res.image_base, tmp, 16); terminal_write(tmp);
    terminal_write("  entry=0x");
    kuitoa(res.entry, tmp, 16); terminal_writeln(tmp);
    terminal_write("[WineCompat] Запускаем... (argc=");
    kuitoa((uint32_t)argc, tmp, 10); terminal_write(tmp);
    terminal_writeln(")");
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);

    typedef int (*pe_entry_t)(int, char**, char**);
    pe_entry_t entry = (pe_entry_t)(uintptr_t)res.entry;

    char *envp[] = { "PATH=C:\\Windows\\System32", "OS=CaramelUK", NULL };

    int ret = 0;
    if (res.entry >= 0x100000 && res.entry < 0x8000000) {
        ret = entry(argc, argv, envp);
    } else {
        terminal_set_color(VGA_LIGHT_RED, VGA_BLACK);
        terminal_writeln("[WineCompat] Недопустимый entry point");
        terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
        return -5;
    }

    terminal_set_color(VGA_YELLOW, VGA_BLACK);
    terminal_write("[WineCompat] Завершено, код выхода: ");
    kuitoa((uint32_t)ret, tmp, 10); terminal_writeln(tmp);
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
    return ret;
}
