#ifndef WINCOMPAT_H
#define WINCOMPAT_H
/*
 * wincompat.h — WineCompat: слой совместимости с Windows PE32 (.exe)
 * CaramelUK v7 "Cupcake"
 *
 * Парсит PE32 заголовок, загружает секции, перехватывает импорты
 * из kernel32.dll, msvcrt.dll, user32.dll и заменяет их
 * нативными функциями CaramelUK.
 *
 * Поддерживаемые API:
 *   kernel32: GetStdHandle, WriteConsole, WriteFile, ReadFile,
 *             ExitProcess, Sleep, GetTickCount, GetCommandLine,
 *             GetLastError, SetLastError, HeapAlloc, HeapFree
 *   msvcrt:   printf, puts, putchar, gets, malloc, free, realloc,
 *             strlen, strcmp, strcpy, strcat, memcpy, memset, memcmp,
 *             exit, abort, fopen, fclose, fread, fwrite, fgets
 *   user32:   MessageBoxA (текстовый вывод)
 */

#include <stdint.h>
#include <stddef.h>

/* ── PE32 Константы ───────────────────────────────────────── */
#define PE_MAGIC          0x00004550   /* "PE\0\0" */
#define PE_OPT_MAGIC_PE32 0x010B
#define PE_MACHINE_I386   0x014C

/* Флаги характеристик PE */
#define PE_CHAR_EXEC      0x0002
#define PE_CHAR_32BIT     0x0100

/* Типы секций */
#define PE_SEC_CODE       0x20
#define PE_SEC_DATA       0x40
#define PE_SEC_BSS        0x80
#define PE_SEC_READABLE   0x40000000
#define PE_SEC_WRITEABLE  0x80000000
#define PE_SEC_EXECUTABLE 0x20000000

/* Результат загрузки */
typedef struct {
    int      valid;
    uint32_t entry;           /* точка входа (VA) */
    uint32_t image_base;      /* база образа */
    uint32_t image_size;      /* размер образа в памяти */
    char     error[128];
} pe_load_result_t;

/* ── Публичный API ────────────────────────────────────────── */

/* Проверить является ли буфер PE32 файлом */
int  pe_validate(const uint8_t *buf, uint32_t size);

/* Загрузить PE32, разрешить импорты, вернуть точку входа */
pe_load_result_t pe_load(const uint8_t *buf, uint32_t size);

/* Запустить PE32 из файла VFS */
int  wincompat_run(const char *path, int argc, char *argv[]);

/* Показать информацию о PE32 файле */
void wincompat_info(const uint8_t *buf, uint32_t size);

#endif
