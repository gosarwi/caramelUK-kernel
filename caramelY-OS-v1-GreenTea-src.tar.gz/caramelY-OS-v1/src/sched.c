/*  sched.c — Round-robin preemptive task scheduler for CaramelUK v3
 *
 *  - Fixed pool of TASK_MAX tasks (no dynamic alloc for task structs)
 *  - Each task gets its own 4KB stack (kmalloc'd)
 *  - PIT IRQ0 calls sched_tick() → context_switch() on ASM side
 *  - Priority: higher priority tasks run more ticks per quantum
 */
#include "sched.h"
#include "kmalloc.h"
#include "util.h"
#include "vga.h"
#include <stdint.h>

#define QUANTUM_BASE  2   /* ticks per quantum unit */

static task_t  task_pool[TASK_MAX];
static task_t *current_task  = 0;
static task_t *run_queue_head = 0;   /* circular singly-linked */
static uint32_t next_pid = 1;
static volatile uint32_t uptime_ticks = 0;

/* ── Helpers ───────────────────────────────────────────────── */
static task_t *alloc_task_slot(void) {
    for (int i = 0; i < TASK_MAX; i++)
        if (task_pool[i].state == TASK_UNUSED)
            return &task_pool[i];
    return NULL;
}

static void queue_add(task_t *t) {
    if (!run_queue_head) {
        run_queue_head = t;
        t->next = t;
        return;
    }
    /* Insert before head (tail → new → head) */
    task_t *tail = run_queue_head;
    while (tail->next != run_queue_head) tail = tail->next;
    tail->next = t;
    t->next = run_queue_head;
}

static void queue_remove(task_t *t) {
    if (!run_queue_head) return;
    if (run_queue_head == t && t->next == t) {
        run_queue_head = NULL;
        t->next = NULL;
        return;
    }
    task_t *prev = run_queue_head;
    while (prev->next != t && prev->next != run_queue_head)
        prev = prev->next;
    if (prev->next == t) {
        prev->next = t->next;
        if (run_queue_head == t)
            run_queue_head = t->next;
        t->next = NULL;
    }
}

/* ── Init ──────────────────────────────────────────────────── */
void sched_init(void) {
    kmemset(task_pool, 0, sizeof(task_pool));
    current_task   = NULL;
    run_queue_head = NULL;
    next_pid       = 1;
    uptime_ticks   = 0;

    /* Create idle task (pid=0, runs when nothing else is ready) */
    task_t *idle = &task_pool[0];
    idle->pid      = 0;
    kstrcpy(idle->name, "idle");
    idle->state    = TASK_READY;
    idle->priority = 1;
    idle->stack_base = NULL;  /* uses boot stack */

    /* Current context becomes idle — will be filled on first switch */
    current_task = idle;
    /* Don't put idle in run queue; we call it only when queue empty */
}

/* ── task_create ───────────────────────────────────────────── */
task_t *task_create(const char *name, task_fn_t fn, uint32_t priority) {
    task_t *t = alloc_task_slot();
    if (!t) return NULL;

    uint32_t *stack = (uint32_t *)kmalloc(TASK_STACK_SIZE);
    if (!stack) return NULL;

    t->pid        = next_pid++;
    kstrcpy(t->name, name);
    t->state      = TASK_READY;
    t->priority   = (priority < 1) ? 1 : (priority > 10) ? 10 : priority;
    t->stack_base = stack;
    t->stack_size = TASK_STACK_SIZE;
    t->ticks      = 0;
    t->exit_code  = 0;

    /* Set up initial stack frame for context_switch:
       The stack must look like context_switch() just pushed registers.
       On first switch, we want eip = fn.
       Stack grows down; set esp to top of allocated stack.
    */
    uint32_t *sp = stack + (TASK_STACK_SIZE / sizeof(uint32_t));

    /* Simulate the iret frame so the task starts with sti */
    *(--sp) = 0x00000202;           /* eflags: IF=1 */
    *(--sp) = (uint32_t)(uintptr_t)fn; /* eip = task function */
    /* pusha registers: edi,esi,ebp,esp,ebx,edx,ecx,eax */
    *(--sp) = 0; /* edi */
    *(--sp) = 0; /* esi */
    *(--sp) = (uint32_t)(uintptr_t)(stack + TASK_STACK_SIZE/sizeof(uint32_t)); /* ebp */
    *(--sp) = 0; /* esp placeholder */
    *(--sp) = 0; /* ebx */
    *(--sp) = 0; /* edx */
    *(--sp) = 0; /* ecx */
    *(--sp) = 0; /* eax */

    t->ctx.esp    = (uint32_t)(uintptr_t)sp;
    t->ctx.eip    = (uint32_t)(uintptr_t)fn;
    t->ctx.eflags = 0x00000202;

    queue_add(t);
    return t;
}

/* ── task_exit ─────────────────────────────────────────────── */
void task_exit(int code) {
    __asm__ volatile("cli");
    if (!current_task || current_task->pid == 0) return;
    current_task->state     = TASK_ZOMBIE;
    current_task->exit_code = code;
    queue_remove(current_task);
    /* Free stack */
    if (current_task->stack_base)
        kfree(current_task->stack_base);
    current_task->stack_base = NULL;
    current_task->state = TASK_UNUSED;
    __asm__ volatile("sti");
    task_yield();
}

/* ── task_yield ────────────────────────────────────────────── */
void task_yield(void) {
    __asm__ volatile("int $0x20");   /* trigger PIT IRQ (INT 32) */
}

/* ── task_block / unblock ──────────────────────────────────── */
void task_block(void) {
    __asm__ volatile("cli");
    if (current_task) {
        current_task->state = TASK_BLOCKED;
        queue_remove(current_task);
    }
    __asm__ volatile("sti");
    task_yield();
}

void task_unblock(task_t *t) {
    if (!t || t->state != TASK_BLOCKED) return;
    t->state = TASK_READY;
    queue_add(t);
}

/* ── sched_tick — called from PIT ISR ─────────────────────── */
static uint32_t quantum_counter = 0;

void sched_tick(void) {
    uptime_ticks++;

    if (!run_queue_head) return;   /* only idle */

    uint32_t quantum = current_task->priority * QUANTUM_BASE;
    if (++quantum_counter < quantum) return;
    quantum_counter = 0;

    /* Find next READY task in circular queue */
    task_t *start = run_queue_head;
    task_t *next  = start;

    do {
        if (next->state == TASK_READY && next != current_task)
            break;
        next = next->next;
    } while (next != start);

    if (next == current_task || next->state != TASK_READY) return;

    /* Perform context switch */
    task_t *old = current_task;
    if (old->state == TASK_RUNNING) old->state = TASK_READY;

    current_task        = next;
    current_task->state = TASK_RUNNING;
    current_task->ticks++;

    context_switch(&old->ctx, &current_task->ctx);
}

/* ── Getters ───────────────────────────────────────────────── */
task_t *sched_current(void) { return current_task; }
uint32_t sched_uptime_ticks(void) { return uptime_ticks; }

/* ── ps — print task list ──────────────────────────────────── */
static const char *state_name(task_state_t s) {
    switch (s) {
        case TASK_READY:   return "ready  ";
        case TASK_RUNNING: return "running";
        case TASK_BLOCKED: return "blocked";
        case TASK_ZOMBIE:  return "zombie ";
        default:           return "unused ";
    }
}

void sched_print_tasks(void) {
    char buf[16];
    terminal_writeln("PID  STATE    PRI  TICKS  NAME");
    terminal_writeln("---  -------  ---  -----  ----");
    for (int i = 0; i < TASK_MAX; i++) {
        task_t *t = &task_pool[i];
        if (t->state == TASK_UNUSED) continue;
        kuitoa(t->pid,      buf, 10); terminal_write(buf);
        terminal_write("    ");
        terminal_write(state_name(t->state));
        terminal_write("  ");
        kuitoa(t->priority, buf, 10); terminal_write(buf);
        terminal_write("    ");
        kuitoa(t->ticks,    buf, 10); terminal_write(buf);
        terminal_write("  ");
        terminal_writeln(t->name);
    }
}
