/* localai.c — CaramelUK v9 Local AI
 * Движок для работы с локальными языковыми моделями форматов .dict и .crml
 */
#include "localai.h"
#include "vfs.h"
#include "vga.h"
#include "keyboard.h"
#include "util.h"
#include <stdint.h>
#include <stddef.h>

ai_model_t g_ai;

/* ── Нормализация строки ──────────────────────────────────── */
void ai_normalize(const char *in, char *out, int out_sz) {
    int i = 0, o = 0;
    /* пропустить ведущие пробелы */
    while (in[i] == ' ' || in[i] == '\t') i++;
    int last_space = 0;
    while (in[i] && o < out_sz - 1) {
        char c = in[i++];
        if (c >= 'A' && c <= 'Z') c = c + 32;
        if (c == ' ' || c == '\t' || c == '\r') {
            if (!last_space && o > 0) { out[o++] = ' '; last_space = 1; }
        } else {
            out[o++] = c;
            last_space = 0;
        }
    }
    /* убрать хвостовой пробел */
    if (o > 0 && out[o-1] == ' ') o--;
    out[o] = 0;
}

/* ── Похожесть строк (0-100) ──────────────────────────────── */
/* Простой алгоритм: количество совпадающих слов / макс слов */
int ai_similarity(const char *a, const char *b) {
    if (!a || !b || !*a || !*b) return 0;
    /* Точное совпадение */
    if (kstrcmp(a, b) == 0) return 100;
    /* Подстрока */
    if (kstrstr(b, a)) return 80;
    if (kstrstr(a, b)) return 70;
    /* Подсчёт общих слов */
    char wa[AI_MAX_STR], wb[AI_MAX_STR];
    kstrncpy(wa, a, AI_MAX_STR-1); wa[AI_MAX_STR-1]=0;
    kstrncpy(wb, b, AI_MAX_STR-1); wb[AI_MAX_STR-1]=0;
    int match = 0, total = 0;
    /* токенизируем a по пробелам */
    char *pa = wa;
    while (*pa) {
        char *end = pa;
        while (*end && *end != ' ') end++;
        char sv = *end; *end = 0;
        if (kstrlen(pa) >= 2) {
            total++;
            if (kstrstr(wb, pa)) match++;
        }
        *end = sv;
        if (!*end) break;
        pa = end + 1;
    }
    if (total == 0) return 0;
    return (match * 100) / total;
}

/* ── Парсинг одной пары "вопрос -> ответ" ─────────────────── */
static int parse_pair(char *line, ai_pair_t *pair) {
    /* пропускаем комментарии и пустые строки */
    char *p = line;
    while (*p == ' ' || *p == '\t') p++;
    if (*p == '#' || *p == ';' || *p == 0) return 0;

    char *arrow = kstrstr(p, "->");
    if (!arrow) return 0;

    /* вопрос */
    *arrow = 0;
    char *q = p;
    /* убрать хвостовые пробелы у вопроса */
    int ql = (int)kstrlen(q);
    while (ql > 0 && (q[ql-1]==' '||q[ql-1]=='\t')) { q[--ql]=0; }
    kstrncpy(pair->question, q, AI_MAX_STR-1);

    /* ответ */
    char *a = arrow + 2;
    while (*a == ' ' || *a == '\t') a++;
    int al = (int)kstrlen(a);
    while (al > 0 && (a[al-1]=='\n'||a[al-1]=='\r'||a[al-1]==' ')) { a[--al]=0; }
    kstrncpy(pair->answer, a, AI_MAX_STR-1);

    pair->weight = 50;
    return (pair->question[0] && pair->answer[0]) ? 1 : 0;
}

/* ── Загрузка модели ──────────────────────────────────────── */
int ai_load(const char *path) {
    int fd = vfs_open(path, O_RDONLY);
    if (fd < 0) {
        terminal_set_color(VGA_LIGHT_RED, VGA_BLACK);
        terminal_write("ai: не найден файл: "); terminal_writeln(path);
        terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
        return -1;
    }

    static uint8_t buf[AI_MAX_MODEL_SZ];
    int n = vfs_read(fd, buf, sizeof(buf)-1);
    vfs_close(fd);
    if (n <= 0) return -2;
    buf[n] = 0;

    /* Сброс состояния */
    ai_unload();
    kstrncpy(g_ai.path, path, 127);
    g_ai.pair_count = 0;
    g_ai.questions_asked = 0;
    g_ai.matches_found   = 0;

    /* Определить формат */
    if (kstrncmp((char*)buf, "CRML1", 5) == 0) {
        g_ai.fmt = AI_FMT_CRML;
    } else if (kstrncmp((char*)buf, "BRAIN1", 6) == 0) {
        g_ai.fmt = AI_FMT_BRAIN;
    } else {
        g_ai.fmt = AI_FMT_DICT;
    }

    /* Имя по умолчанию из имени файла */
    const char *slash = kstrrchr(path, '/');
    kstrncpy(g_ai.name, slash ? slash+1 : path, 63);
    kstrcpy(g_ai.lang, "mixed");
    kstrcpy(g_ai.prompt, "Привет! Я локальная AI модель CaramelUK.");

    /* Парсим строки */
    char *cur = (char*)buf;
    int in_data = (g_ai.fmt == AI_FMT_DICT); /* .dict сразу читает данные */

    while (*cur && g_ai.pair_count < AI_MAX_PAIRS) {
        /* Найти конец строки */
        char *eol = cur;
        while (*eol && *eol != '\n') eol++;
        char sv = *eol; *eol = 0;

        char *line = cur;
        /* пропустить пробелы в начале */
        while (*line == ' ' || *line == '\t') line++;

        if (g_ai.fmt == AI_FMT_CRML) {
            if (kstrcmp(line, "---") == 0) {
                in_data = 1;
            } else if (!in_data) {
                /* Заголовочные поля */
                if (kstrncmp(line, "name=", 5) == 0)
                    kstrncpy(g_ai.name, line+5, 63);
                else if (kstrncmp(line, "lang=", 5) == 0)
                    kstrncpy(g_ai.lang, line+5, 7);
                else if (kstrncmp(line, "prompt=", 7) == 0)
                    kstrncpy(g_ai.prompt, line+7, 255);
            }
        }

        if (in_data && *line && *line != '#') {
            ai_pair_t pair;
            kmemset(&pair, 0, sizeof(pair));
            if (parse_pair(line, &pair)) {
                g_ai.pairs[g_ai.pair_count++] = pair;
            }
        }

        *eol = sv;
        cur = (*eol == '\n') ? eol+1 : eol;
        if (!*cur) break;
    }

    g_ai.loaded = 1;
    return g_ai.pair_count;
}

/* ── Выгрузка ─────────────────────────────────────────────── */
void ai_unload(void) {
    kmemset(&g_ai, 0, sizeof(g_ai));
    g_ai.loaded = 0;
}

/* ── Задать вопрос ────────────────────────────────────────── */
int ai_ask(const char *question, char *out, int out_sz) {
    if (!g_ai.loaded || g_ai.pair_count == 0) {
        kstrncpy(out, "Модель не загружена. Используйте 'ai load <путь>'.", out_sz-1);
        return 0;
    }
    g_ai.questions_asked++;

    /* Нормализовать вопрос */
    char norm_q[AI_MAX_STR];
    ai_normalize(question, norm_q, AI_MAX_STR);

    /* Найти лучшее совпадение */
    int best_score = 0;
    int best_idx   = -1;
    int default_idx = -1;

    for (int i = 0; i < g_ai.pair_count; i++) {
        const char *pq = g_ai.pairs[i].question;
        /* Специальный ключ "default" — ответ по умолчанию */
        if (kstrcmp(pq, "default") == 0 || kstrcmp(pq, "Default") == 0) {
            default_idx = i;
            continue;
        }
        char norm_pq[AI_MAX_STR];
        ai_normalize(pq, norm_pq, AI_MAX_STR);
        int score = ai_similarity(norm_q, norm_pq);
        if (score > best_score) {
            best_score = score;
            best_idx   = i;
        }
    }

    /* Порог совпадения — 35% */
    if (best_idx >= 0 && best_score >= 35) {
        kstrncpy(out, g_ai.pairs[best_idx].answer, out_sz-1);
        out[out_sz-1] = 0;
        g_ai.matches_found++;
        return 1;
    }

    /* Дефолтный ответ */
    if (default_idx >= 0) {
        kstrncpy(out, g_ai.pairs[default_idx].answer, out_sz-1);
    } else {
        kstrncpy(out, "Не знаю ответа на этот вопрос.", out_sz-1);
    }
    out[out_sz-1] = 0;
    return 0;
}

/* ── Информация о модели ──────────────────────────────────── */
void ai_info(void) {
    const color_scheme_t *s = terminal_current_scheme();
    terminal_set_color(s->header_fg, s->normal_bg);
    terminal_writeln("── Информация о AI модели ──────────────────────");
    terminal_set_color(s->normal_fg, s->normal_bg);
    if (!g_ai.loaded) {
        terminal_writeln("  Модель не загружена.");
        return;
    }
    char buf[32];
    terminal_write("  Имя:      "); terminal_writeln(g_ai.name);
    terminal_write("  Файл:     "); terminal_writeln(g_ai.path);
    terminal_write("  Язык:     "); terminal_writeln(g_ai.lang);
    terminal_write("  Формат:   ");
    terminal_writeln(g_ai.fmt==AI_FMT_CRML?"CRML1":g_ai.fmt==AI_FMT_BRAIN?"BRAIN1":"DICT");
    terminal_write("  Промпт:   "); terminal_writeln(g_ai.prompt);
    kuitoa(g_ai.pair_count, buf, 10);
    terminal_write("  Пар:      "); terminal_writeln(buf);
    kuitoa(g_ai.questions_asked, buf, 10);
    terminal_write("  Вопросов: "); terminal_writeln(buf);
    kuitoa(g_ai.matches_found, buf, 10);
    terminal_write("  Совпало:  "); terminal_writeln(buf);
    terminal_writeln("────────────────────────────────────────────────");
}

/* ── Интерактивный чат ────────────────────────────────────── */
/* Объявляем readline_v9 как extern, она определена в kernel.c */
extern void readline_v9(char *out, int maxlen);

void ai_chat_loop(void) {
    const color_scheme_t *s = terminal_current_scheme();
    if (!g_ai.loaded) {
        terminal_set_color(s->warn_fg, s->normal_bg);
        terminal_writeln("ai: модель не загружена. Используйте 'ai load <путь>'.");
        terminal_set_color(s->normal_fg, s->normal_bg);
        return;
    }

    terminal_set_color(s->header_fg, s->normal_bg);
    terminal_write("── Чат с ");
    terminal_write(g_ai.name);
    terminal_writeln(" ─────────────────────────────");
    terminal_set_color(s->dim_fg, s->normal_bg);
    terminal_write("  Язык: "); terminal_write(g_ai.lang);
    terminal_writeln("  |  Выход: 'exit' или Ctrl+C");
    terminal_writeln("─────────────────────────────────────────────────");
    terminal_set_color(s->success_fg, s->normal_bg);
    terminal_write("AI: ");
    terminal_set_color(s->normal_fg, s->normal_bg);
    terminal_writeln(g_ai.prompt);
    terminal_writeln("");

    static char input[512];
    static char answer[AI_MAX_STR];

    while (1) {
        /* Промпт пользователя */
        terminal_set_color(s->prompt_fg, s->normal_bg);
        terminal_write("Вы: ");
        terminal_set_color(s->normal_fg, s->normal_bg);

        readline_v9(input, 511);

        if (!input[0]) continue;
        if (kstrcmp(input, "exit") == 0 ||
            kstrcmp(input, "quit") == 0 ||
            kstrcmp(input, "выход") == 0) {
            terminal_set_color(s->dim_fg, s->normal_bg);
            terminal_writeln("Чат завершён.");
            terminal_set_color(s->normal_fg, s->normal_bg);
            break;
        }
        if (kstrcmp(input, "info") == 0) { ai_info(); continue; }
        if (kstrcmp(input, "help") == 0 || kstrcmp(input, "помощь") == 0) {
            terminal_writeln("Команды чата: exit/выход — выйти, info — инфо о модели");
            continue;
        }

        /* Получить ответ */
        int matched = ai_ask(input, answer, AI_MAX_STR);
        terminal_set_color(matched ? s->success_fg : s->warn_fg, s->normal_bg);
        terminal_write("AI: ");
        terminal_set_color(s->normal_fg, s->normal_bg);
        terminal_writeln(answer);
    }
}

/* ── Создать модель интерактивно ──────────────────────────── */
int ai_create_interactive(const char *path) {
    const color_scheme_t *s = terminal_current_scheme();
    terminal_set_color(s->header_fg, s->normal_bg);
    terminal_writeln("── Создание новой AI модели (.crml) ─────────────");
    terminal_set_color(s->normal_fg, s->normal_bg);

    static char namebuf[64], langbuf[16], promptbuf[256];
    static char line[512];

    terminal_write("Название модели: ");
    readline_v9(namebuf, 63);
    if (!namebuf[0]) kstrcpy(namebuf, "MyBot");

    terminal_write("Язык (ru/en/mixed): ");
    readline_v9(langbuf, 15);
    if (!langbuf[0]) kstrcpy(langbuf, "mixed");

    terminal_write("Системный промпт: ");
    readline_v9(promptbuf, 255);
    if (!promptbuf[0]) kstrcpy(promptbuf, "Привет! Я готов помочь.");

    /* Собираем файл в буфер */
    static char filebuf[AI_MAX_MODEL_SZ];
    int flen = 0;
    flen += ksnprintf(filebuf + flen, AI_MAX_MODEL_SZ - flen,
        "CRML1\nname=%s\nlang=%s\nprompt=%s\n---\n",
        namebuf, langbuf, promptbuf);

    terminal_set_color(s->dim_fg, s->normal_bg);
    terminal_writeln("Введите пары вопрос -> ответ. Пустая строка — завершить.");
    terminal_set_color(s->normal_fg, s->normal_bg);

    int count = 0;
    while (flen < AI_MAX_MODEL_SZ - 512) {
        char qbuf[AI_MAX_STR], abuf[AI_MAX_STR];
        terminal_set_color(s->accent_fg, s->normal_bg);
        terminal_write("Вопрос: "); terminal_set_color(s->normal_fg, s->normal_bg);
        readline_v9(qbuf, AI_MAX_STR-1);
        if (!qbuf[0]) break;

        terminal_set_color(s->accent_fg, s->normal_bg);
        terminal_write("Ответ:  "); terminal_set_color(s->normal_fg, s->normal_bg);
        readline_v9(abuf, AI_MAX_STR-1);
        if (!abuf[0]) break;

        flen += ksnprintf(line, 511, "%s -> %s\n", qbuf, abuf);
        kstrncat(filebuf, line, AI_MAX_MODEL_SZ - flen - 1);
        flen += (int)kstrlen(line);
        count++;
    }

    /* Добавить дефолтный ответ если нет */
    if (flen < AI_MAX_MODEL_SZ - 128)
        flen += ksnprintf(filebuf + flen, AI_MAX_MODEL_SZ - flen,
            "default -> Я не знаю ответа на этот вопрос.\n");

    /* Записать файл */
    int fd = vfs_open(path, O_WRONLY|O_CREAT|O_TRUNC);
    if (fd < 0) {
        terminal_set_color(VGA_LIGHT_RED, VGA_BLACK);
        terminal_writeln("ai: не удалось создать файл");
        terminal_set_color(s->normal_fg, s->normal_bg);
        return -1;
    }
    vfs_write(fd, (uint8_t*)filebuf, (uint32_t)flen);
    vfs_close(fd);

    terminal_set_color(s->success_fg, s->normal_bg);
    terminal_write("Модель создана: "); terminal_writeln(path);
    char nbuf[16]; kuitoa((uint32_t)count, nbuf, 10);
    terminal_write("Пар: "); terminal_writeln(nbuf);
    terminal_set_color(s->normal_fg, s->normal_bg);
    return count;
}
