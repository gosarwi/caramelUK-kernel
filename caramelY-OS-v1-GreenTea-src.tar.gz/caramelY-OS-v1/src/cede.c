/* cede.c — CaramelUK .cede package manager v2
 * Формат v2: magic 0xCEDE0005, 8 типов секций, совместимость с v1
 */
#include "cede.h"
#include "elf.h"
#include "vfs.h"
#include "util.h"
#include "vga.h"
#include "config.h"
#include <stdint.h>
#include <stddef.h>

/* ── Контрольная сумма (XOR32 по 4 байта) ───────────────── */
uint32_t cede_checksum(const uint8_t *data, uint32_t size) {
    uint32_t crc = 0xDEADBEEF;
    for (uint32_t i = 0; i + 3 < size; i += 4) {
        uint32_t word;
        kmemcpy(&word, data + i, 4);
        crc ^= word;
        /* простое перемешивание */
        crc = (crc << 13) | (crc >> 19);
        crc ^= 0xA5A5A5A5;
    }
    /* остаток */
    for (uint32_t i = size & ~3u; i < size; i++)
        crc ^= (uint32_t)data[i] << ((i & 3) * 8);
    return crc;
}

/* ── Имя типа секции ─────────────────────────────────────── */
static const char *sec_type_name(uint8_t t) {
    switch (t) {
        case CEDE_SEC_ELF:  return "ELF   ";
        case CEDE_SEC_DATA: return "DATA  ";
        case CEDE_SEC_CONF: return "CONF  ";
        case CEDE_SEC_INIT: return "INIT  ";
        case CEDE_SEC_LIB:  return "LIB   ";
        case CEDE_SEC_ICON: return "ICON  ";
        case CEDE_SEC_MAN:  return "MAN   ";
        case CEDE_SEC_RES:  return "RES   ";
        default:            return "UNK   ";
    }
}

/* ── Parse ───────────────────────────────────────────────── */
int cede_parse(cede_pkg_t *pkg, const uint8_t *buf, uint32_t size) {
    if (!buf || size < sizeof(cede_header_t)) return -1;

    kmemcpy(&pkg->hdr, buf, sizeof(cede_header_t));
    pkg->v1_compat = 0;

    /* Поддержка обоих версий */
    if (pkg->hdr.magic == CEDE_MAGIC_V1) {
        pkg->v1_compat = 1;
        /* v1 совместима по структуре заголовка, только magic другой */
    } else if (pkg->hdr.magic != CEDE_MAGIC) {
        return -2;  /* неизвестный формат */
    }

    if (pkg->hdr.n_sections > 16) return -4;

    /* Читаем дескрипторы секций */
    const uint8_t *p = buf + sizeof(cede_header_t);
    for (uint32_t i = 0; i < pkg->hdr.n_sections; i++) {
        if ((size_t)(p - buf) + sizeof(cede_section_t) > size) return -5;
        kmemcpy(&pkg->sections[i], p, sizeof(cede_section_t));
        p += sizeof(cede_section_t);
    }

    /* Проверяем смещения секций */
    for (uint32_t i = 0; i < pkg->hdr.n_sections; i++) {
        if (pkg->sections[i].offset + pkg->sections[i].size > size) return -6;
    }

    pkg->data      = buf;
    pkg->data_size = size;
    return 0;
}

/* ── Info ────────────────────────────────────────────────── */
void cede_info(const cede_pkg_t *pkg) {
    char buf[16];
    terminal_set_color(VGA_LIGHT_CYAN, VGA_BLACK);
    terminal_writeln("╔══ .cede Package Info ══════════════════════╗");
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);

    #define FIELD(label, val) \
        terminal_write("║  " label ": "); terminal_write(val); terminal_writeln("")

    FIELD("Name       ", pkg->hdr.pkg_name);
    FIELD("Version    ", pkg->hdr.pkg_version);
    FIELD("Author     ", pkg->hdr.pkg_author);
    FIELD("Description", pkg->hdr.pkg_description);
    if (pkg->hdr.pkg_depends[0])
        FIELD("Depends    ", pkg->hdr.pkg_depends);
    if (pkg->hdr.pkg_license[0])
        FIELD("License    ", pkg->hdr.pkg_license);
    if (pkg->hdr.pkg_homepage[0])
        FIELD("Homepage   ", pkg->hdr.pkg_homepage);
    #undef FIELD

    terminal_write("║  Format   : .cede v");
    kuitoa(pkg->v1_compat ? 1 : (uint32_t)pkg->hdr.cede_version, buf, 10);
    terminal_write(buf);
    if (pkg->v1_compat) terminal_write(" (legacy, auto-upgraded)");
    terminal_writeln("");

    terminal_write("║  Sections : ");
    kuitoa(pkg->hdr.n_sections, buf, 10); terminal_writeln(buf);
    terminal_write("║  Size     : ");
    kuitoa(pkg->hdr.install_size, buf, 10);
    terminal_write(buf); terminal_writeln(" bytes");

    terminal_set_color(VGA_LIGHT_CYAN, VGA_BLACK);
    terminal_writeln("╠══ Sections ════════════════════════════════╣");
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);

    for (uint32_t i = 0; i < pkg->hdr.n_sections; i++) {
        const cede_section_t *s = &pkg->sections[i];
        if (s->flags & CEDE_FLAG_HIDDEN) continue;
        terminal_write("║  [");
        kuitoa(i, buf, 10); terminal_write(buf);
        terminal_write("] ");
        terminal_write(sec_type_name(s->type));
        if (s->name[0]) { terminal_write(" '"); terminal_write(s->name); terminal_write("'"); }
        terminal_write("  ");
        if (s->dest_path[0]) terminal_write(s->dest_path);
        terminal_write("  ");
        kuitoa(s->size, buf, 10); terminal_write(buf);
        terminal_write("B");
        if (s->flags & CEDE_FLAG_EXEC)     terminal_write(" [exec]");
        if (s->flags & CEDE_FLAG_COMPRESS) terminal_write(" [compressed]");
        if (s->flags & CEDE_FLAG_OPTIONAL) terminal_write(" [optional]");
        terminal_writeln("");
    }

    terminal_set_color(VGA_LIGHT_CYAN, VGA_BLACK);
    terminal_writeln("╚════════════════════════════════════════════╝");
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
}

/* ── Установка одной секции ──────────────────────────────── */
static int install_section(const cede_pkg_t *pkg, uint32_t i) {
    const cede_section_t *sec = &pkg->sections[i];
    const uint8_t *sdata = pkg->data + sec->offset;

    if (sec->flags & CEDE_FLAG_OPTIONAL) {
        /* пропускаем опциональные если нет места */
    }

    switch (sec->type) {
        case CEDE_SEC_ELF:
        case CEDE_SEC_DATA:
        case CEDE_SEC_LIB: {
            if (!sec->dest_path[0]) return 0;
            int fd = vfs_open(sec->dest_path, O_WRONLY | O_CREAT | O_TRUNC);
            if (fd < 0) {
                terminal_write("  [!] Не удалось создать: ");
                terminal_writeln(sec->dest_path);
                return -1;
            }
            vfs_write(fd, sdata, sec->size);
            vfs_close(fd);
            terminal_write("  [+] "); terminal_writeln(sec->dest_path);
            return 0;
        }

        case CEDE_SEC_CONF: {
            char cfgpath[128];
            kstrcpy(cfgpath, CFG_ROOT "/");
            /* dest_path уже содержит имя файла */
            kstrcat(cfgpath, sec->dest_path[0] ? sec->dest_path : pkg->hdr.pkg_name);
            if (!kstrstr(cfgpath, ".conf")) kstrcat(cfgpath, ".conf");
            int fd = vfs_open(cfgpath, O_WRONLY | O_CREAT | O_TRUNC);
            if (fd >= 0) {
                vfs_write(fd, sdata, sec->size);
                vfs_close(fd);
                terminal_write("  [C] "); terminal_writeln(cfgpath);
            }
            return 0;
        }

        case CEDE_SEC_MAN: {
            char manpath[128];
            kstrcpy(manpath, "/uiu/etc/man/");
            kstrcat(manpath, sec->dest_path[0] ? sec->dest_path : pkg->hdr.pkg_name);
            int fd = vfs_open(manpath, O_WRONLY | O_CREAT | O_TRUNC);
            if (fd >= 0) {
                vfs_write(fd, sdata, sec->size);
                vfs_close(fd);
                terminal_write("  [M] "); terminal_writeln(manpath);
            }
            return 0;
        }

        case CEDE_SEC_ICON: {
            char iconpath[128];
            kstrcpy(iconpath, "/uiu/etc/icons/");
            kstrcat(iconpath, pkg->hdr.pkg_name);
            kstrcat(iconpath, ".icon");
            /* Создаём папку если нужно */
            vfs_mkdir("/uiu/etc/icons");
            int fd = vfs_open(iconpath, O_WRONLY | O_CREAT | O_TRUNC);
            if (fd >= 0) { vfs_write(fd, sdata, sec->size); vfs_close(fd); }
            terminal_write("  [I] "); terminal_writeln(iconpath);
            return 0;
        }

        case CEDE_SEC_RES: {
            char respath[128];
            kstrcpy(respath, "/uiu/etc/res/");
            vfs_mkdir("/uiu/etc/res");
            kstrcat(respath, sec->dest_path[0] ? sec->dest_path : "resource");
            int fd = vfs_open(respath, O_WRONLY | O_CREAT | O_TRUNC);
            if (fd >= 0) { vfs_write(fd, sdata, sec->size); vfs_close(fd); }
            terminal_write("  [R] "); terminal_writeln(respath);
            return 0;
        }

        case CEDE_SEC_INIT: {
            terminal_writeln("  [*] Выполняю скрипт установки...");
            /* Выполняем строки скрипта */
            const char *p = (const char *)sdata;
            uint32_t pos = 0;
            while (pos < sec->size) {
                /* Собираем строку */
                char line[256]; int li = 0;
                while (pos < sec->size && p[pos] != '\n' && li < 255)
                    line[li++] = p[pos++];
                line[li] = 0;
                if (p[pos] == '\n') pos++;
                /* Пропускаем пустые и комментарии */
                char *trimmed = line;
                while (*trimmed == ' ' || *trimmed == '\t') trimmed++;
                if (!trimmed[0] || trimmed[0] == '#') continue;
                terminal_write("      $ "); terminal_writeln(trimmed);
                /* Реальное выполнение через VFS — mkdir, echo, cp */
                if (kstrncmp(trimmed, "mkdir ", 6) == 0)
                    vfs_mkdir(trimmed + 6);
                else if (kstrncmp(trimmed, "echo ", 5) == 0)
                    terminal_writeln(trimmed + 5);
            }
            return 0;
        }

        default:
            terminal_write("  [?] Неизвестный тип секции: ");
            char nb[8]; kuitoa(sec->type, nb, 10);
            terminal_writeln(nb);
            return 0;
    }
}

/* ── Install ─────────────────────────────────────────────── */
int cede_install(const cede_pkg_t *pkg) {
    terminal_set_color(VGA_LIGHT_CYAN, VGA_BLACK);
    terminal_write("Установка: ");
    terminal_write(pkg->hdr.pkg_name);
    terminal_write(" v"); terminal_writeln(pkg->hdr.pkg_version);
    if (pkg->hdr.pkg_description[0]) {
        terminal_write("  "); terminal_writeln(pkg->hdr.pkg_description);
    }
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);

    /* Проверяем контрольную сумму */
    if (pkg->hdr.checksum != 0) {
        uint32_t calc = cede_checksum(pkg->data, pkg->data_size);
        if (calc != pkg->hdr.checksum) {
            terminal_set_color(VGA_LIGHT_RED, VGA_BLACK);
            terminal_writeln("  [!] Предупреждение: контрольная сумма не совпадает!");
            terminal_writeln("      Пакет может быть повреждён. Продолжаю...");
            terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
        } else {
            terminal_writeln("  [✓] Контрольная сумма OK");
        }
    }

    int errors = 0;
    for (uint32_t i = 0; i < pkg->hdr.n_sections; i++) {
        if (install_section(pkg, i) < 0) errors++;
    }

    /* Записываем в БД пакетов */
    cfg_set(&g_pkgcfg, pkg->hdr.pkg_name, "version",   pkg->hdr.pkg_version);
    cfg_set(&g_pkgcfg, pkg->hdr.pkg_name, "installed",  "yes");
    cfg_set(&g_pkgcfg, pkg->hdr.pkg_name, "author",     pkg->hdr.pkg_author);
    cfg_set(&g_pkgcfg, pkg->hdr.pkg_name, "description",pkg->hdr.pkg_description);
    if (pkg->hdr.pkg_license[0])
        cfg_set(&g_pkgcfg, pkg->hdr.pkg_name, "license", pkg->hdr.pkg_license);
    cfg_save(&g_pkgcfg, CFG_ROOT "/packages.conf");

    if (errors == 0) {
        terminal_set_color(VGA_LIGHT_GREEN, VGA_BLACK);
        terminal_write("Готово: "); terminal_writeln(pkg->hdr.pkg_name);
    } else {
        terminal_set_color(VGA_YELLOW, VGA_BLACK);
        terminal_write("Установлено с ошибками: ");
        char nb[8]; kuitoa((uint32_t)errors, nb, 10);
        terminal_write(nb); terminal_writeln(" секций пропущено");
    }
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
    return errors ? -1 : 0;
}

/* ── Remove ──────────────────────────────────────────────── */
int cede_remove(const char *pkg_name) {
    const char *inst = cfg_get(&g_pkgcfg, pkg_name, "installed");
    if (!inst || kstrcmp(inst, "yes") != 0) {
        terminal_write("pkg: '"); terminal_write(pkg_name);
        terminal_writeln("' не установлен");
        return -1;
    }
    cfg_set(&g_pkgcfg, pkg_name, "installed", "no");
    cfg_save(&g_pkgcfg, CFG_ROOT "/packages.conf");
    terminal_set_color(VGA_LIGHT_GREEN, VGA_BLACK);
    terminal_write("Удалён: "); terminal_writeln(pkg_name);
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
    return 0;
}

/* ── Execute ELF section ─────────────────────────────────── */
int cede_exec(const cede_pkg_t *pkg, int sidx) {
    if (sidx < 0 || (uint32_t)sidx >= pkg->hdr.n_sections) return -1;
    const cede_section_t *sec = &pkg->sections[sidx];
    if (sec->type != CEDE_SEC_ELF && sec->type != CEDE_SEC_LIB) return -2;

    const uint8_t *edata = pkg->data + sec->offset;
    if (!elf_validate(edata, sec->size)) {
        terminal_writeln("cede_exec: не валидный ELF");
        return -3;
    }
    elf_load_result_t res = elf_load(edata, sec->size);
    if (!res.valid) {
        terminal_write("cede_exec: "); terminal_writeln(res.error);
        return -4;
    }
    ((void(*)(void))(uintptr_t)res.entry)();
    return 0;
}

/* ── Wrap ELF → .cede ────────────────────────────────────── */
int cede_wrap_elf(const uint8_t *elf_data, uint32_t elf_size,
                  const char *name, const char *version,
                  uint8_t *out_buf, uint32_t out_sz) {
    uint32_t need = sizeof(cede_header_t) + sizeof(cede_section_t) + elf_size;
    if (need > out_sz) return -1;

    kmemset(out_buf, 0, need);

    /* Header */
    cede_header_t *hdr = (cede_header_t *)out_buf;
    hdr->magic        = CEDE_MAGIC;
    hdr->cede_version = CEDE_VERSION;
    hdr->n_sections   = 1;
    hdr->install_size = elf_size;
    kstrcpy(hdr->pkg_name,    name);
    kstrcpy(hdr->pkg_version, version);
    kstrcpy(hdr->pkg_author,  "CaramelUK");
    kstrcpy(hdr->pkg_description, "Auto-wrapped ELF binary");
    kstrcpy(hdr->pkg_license, "custom");

    /* Section */
    cede_section_t *sec = (cede_section_t *)(out_buf + sizeof(cede_header_t));
    sec->type   = CEDE_SEC_ELF;
    sec->flags  = CEDE_FLAG_EXEC;
    sec->offset = sizeof(cede_header_t) + sizeof(cede_section_t);
    sec->size   = elf_size;
    kstrcpy(sec->name,      "main");
    kstrcpy(sec->dest_path, "/syls/bin/");
    kstrcat(sec->dest_path, name);

    /* ELF data */
    kmemcpy(out_buf + sec->offset, elf_data, elf_size);

    /* Checksum */
    hdr->checksum = cede_checksum(out_buf, need);
    /* Пересчитываем с нулевым полем checksum */
    uint32_t saved = hdr->checksum;
    hdr->checksum = 0;
    hdr->checksum = cede_checksum(out_buf, need);
    (void)saved;

    return (int)need;
}

/* ── Динамические библиотеки (CEDE_SEC_DYNLIB) ──────────── */
int cede_dynlib_load(const cede_pkg_t *pkg, int sidx) {
    if (sidx < 0 || (uint32_t)sidx >= pkg->hdr.n_sections) return -1;
    const cede_section_t *sec = &pkg->sections[sidx];
    if (sec->type != CEDE_SEC_DYNLIB) return -2;
    /* Загружаем как обычный ELF, но не вызываем entry — только маппируем */
    const uint8_t *edata = pkg->data + sec->offset;
    if (!elf_validate(edata, sec->size)) return -3;
    elf_load_result_t res = elf_load(edata, sec->size);
    if (!res.valid) return -4;
    terminal_set_color(VGA_LIGHT_GREEN, VGA_BLACK);
    terminal_write("  [dynlib] Loaded: "); terminal_write(sec->name[0]?sec->name:"lib");
    terminal_write(" @ 0x");
    char nb[12]; kuitoa(res.load_base, nb, 16); terminal_writeln(nb);
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
    return 0;
}

/* ── Сохранение данных (CEDE_SEC_SAVEDATA) ──────────────── */
int cede_savedata_write(const char *pkg_name, const void *data, uint32_t size) {
    char path[64];
    kstrcpy(path, "/data/saves/");
    vfs_mkdir("/data/saves");
    kstrcat(path, pkg_name);
    kstrcat(path, ".save");
    int fd = vfs_open(path, O_WRONLY|O_CREAT|O_TRUNC);
    if (fd < 0) return -1;
    vfs_write(fd, (const uint8_t *)data, size);
    vfs_close(fd);
    return 0;
}

int cede_savedata_read(const char *pkg_name, void *data, uint32_t maxsize) {
    char path[64];
    kstrcpy(path, "/data/saves/");
    kstrcat(path, pkg_name);
    kstrcat(path, ".save");
    int fd = vfs_open(path, O_RDONLY);
    if (fd < 0) return -1;
    int n = vfs_read(fd, (uint8_t *)data, maxsize);
    vfs_close(fd);
    return n;
}
