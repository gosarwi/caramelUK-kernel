#include "idt.h"
#include "kernel_panic.h"
#include "vga.h"
#include "util.h"
#include <stdint.h>

#define IDT_ENTRIES 256

static idt_entry_t idt_entries[IDT_ENTRIES];
static idt_ptr_t   idt_ptr;

static irq_handler_t irq_routines[16] = { 0 };

/* ─── PIC helpers ─────────────────────────────────────────── */
#define PIC1_CMD  0x20
#define PIC1_DATA 0x21
#define PIC2_CMD  0xA0
#define PIC2_DATA 0xA1
#define PIC_EOI   0x20

/* Remap PIC: IRQ0-7 → IDT 32-39, IRQ8-15 → IDT 40-47 */
static void pic_remap(void) {
    uint8_t mask1 = inb(PIC1_DATA);
    uint8_t mask2 = inb(PIC2_DATA);

    outb(PIC1_CMD,  0x11); io_wait();
    outb(PIC2_CMD,  0x11); io_wait();
    outb(PIC1_DATA, 0x20); io_wait(); /* IRQ0 → INT 32 */
    outb(PIC2_DATA, 0x28); io_wait(); /* IRQ8 → INT 40 */
    outb(PIC1_DATA, 0x04); io_wait(); /* PIC1 cascade IRQ2 */
    outb(PIC2_DATA, 0x02); io_wait();
    outb(PIC1_DATA, 0x01); io_wait(); /* 8086 mode */
    outb(PIC2_DATA, 0x01); io_wait();

    outb(PIC1_DATA, mask1);
    outb(PIC2_DATA, mask2);
}

/* ─── IDT entry setup ─────────────────────────────────────── */
static void idt_set_gate(uint8_t num, uint32_t base,
                          uint16_t sel, uint8_t flags)
{
    idt_entries[num].base_low  = base & 0xFFFF;
    idt_entries[num].base_high = (base >> 16) & 0xFFFF;
    idt_entries[num].selector  = sel;
    idt_entries[num].always0   = 0;
    idt_entries[num].flags     = flags;
}

void idt_install(void) {
    idt_ptr.limit = (sizeof(idt_entry_t) * IDT_ENTRIES) - 1;
    idt_ptr.base  = (uint32_t)&idt_entries;

    for (int i = 0; i < IDT_ENTRIES; i++)
        idt_set_gate(i, 0, 0, 0);

    pic_remap();

    /* CPU exceptions 0-31 */
    idt_set_gate(0,  (uint32_t)isr0,  0x08, 0x8E);
    idt_set_gate(1,  (uint32_t)isr1,  0x08, 0x8E);
    idt_set_gate(2,  (uint32_t)isr2,  0x08, 0x8E);
    idt_set_gate(3,  (uint32_t)isr3,  0x08, 0x8E);
    idt_set_gate(4,  (uint32_t)isr4,  0x08, 0x8E);
    idt_set_gate(5,  (uint32_t)isr5,  0x08, 0x8E);
    idt_set_gate(6,  (uint32_t)isr6,  0x08, 0x8E);
    idt_set_gate(7,  (uint32_t)isr7,  0x08, 0x8E);
    idt_set_gate(8,  (uint32_t)isr8,  0x08, 0x8E);
    idt_set_gate(9,  (uint32_t)isr9,  0x08, 0x8E);
    idt_set_gate(10, (uint32_t)isr10, 0x08, 0x8E);
    idt_set_gate(11, (uint32_t)isr11, 0x08, 0x8E);
    idt_set_gate(12, (uint32_t)isr12, 0x08, 0x8E);
    idt_set_gate(13, (uint32_t)isr13, 0x08, 0x8E);
    idt_set_gate(14, (uint32_t)isr14, 0x08, 0x8E);
    idt_set_gate(15, (uint32_t)isr15, 0x08, 0x8E);
    idt_set_gate(16, (uint32_t)isr16, 0x08, 0x8E);
    idt_set_gate(17, (uint32_t)isr17, 0x08, 0x8E);
    idt_set_gate(18, (uint32_t)isr18, 0x08, 0x8E);
    idt_set_gate(19, (uint32_t)isr19, 0x08, 0x8E);
    idt_set_gate(20, (uint32_t)isr20, 0x08, 0x8E);
    idt_set_gate(21, (uint32_t)isr21, 0x08, 0x8E);
    idt_set_gate(22, (uint32_t)isr22, 0x08, 0x8E);
    idt_set_gate(23, (uint32_t)isr23, 0x08, 0x8E);
    idt_set_gate(24, (uint32_t)isr24, 0x08, 0x8E);
    idt_set_gate(25, (uint32_t)isr25, 0x08, 0x8E);
    idt_set_gate(26, (uint32_t)isr26, 0x08, 0x8E);
    idt_set_gate(27, (uint32_t)isr27, 0x08, 0x8E);
    idt_set_gate(28, (uint32_t)isr28, 0x08, 0x8E);
    idt_set_gate(29, (uint32_t)isr29, 0x08, 0x8E);
    idt_set_gate(30, (uint32_t)isr30, 0x08, 0x8E);
    idt_set_gate(31, (uint32_t)isr31, 0x08, 0x8E);

    /* IRQ 0-15 */
    idt_set_gate(32, (uint32_t)irq0,  0x08, 0x8E);
    idt_set_gate(33, (uint32_t)irq1,  0x08, 0x8E);
    idt_set_gate(34, (uint32_t)irq2,  0x08, 0x8E);
    idt_set_gate(35, (uint32_t)irq3,  0x08, 0x8E);
    idt_set_gate(36, (uint32_t)irq4,  0x08, 0x8E);
    idt_set_gate(37, (uint32_t)irq5,  0x08, 0x8E);
    idt_set_gate(38, (uint32_t)irq6,  0x08, 0x8E);
    idt_set_gate(39, (uint32_t)irq7,  0x08, 0x8E);
    idt_set_gate(40, (uint32_t)irq8,  0x08, 0x8E);
    idt_set_gate(41, (uint32_t)irq9,  0x08, 0x8E);
    idt_set_gate(42, (uint32_t)irq10, 0x08, 0x8E);
    idt_set_gate(43, (uint32_t)irq11, 0x08, 0x8E);
    idt_set_gate(44, (uint32_t)irq12, 0x08, 0x8E);
    idt_set_gate(45, (uint32_t)irq13, 0x08, 0x8E);
    idt_set_gate(46, (uint32_t)irq14, 0x08, 0x8E);
    idt_set_gate(47, (uint32_t)irq15, 0x08, 0x8E);

    /* int 0x80 — syscall (ring 3 callable: flags=0xEE) */
    idt_set_gate(0x80, (uint32_t)isr128, 0x08, 0xEE);

    idt_flush(&idt_ptr);
}

/* ─── IRQ install / remove ────────────────────────────────── */
void irq_install_handler(int irq, irq_handler_t handler) {
    irq_routines[irq & 0xF] = handler;
}
void irq_uninstall_handler(int irq) {
    irq_routines[irq & 0xF] = 0;
}

/* ─── Exception names ─────────────────────────────────────── */
static const char *exception_messages[] = {
    "Division By Zero",        "Debug",
    "Non Maskable Interrupt",  "Breakpoint",
    "Into Detected Overflow",  "Out of Bounds",
    "Invalid Opcode",          "No Coprocessor",
    "Double Fault",            "Coprocessor Segment Overrun",
    "Bad TSS",                 "Segment Not Present",
    "Stack Fault",             "General Protection Fault",
    "Page Fault",              "Unknown Interrupt",
    "Coprocessor Fault",       "Alignment Check",
    "Machine Check",           "Reserved",
    "Reserved","Reserved","Reserved","Reserved",
    "Reserved","Reserved","Reserved","Reserved",
    "Reserved","Reserved","Reserved","Reserved"
};

/* ─── ISR handler (called from ASM stub) ─────────────────── */
void isr_handler(registers_t *regs) {
    if (regs->int_no == 128) {
        /* int 0x80 syscall — EAX = syscall number */
        /* Basic syscall table:
           0 = sys_write (ECX=buf ptr, EDX=len) → print to VGA
           1 = sys_exit  (EBX=code)             → halt
        */
        switch (regs->eax) {
            case 0: {
                const char *buf = (const char *)regs->ecx;
                uint32_t len = regs->edx;
                /* safety: only print if pointer looks reasonable */
                if (buf && len < 4096) {
                    for (uint32_t i = 0; i < len; i++)
                        terminal_putchar(buf[i]);
                }
                break;
            }
            case 1:
                terminal_writeln("[syscall] sys_exit called");
                __asm__ volatile ("cli; hlt");
                break;
            default:
                kprintf("[syscall] unknown: %d\n", regs->eax);
                break;
        }
        return;
    }

    if (regs->int_no < 32) {
        kernel_panic_exception(regs);
    }
}

/* ─── IRQ handler (called from ASM stub) ─────────────────── */
void irq_handler(registers_t *regs) {
    /* Send EOI */
    if (regs->int_no >= 40)
        outb(PIC2_CMD, PIC_EOI);
    outb(PIC1_CMD, PIC_EOI);

    int irq = regs->int_no - 32;
    if (irq >= 0 && irq < 16 && irq_routines[irq])
        irq_routines[irq](regs);
}
