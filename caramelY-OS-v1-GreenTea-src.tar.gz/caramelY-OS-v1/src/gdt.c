#include "gdt.h"

#define GDT_ENTRIES 5

static gdt_entry_t gdt_entries[GDT_ENTRIES];
static gdt_ptr_t   gdt_ptr;

static void gdt_set_entry(int idx, uint32_t base, uint32_t limit,
                           uint8_t access, uint8_t gran)
{
    gdt_entries[idx].base_low  = (base & 0xFFFF);
    gdt_entries[idx].base_mid  = (base >> 16) & 0xFF;
    gdt_entries[idx].base_high = (base >> 24) & 0xFF;

    gdt_entries[idx].limit_low   = (limit & 0xFFFF);
    gdt_entries[idx].granularity = ((limit >> 16) & 0x0F) | (gran & 0xF0);

    gdt_entries[idx].access = access;
}

void gdt_install(void)
{
    gdt_ptr.limit = (sizeof(gdt_entry_t) * GDT_ENTRIES) - 1;
    gdt_ptr.base  = (uint32_t)&gdt_entries;

    /* 0: null descriptor */
    gdt_set_entry(0, 0, 0, 0, 0);

    /* 1: kernel code  0x08  (ring 0, exec/read) */
    gdt_set_entry(1, 0, 0xFFFFFFFF, 0x9A, 0xCF);

    /* 2: kernel data  0x10  (ring 0, read/write) */
    gdt_set_entry(2, 0, 0xFFFFFFFF, 0x92, 0xCF);

    /* 3: user code    0x18  (ring 3, exec/read) */
    gdt_set_entry(3, 0, 0xFFFFFFFF, 0xFA, 0xCF);

    /* 4: user data    0x20  (ring 3, read/write) */
    gdt_set_entry(4, 0, 0xFFFFFFFF, 0xF2, 0xCF);

    gdt_flush(&gdt_ptr);
}
