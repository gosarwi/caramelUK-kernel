#ifndef LOCALAI_H
#define LOCALAI_H
/*
 * localai.h — CaramelUK v9 Local AI Interface
 *
 * Позволяет загрузить языковую модель из файла в /ai/ и общаться с ней
 * прямо в шелле через команду 'ai'.
 *
 * Поддерживаемые форматы моделей:
 *   .crml  — нативный формат CaramelUK (простой Markov/n-gram)
 *   .dict  — словарный чат-бот (пары вопрос-ответ)
 *   .brain — расширенный формат с весами
 *
 * Использование:
 *   ai load /ai/mymodel.crml   — загрузить модель
 *   ai chat                    — начать диалог (выход: 'exit' или Ctrl+C)
 *   ai ask "вопрос"            — одиночный вопрос
 *   ai info                    — информация о загруженной модели
 *   ai unload                  — выгрузить модель
 *   ai create /ai/name.dict    — создать словарный чат-бот
 *
 * Формат .dict файла (простые пары):
 *   # Комментарий
 *   привет -> Привет! Как дела?
 *   как дела -> Всё хорошо, спасибо!
 *   default -> Извините, не понимаю.
 *
 * Формат .crml файла:
 *   CRML1\n
 *   name=Имя модели\n
 *   lang=ru\n
 *   prompt=Системный промпт\n
 *   ---\n
 *   пары вопрос->ответ как в .dict
 */
#include <stdint.h>
#include <stddef.h>

#define AI_MAX_PAIRS     512    /* максимум пар вопрос-ответ */
#define AI_MAX_STR       256    /* максимальная длина строки */
#define AI_MAX_MODEL_SZ  (512*1024)  /* 512KB максимальный размер модели */

typedef enum {
    AI_FMT_NONE = 0,
    AI_FMT_DICT,    /* .dict — простые пары */
    AI_FMT_CRML,    /* .crml — нативный CaramelUK формат */
    AI_FMT_BRAIN,   /* .brain — с весами (заглушка) */
} ai_fmt_t;

typedef struct {
    char question[AI_MAX_STR];
    char answer[AI_MAX_STR];
    int  weight;    /* 0-100, приоритет ответа */
} ai_pair_t;

typedef struct {
    ai_fmt_t fmt;
    char     name[64];
    char     lang[8];        /* "ru", "en", "mixed" */
    char     prompt[256];    /* системный промпт/описание */
    char     path[128];      /* путь к файлу */
    ai_pair_t pairs[AI_MAX_PAIRS];
    int      pair_count;
    int      loaded;
    /* Статистика */
    uint32_t questions_asked;
    uint32_t matches_found;
} ai_model_t;

/* Единственный глобальный экземпляр */
extern ai_model_t g_ai;

/* ── API ──────────────────────────────────────────────────── */

/* Загрузить модель из файла */
int  ai_load(const char *path);

/* Выгрузить модель */
void ai_unload(void);

/* Задать вопрос, получить ответ в out[out_sz] */
/* Возвращает 1 если нашёл совпадение, 0 если дефолтный ответ */
int  ai_ask(const char *question, char *out, int out_sz);

/* Создать новую модель типа .dict интерактивно */
int  ai_create_interactive(const char *path);

/* Информация о модели */
void ai_info(void);

/* Запустить интерактивный чат (выход по "exit") */
void ai_chat_loop(void);

/* ── Утилиты ──────────────────────────────────────────────── */
/* Вычислить похожесть строк (0-100) */
int  ai_similarity(const char *a, const char *b);

/* Нормализовать строку (нижний регистр, без лишних пробелов) */
void ai_normalize(const char *in, char *out, int out_sz);

/* readline from kernel.c */
void readline_v9(char *out, int maxlen);

#endif
