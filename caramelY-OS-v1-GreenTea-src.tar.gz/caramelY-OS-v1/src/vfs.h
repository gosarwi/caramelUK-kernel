#ifndef VFS_H
#define VFS_H

#include <stdint.h>
#include <stddef.h>

/* ── File types ──────────────────────────────────────────── */
#define VFS_FILE    0x01
#define VFS_DIR     0x02
#define VFS_CHARDEV 0x04
#define VFS_BLKDEV  0x08
#define VFS_PIPE    0x10
#define VFS_SYMLINK 0x20
#define VFS_MOUNT   0x40

/* ── Permissions (Unix-style bits, simplified) ───────────── */
#define PERM_R  0x04
#define PERM_W  0x02
#define PERM_X  0x01

/* ── Open flags ──────────────────────────────────────────── */
#define O_RDONLY  0x0
#define O_WRONLY  0x1
#define O_RDWR    0x2
#define O_CREAT   0x40
#define O_TRUNC   0x200
#define O_APPEND  0x400

/* ── stat structure ──────────────────────────────────────── */
typedef struct {
    uint32_t inode;
    uint32_t size;
    uint8_t  type;
    uint8_t  perms;
    uint32_t uid, gid;
} vfs_stat_t;

/* ── Forward declarations ────────────────────────────────── */
struct vfs_node;
struct vfs_dirent;

/* ── Filesystem operations table (vtable) ────────────────── */
typedef struct vfs_ops {
    uint32_t (*read) (struct vfs_node *, uint32_t offset, uint32_t size, uint8_t *buf);
    uint32_t (*write)(struct vfs_node *, uint32_t offset, uint32_t size, const uint8_t *buf);
    void     (*open) (struct vfs_node *, uint32_t flags);
    void     (*close)(struct vfs_node *);
    struct vfs_dirent *(*readdir)(struct vfs_node *, uint32_t index);
    struct vfs_node   *(*finddir)(struct vfs_node *, const char *name);
    int      (*create)(struct vfs_node *, const char *name, uint8_t type);
    int      (*unlink)(struct vfs_node *, const char *name);
    int      (*stat)  (struct vfs_node *, vfs_stat_t *st);
    int      (*mkdir) (struct vfs_node *, const char *name);
} vfs_ops_t;

/* ── VFS node ─────────────────────────────────────────────── */
#define VFS_NAME_MAX 64

typedef struct vfs_node {
    char          name[VFS_NAME_MAX];
    uint32_t      inode;
    uint32_t      size;
    uint8_t       type;     /* VFS_FILE | VFS_DIR | ... */
    uint8_t       perms;
    uint32_t      uid, gid;
    vfs_ops_t    *ops;
    void         *impl;     /* filesystem-specific data */
    struct vfs_node *mount; /* if VFS_MOUNT, pointer to root of mounted fs */
} vfs_node_t;

/* ── Directory entry ─────────────────────────────────────── */
typedef struct vfs_dirent {
    char     name[VFS_NAME_MAX];
    uint32_t inode;
    uint8_t  type;
} vfs_dirent_t;

/* ── File descriptor ─────────────────────────────────────── */
#define FD_MAX 16

typedef struct {
    vfs_node_t *node;
    uint32_t    offset;
    uint32_t    flags;
    int         used;
} fd_t;

/* ── Public API ──────────────────────────────────────────── */
void         vfs_init(void);
vfs_node_t  *vfs_root(void);
void         vfs_mount(const char *path, vfs_node_t *node);

/* Path resolution */
vfs_node_t  *vfs_lookup(const char *path);

/* File operations */
int          vfs_open  (const char *path, uint32_t flags);
void         vfs_close (int fd);
int          vfs_read  (int fd, void *buf, uint32_t size);
int          vfs_write (int fd, const void *buf, uint32_t size);
int          vfs_stat  (const char *path, vfs_stat_t *st);

/* Directory operations */
int          vfs_mkdir (const char *path);
int          vfs_create(const char *path);
int          vfs_unlink(const char *path);
vfs_dirent_t *vfs_readdir(const char *path, uint32_t index);
int          vfs_listdir(const char *path, char names[][VFS_NAME_MAX], int *count);

/* ── ramfs (in-memory filesystem) ───────────────────────── */
vfs_node_t  *ramfs_create_root(void);

#endif
