#ifndef DE_H
#define DE_H
#include "vbe.h"
#include "vga.h"
#include "vfs.h"
#include <stdint.h>
#include <stddef.h>

/* Sizes */
#define DE_SCR_W        800
#define DE_SCR_H        600
#define DE_TASKBAR_H     28
#define DE_TITLEBAR_H    22
#define DE_BORDER         2
#define DE_MAX_WIN        8
#define DE_TERM_HIST    200
#define DE_TERM_COLS     80
#define DE_NOTIF_MAX      4
#define FM_MAX_ENTRIES  128
#define FM_NAME_LEN      64
#define SYSMON_HISTORY   60

/* Colors (Catppuccin Mocha) */
#define C_BASE      RGB(0x1E,0x1E,0x2E)
#define C_MANTLE    RGB(0x18,0x18,0x2A)
#define C_CRUST     RGB(0x11,0x11,0x1D)
#define C_SURFACE0  RGB(0x31,0x32,0x44)
#define C_SURFACE1  RGB(0x45,0x47,0x5A)
#define C_SURFACE2  RGB(0x58,0x5B,0x70)
#define C_OVERLAY0  RGB(0x6C,0x70,0x86)
#define C_TEXT      RGB(0xCA,0xD3,0xF5)
#define C_SUBTEXT   RGB(0xA6,0xAD,0xC8)
#define C_LAVENDER  RGB(0xB7,0xBD,0xF8)
#define C_BLUE      RGB(0x89,0xB4,0xFA)
#define C_SAPPHIRE  RGB(0x74,0xC7,0xEC)
#define C_SKY       RGB(0x89,0xDC,0xEB)
#define C_TEAL      RGB(0x94,0xE2,0xD5)
#define C_GREEN     RGB(0xA6,0xE3,0xA1)
#define C_YELLOW    RGB(0xF9,0xE2,0xAF)
#define C_PEACH     RGB(0xFA,0xB3,0x87)
#define C_MAROON    RGB(0xEB,0xA0,0xAC)
#define C_RED       RGB(0xF3,0x8B,0xA8)
#define C_MAUVE     RGB(0xCB,0xA6,0xF7)
#define C_PINK      RGB(0xF5,0xC2,0xE7)

/* App IDs */
typedef enum {
    APP_NONE=0, APP_TERMINAL, APP_FILES, APP_EDITOR,
    APP_SYSMON, APP_SETTINGS, APP_VIEWER, APP_ABOUT,
} app_id_t;

/* Terminal line */
typedef struct {
    char    text[DE_TERM_COLS+4];
    uint32_t color;
    uint8_t  is_prompt;
} de_tline_t;

/* File entry */
typedef struct {
    char     name[FM_NAME_LEN];
    int      is_dir;
    uint32_t size;
} fm_entry_t;

/* Sysmon history */
typedef struct {
    uint8_t  cpu[SYSMON_HISTORY];
    uint8_t  mem[SYSMON_HISTORY];
    int      head;
    uint32_t last_tick;
    uint32_t last_free;
} sysmon_t;

/* Notification */
typedef struct {
    char      msg[64];
    uint32_t  expire;
    int       active;
    color32_t color;
} de_notif_t;

/* Window */
typedef struct {
    int       id;
    app_id_t  app;
    char      title[48];
    int       x, y, w, h;
    int       minimized;
    int       maximized;
    int       px, py, pw, ph;

    /* Terminal */
    de_tline_t tlines[DE_TERM_HIST];
    int        tcount, tscroll;
    char       tinput[256];
    int        tinput_pos;
    char       thist[32][256];
    int        thist_count, thist_idx;

    /* Files */
    char       fm_path[128];
    fm_entry_t fm_ent[FM_MAX_ENTRIES];
    int        fm_count, fm_sel, fm_scroll;
    char       fm_preview[512];

    /* Editor */
    char       ed_path[128];
    char       ed_buf[8192];
    int        ed_len, ed_scroll;
    int        ed_readonly;

    /* Sysmon */
    sysmon_t   sysmon;

    /* Settings */
    int        cfg_tab;
} de_win_t;

/* State */
typedef struct {
    de_win_t   wins[DE_MAX_WIN];
    int        win_count;
    int        active;
    int        running;
    int        launcher_open;
    int        launcher_sel;
    int        alttab_open;
    int        alttab_sel;
    de_notif_t notifs[DE_NOTIF_MAX];
    uint32_t   clock_sec;
    uint32_t   last_clock;
} de_state_t;

/* Public API */
void de_init(void);
void de_run(void);
int  de_open_app(app_id_t app, const char *path);
void de_notify(const char *msg, color32_t color);
void de_capture_char(char c);  /* called by vbe_console_putchar */

#endif
