/* kernel.c === caramelY OS v10.0 "Green Tea"
 *
 * NEW in v7:
 *   - Games: Snake, Tetris (ASCII, fully playable)
 *   - Easter eggs: alya (ASCII art), crash (Windows BSOD), matrix (rain)
 *   - Alt+C hotkey in readline === opens config create
 *   - [command] section in system.conf === full command aliasing/remapping
 *   - Desktop customization: style windows/mac/caramel, bg color, wallpaper text
 *   - Kernel config: kernel_name, hostname_color, boot_msg, prompt_format,
 *                    disable_cmd, accent_char, motd_color, sidebar_info
 *   - Bug fixes: readline backspace at col 0, ls after rm, sysconf save theme
 *
 * READLINE v6 (inherited, fixed):
 *   - Alt+C during input === dispatch "config create"
 *   - Ctrl+C fixed for VBE path
 */

#include "vga.h"
#include "vbe.h"
#include "keyboard.h"
#include "util.h"
#include "vfs.h"
#include "gdt.h"
#include "idt.h"
#include "pit.h"
#include "kmalloc.h"
#include "sched.h"
#include "elf.h"
#include "net.h"
#include "disk.h"
#include "cfs.h"
#include "config.h"
#include "cede.h"
#include "fileformat.h"
#include "de.h"
#include "ossdk.h"
#include "browser.h"
#include "wincompat.h"
#include "fat32.h"
#include "osbuilder.h"
#include "gamesdk.h"
#include "maze.h"
#include "gamelauncher.h"
#include "store.h"
#include "localai.h"
#include "kernel_panic.h"
#include "kmod.h"
#include "fish_shell.h"
extern char keyboard_utf8_buf[4];
#include <stddef.h>
#include <stdint.h>

/* ====== Multiboot ============================================================================================================================================= */
typedef struct __attribute__((packed)) {
    uint32_t mod_start, mod_end, cmdline, reserved;
} mb_module_t;

typedef struct __attribute__((packed)) {
    uint32_t flags, mem_lower, mem_upper, boot_device, cmdline;
    uint32_t mods_count, mods_addr;
    uint8_t  _skip[48];
    uint32_t fb_addr_lo, fb_addr_hi, fb_pitch, fb_width, fb_height;
    uint8_t  fb_bpp, fb_type; uint16_t _res;
    uint8_t  fb_red_pos, fb_red_mask, fb_green_pos, fb_green_mask;
    uint8_t  fb_blue_pos, fb_blue_mask;
} mb_info_t;

#define HEAP_ADDR 0x800000   /* 8MB === ============================ ======== BSS ======== */
#define HEAP_SIZE (8*1024*1024)  /* 8MB ======== */

/* ====== Global state ==================================================================================================================================== */
static int       use_vbe   = 0;
static int       live_mode = 1;
static mb_info_t *g_mbi    = NULL;
static uint32_t   g_mem_upper = 0;
static int        sudo_mode  = 0;
static char       sudo_pin[16] = "1234";

/* ====== Console abstraction =============================================================================================================== */
static void con_putchar(char c) {
    if (use_vbe) vbe_console_putchar(c); else terminal_putchar(c);
}
static void con_write(const char *s) { while(*s) con_putchar(*s++); }
static void con_writeln(const char *s){ con_write(s); con_putchar('\n'); }
static void con_clear(void) {
    if (use_vbe) vbe_console_clear(); else terminal_clear();
}
static void con_erase(void) {
    if (!use_vbe) terminal_erase_char();
}
static void con_erase_eol(void) {
    if (!use_vbe) terminal_erase_eol();
}

/* Color helpers */
#define C_NRM() terminal_set_color(SCH->normal_fg,  SCH->normal_bg)
#define C_ERR() terminal_set_color(SCH->error_fg,   SCH->normal_bg)
#define C_ACC() terminal_set_color(SCH->accent_fg,  SCH->normal_bg)
#define C_OK()  terminal_set_color(SCH->success_fg, SCH->normal_bg)
#define C_HDR() terminal_set_color(SCH->header_fg,  SCH->normal_bg)
#define C_WRN() terminal_set_color(SCH->warn_fg,    SCH->normal_bg)
#define C_DIM() terminal_set_color(SCH->dim_fg,     SCH->normal_bg)
#define C_PRM() terminal_set_color(SCH->prompt_fg,  SCH->normal_bg)

/* cprintf */
static void cprintf(const char *fmt, ...) {
    __builtin_va_list ap; __builtin_va_start(ap, fmt);
    char nb[32];
    while (*fmt) {
        if (*fmt != '%') { con_putchar(*fmt++); continue; }
        fmt++;
        int w=0,zp=0;
        if (*fmt=='0'){zp=1;fmt++;} while(*fmt>='0'&&*fmt<='9'){w=w*10+(*fmt-'0');fmt++;}
        if (*fmt=='d'){int n=__builtin_va_arg(ap,int);kitoa(n,nb,10);
            int l=(int)kstrlen(nb); for(int i=l;i<w;i++)con_putchar(zp?'0':' ');
            con_write(nb);}
        else if (*fmt=='u'){uint32_t n=__builtin_va_arg(ap,uint32_t);kuitoa(n,nb,10);
            int l=(int)kstrlen(nb); for(int i=l;i<w;i++)con_putchar(zp?'0':' ');
            con_write(nb);}
        else if (*fmt=='x'){uint32_t n=__builtin_va_arg(ap,uint32_t);kuitoa(n,nb,16);
            int l=(int)kstrlen(nb); for(int i=l;i<w;i++)con_putchar(zp?'0':' ');
            con_write(nb);}
        else if (*fmt=='p'){uint32_t n=__builtin_va_arg(ap,uint32_t);kuitoa(n,nb,16);
            con_write("0x"); con_write(nb);}
        else if (*fmt=='s'){const char*s=__builtin_va_arg(ap,const char*);con_write(s?s:"(null)");}
        else if (*fmt=='c'){con_putchar((char)__builtin_va_arg(ap,int));}
        else if (*fmt=='%'){con_putchar('%');}
        else {con_putchar('%');con_putchar(*fmt);}
        fmt++;
    }
    __builtin_va_end(ap);
}
#undef kprintf
#define kprintf cprintf

/* ====== Shell state ======================================================================================================================================= */
#define CMD_MAX       512
#define HIST_SIZE     256
#define RL_MAX        512
#define COMP_MAX       64

static char  cwd[128]   = "/home";
static char  history[HIST_SIZE][CMD_MAX];
static int   hist_count  = 0;
static char  hostname[64] = "caramelY";
static char  username[32] = "root";
static int   redirect_fd  = -1;

/* ====== READLINE v6 (fixed + Alt+C hotkey) =============================================================== */
static int  rl_prompt_col = 0;
static int  rl_prompt_row = 0;

void print_prompt(void);  /* used by fish_shell.c */

static void rl_redraw(const char *linebuf, int len, int pos, int old_len) {
    if (use_vbe) return;

    /* v9 FIX: ================ redraw ==== ============ ====================== ============== ==============.
     * ================:
     *   1. ====================== ============ ========== ==== (rl_prompt_row, rl_prompt_col).
     *   2. ============== ====== ============ ==== ========== + 1 ============ ======== (==== ============ ================).
     *   3. ======================== ======== ========== == ============.
     *   4. ================== ============ ==== ============ pos.
     * ====== ================== ======================== ================ ====== ================ ============.
     */
    int cur_row, cur_col;
    terminal_get_cursor(&cur_row, &cur_col);

    /* ====== 1: ========================== ==== ============ ============ ========== */
    /* ======== ==== ==== ====== ==== ============ === ============ ======== ========== */
    /* ======== ======== ======== === ======== ========== ========== \b ==== col=0, ========== CR */
    if (cur_row == rl_prompt_row) {
        while (cur_col > rl_prompt_col) { terminal_putchar('\b'); cur_col--; }
    } else {
        /* ============== ================ === ============== ============== ============ == ======================== */
        terminal_erase_eol();
        /* CR == ============== ==== ============ ========== */
        terminal_set_cursor(rl_prompt_row, rl_prompt_col);
    }

    /* ====== 2: ============== ============ ============== ==== ============== ============== ==== ========== ============ */
    terminal_erase_eol();
    /* ======== ============ len ====== ============ ============== === ============== ================== ============ ======== */
    if (rl_prompt_col + old_len >= VGA_WIDTH) {
        int next_row = rl_prompt_row + 1;
        if (next_row < VGA_HEIGHT) {
            int sr, sc2; terminal_get_cursor(&sr, &sc2);
            terminal_set_cursor(next_row, 0);
            terminal_erase_eol();
            terminal_set_cursor(sr, sc2);
        }
    }

    /* ====== 3: ======================== ======== ========== */
    C_NRM();
    for (int i = 0; i < len; i++) con_putchar(linebuf[i]);

    /* ====== 4: ============== ============ ==== pos */
    /* ============== col = rl_prompt_col + len (mod VGA_WIDTH) */
    /* ============ ======== ========== len-pos ====== */
    for (int i = len; i > pos; i--) terminal_putchar('\b');
}

/* Forward declare dispatch so readline can call it for Alt+C */
static void easter_android(void);
static void easter_v10_jubilee(void);
void game_pong(void);

void dispatch(char *line);


static void readline_v6(char *out, int maxlen) {
    char    buf[RL_MAX];
    int     len = 0, pos = 0;
    int     hist_idx = hist_count;
    char    saved[RL_MAX]; saved[0] = 0;

    /* Tab completion candidates */
    static const char *builtins[] = {
        "ls","ll","la","cat","view","less","head","tail","file","hd","hexdump","wc",
        "grep","sort","uniq","cut","tr","tee","find","tree","write","append","touch",
        "rm","cp","mv","mkdir","rmdir","cd","pwd","stat","chmod","chown","ln",
        "ps","kill","sleep","wait","sh","source","uname","info","hwinfo","lscpu",
        "uptime","mem","free","dmesg","date","hostname","whoami","id","env","set",
        "unset","export","printenv","lsblk","df","du","mount","umount","mkfs","sync",
        "ifconfig","netstat","ping","arp","route","theme","themes","sysconf","pkg",
        "readelf","exec","sdk","serial","modinfo","malloc","which","man","history",
        "clear","reset","logo","echo","printf","de","install","live","modules","aiy",
        "help","reboot","halt","poweroff","sudo","su","xargs",
        /* v10 new */
        "snake","tetris","matrix","alya","crash","pong","android","v10","lollipop","desktop","kernel",
        NULL
    };

    if (!use_vbe) {
        int r, c; terminal_get_cursor(&r, &c);
        rl_prompt_col = c; rl_prompt_row = r;
    }

    while (1) {
        /* Poll with alt-awareness */
        int k;
        do {
            while (!(inb(0x64) & 1)) __asm__ volatile("pause");
            k = keyboard_poll();
        } while (k == 0);

        /* ====== Alt+C hotkey === open config create ====== */
        if (keyboard_alt() && (k == 'c' || k == 'C' || k == 3)) {
            /* Clear current line visually */
            if (!use_vbe) {
                for (int i = pos; i < len; i++) con_putchar(' ');
                for (int i = 0; i < len; i++) terminal_putchar('\b');
                for (int i = 0; i < len; i++) con_putchar(' ');
                for (int i = 0; i < len; i++) terminal_putchar('\b');
            }
            con_putchar('\n');
            C_ACC(); con_writeln("[Alt+C] Opening Config Creator..."); C_NRM();
            dispatch((char*)"config create");
            /* Reprint prompt */
            print_prompt();
            len = 0; pos = 0;
            if (!use_vbe) {
                int r2, c2; terminal_get_cursor(&r2, &c2);
                rl_prompt_col = c2; rl_prompt_row = r2;
            }
            continue;
        }

        int old_len = len;

        if (k == '\n' || k == '\r') {
            /* Move to end so next prompt is on new line */
            if (!use_vbe) for (int i = pos; i < len; i++) con_putchar(buf[i]);
            con_putchar('\n');
            buf[len] = 0;
            kstrcpy(out, buf);
            return;
        }

        /* Ctrl+C */
        if (k == 3) {
            con_putchar('^'); con_putchar('C'); con_putchar('\n');
            out[0] = 0; return;
        }
        /* Ctrl+D */
        if (k == 4 && len == 0) { con_putchar('\n'); out[0] = 0; return; }
        /* Ctrl+L */
        if (k == 12) {
            con_clear();
            print_prompt();
            if (!use_vbe) {
                int r2,c2; terminal_get_cursor(&r2,&c2);
                rl_prompt_col=c2; rl_prompt_row=r2;
            }
            rl_redraw(buf,len,pos,0);
            continue;
        }
        /* Ctrl+A === beginning of line */
        if (k == 1) {
            if (!use_vbe) for (int i = 0; i < pos; i++) terminal_putchar('\b');
            pos = 0; continue;
        }
        /* Ctrl+E === end of line */
        if (k == 5) {
            if (!use_vbe) for (int i = pos; i < len; i++) con_putchar(buf[i]);
            pos = len; continue;
        }
        /* Ctrl+K === kill to end */
        if (k == 11) {
            if (!use_vbe) { con_erase_eol(); }
            len = pos; buf[len] = 0; continue;
        }
        /* Ctrl+U === kill to start */
        if (k == 21) {
            if (!use_vbe) {
                for (int i=0;i<pos;i++) terminal_putchar('\b');
                for (int i=0;i<len;i++) con_putchar(' ');
                for (int i=0;i<len;i++) terminal_putchar('\b');
            }
            kmemmove(buf, buf+pos, (size_t)(len-pos));
            len -= pos; pos = 0; buf[len] = 0;
            rl_redraw(buf,len,pos,old_len); continue;
        }
        /* Ctrl+W === delete word before cursor */
        if (k == 23) {
            int p2 = pos;
            while (p2 > 0 && buf[p2-1] == ' ') p2--;
            while (p2 > 0 && buf[p2-1] != ' ') p2--;
            int del = pos - p2;
            kmemmove(buf+p2, buf+pos, (size_t)(len-pos));
            len -= del; pos = p2; buf[len] = 0;
            rl_redraw(buf,len,pos,old_len); continue;
        }

        /* Up arrow === history */
        if (k == KEY_UP) {
            if (hist_idx == hist_count) kstrcpy(saved, buf);
            if (hist_idx > 0) {
                hist_idx--;
                kstrcpy(buf, history[hist_idx]);
                len = (int)kstrlen(buf); pos = len;
                rl_redraw(buf,len,pos,old_len);
            }
            continue;
        }
        /* Down arrow === history */
        if (k == KEY_DOWN) {
            if (hist_idx < hist_count) {
                hist_idx++;
                if (hist_idx == hist_count) kstrcpy(buf, saved);
                else kstrcpy(buf, history[hist_idx]);
                len = (int)kstrlen(buf); pos = len;
                rl_redraw(buf,len,pos,old_len);
            }
            continue;
        }
        /* Left/Right */
        if (k == KEY_LEFT)  { if (pos>0){ pos--; if(!use_vbe) terminal_putchar('\b'); } continue; }
        if (k == KEY_RIGHT) { if (pos<len){ if(!use_vbe) con_putchar(buf[pos]); pos++; } continue; }
        if (k == KEY_HOME)  { if(!use_vbe) for(int i=0;i<pos;i++) terminal_putchar('\b'); pos=0; continue; }
        if (k == KEY_END)   { if(!use_vbe) for(int i=pos;i<len;i++) con_putchar(buf[i]); pos=len; continue; }

        /* PgUp/PgDn === scroll */
        if (k == KEY_PGUP) { if(!use_vbe) terminal_scroll_up(10);   continue; }
        if (k == KEY_PGDN) { if(!use_vbe) terminal_scroll_down(10); continue; }

        /* Delete key */
        if (k == KEY_DEL) {
            if (pos < len) {
                kmemmove(buf+pos, buf+pos+1, (size_t)(len-pos-1));
                len--; buf[len]=0;
                rl_redraw(buf,len,pos,old_len);
            }
            continue;
        }

        /* Backspace */
        if (k == '\b' || k == 127) {
            if (pos > 0) {
                kmemmove(buf+pos-1, buf+pos, (size_t)(len-pos));
                pos--; len--; buf[len]=0;
                /* BUG FIX v7: only do visual backspace if not at col 0 */
                if (!use_vbe) {
                    terminal_putchar('\b');
                    rl_redraw(buf,len,pos,old_len);
                }
            }
            continue;
        }

        /* Tab completion */
        if (k == '\t') {
            /* Find prefix */
            int ws = pos;
            while (ws > 0 && buf[ws-1] != ' ') ws--;
            char prefix[64]; int pl = pos - ws;
            if (pl >= 63) { continue; }
            kmemcpy(prefix, buf+ws, (size_t)pl); prefix[pl] = 0;

            /* Collect matches */
            const char *matches[COMP_MAX]; int mc = 0;
            for (int i = 0; builtins[i] && mc < COMP_MAX; i++) {
                if (kstrncmp(builtins[i], prefix, (size_t)pl) == 0)
                    matches[mc++] = builtins[i];
            }
            /* SDK commands */
            sdk_cmd_t *sc = sdk_cmd_find(NULL);
            while (sc && mc < COMP_MAX) {
                if (kstrncmp(sc->name, prefix, (size_t)pl)==0) matches[mc++]=sc->name;
                sc = sc->next;
            }

            if (mc == 1) {
                /* Complete */
                const char *m = matches[0];
                int mlen = (int)kstrlen(m);
                int add = mlen - pl;
                if (len + add < maxlen - 1) {
                    kmemmove(buf+pos+add, buf+pos, (size_t)(len-pos));
                    kmemcpy(buf+pos, m+pl, (size_t)add);
                    len += add; pos += add; buf[len] = 0;
                    rl_redraw(buf,len,pos,old_len);
                }
            } else if (mc > 1) {
                con_putchar('\n');
                for (int i = 0; i < mc; i++) {
                    C_DIM(); con_write(matches[i]); con_putchar(' ');
                }
                C_NRM(); con_putchar('\n');
                print_prompt();
                if (!use_vbe) {
                    int r2,c2; terminal_get_cursor(&r2,&c2);
                    rl_prompt_col=c2; rl_prompt_row=r2;
                }
                rl_redraw(buf,len,pos,0);
            }
            continue;
        }

        /* ====== ============== ============== (UTF-8) ====== */
        if (k == KEY_UTF8) {
            int ulen = (int)kstrlen(keyboard_utf8_buf);
            if (len + ulen < RL_MAX - 1 && len + ulen < maxlen - 1) {
                kmemmove(buf+pos+ulen, buf+pos, (size_t)(len-pos));
                kmemcpy(buf+pos, keyboard_utf8_buf, (size_t)ulen);
                pos += ulen; len += ulen; buf[len] = 0;
                rl_redraw(buf, len, pos, old_len);
            }
            continue;
        }

        /* Normal printable character */
        if (k >= ' ' && k <= '~' && len < maxlen-1) {
            kmemmove(buf+pos+1, buf+pos, (size_t)(len-pos));
            buf[pos] = (char)k;
            pos++; len++; buf[len] = 0;
            rl_redraw(buf,len,pos,old_len);
        }
    }
}

void readline_v9(char *out, int maxlen) { readline_v6(out, maxlen); }

/* ====== build_abs: resolve path relative to cwd ================================================ */
static void build_abs(const char *rel, char *out) {
    if (rel[0] == '/') { kstrcpy(out, rel); return; }
    kstrcpy(out, cwd);
    if (out[kstrlen(out)-1] != '/') kstrcat(out, "/");
    kstrcat(out, rel);
}

/* ====== arg parser ============================================================================================================================================= */
static int parse_args(char *line, char **argv, int maxargc) {
    int argc = 0;
    char *p = line;
    while (*p) {
        while (*p == ' ' || *p == '\t') p++;
        if (!*p) break;
        if (argc >= maxargc-1) break;
        char q = 0;
        if (*p == '"' || *p == '\'') { q = *p++; }
        argv[argc++] = p;
        if (q) {
            while (*p && *p != q) p++;
            if (*p) *p++ = 0;
        } else {
            while (*p && *p != ' ' && *p != '\t') p++;
            if (*p) *p++ = 0;
        }
    }
    argv[argc] = NULL;
    return argc;
}

/* ====== do_sudo_auth ======================================================================================================================================= */
static int do_sudo_auth(void) {
    C_WRN(); con_write("[sudo] password: "); C_NRM();
    char pin[32]; int pp=0;
    while(1){int k=keyboard_getkey();
        if(k=='\n'||k=='\r'){pin[pp]=0;con_putchar('\n');break;}
        if((k=='\b'||k==127)&&pp>0){pp--;terminal_putchar('\b');con_erase();terminal_putchar('\b');}
        else if(k>=' '&&k<='~'&&pp<31){pin[pp++]=(char)k;con_putchar('*');}
    }
    if(kstrcmp(pin,sudo_pin)==0) return 1;
    C_ERR(); con_writeln("sudo: authentication failure"); C_NRM();
    return 0;
}

/* ====== Prompt ========================================================================================================================================================= */
void print_prompt(void) {
    /* Check custom prompt_format in kernel config */
    const char *pfmt = sysconf_get("kernel","prompt_format");
    if (pfmt && pfmt[0]) {
        /* Simple substitution: %u=user %h=host %d=cwd %$=# or $ */
        C_PRM();
        const char *p = pfmt;
        while (*p) {
            if (*p == '%' && *(p+1)) {
                p++;
                if (*p=='u') con_write(username);
                else if (*p=='h') con_write(hostname);
                else if (*p=='d') con_write(cwd);
                else if (*p=='$') con_putchar(sudo_mode?'#':'$');
                else { con_putchar('%'); con_putchar(*p); }
                p++;
            } else {
                con_putchar(*p++);
            }
        }
        C_NRM();
        return;
    }
    /* Default prompt */
    C_PRM();
    con_write(username); con_putchar('@');
    con_write(hostname);
    C_DIM(); con_putchar(':');
    C_ACC(); con_write(cwd);
    C_NRM(); con_putchar(sudo_mode?'#':'$'); con_putchar(' ');
}

/* ====== ls helper ================================================================================================================================================ */
static void do_ls(int argc, char *argv[]) {
    int show_all = 0, long_fmt = 0;
    const char *path = cwd;
    for (int i=1;i<argc;i++){
        if(!argv[i]) break;
        if(argv[i][0]=='-'){
            for(int j=1;argv[i][j];j++){
                if(argv[i][j]=='a') show_all=1;
                if(argv[i][j]=='l') long_fmt=1;
            }
        } else path=argv[i];
    }
    char abs[128]; build_abs(path, abs);
    char names[64][VFS_NAME_MAX]; int count=0;
    vfs_listdir(abs, names, &count);
    /* BUG FIX v7: sort names so deleted files don't appear */
    for(int i=0;i<count-1;i++) for(int j=0;j<count-i-1;j++)
        if(kstrcmp(names[j],names[j+1])>0){
            char tmp[VFS_NAME_MAX]; kstrcpy(tmp,names[j]);
            kstrcpy(names[j],names[j+1]); kstrcpy(names[j+1],tmp);
        }
    for(int i=0;i<count;i++){
        size_t nl=kstrlen(names[i]);
        int is_dir=nl>0&&names[i][nl-1]=='/';
        if(!show_all && names[i][0]=='.') continue;
        if(long_fmt){
            char fp[256]; kstrcpy(fp,abs);
            if(fp[kstrlen(fp)-1]!='/') kstrcat(fp,"/");
            char nm2[VFS_NAME_MAX]; kstrcpy(nm2,names[i]);
            if(is_dir&&nm2[kstrlen(nm2)-1]=='/') nm2[kstrlen(nm2)-1]=0;
            kstrcat(fp,nm2);
            vfs_stat_t st; int has=vfs_stat(fp,&st)==0;
            C_DIM(); con_write(is_dir?"drwxr-xr-x":"-rw-r--r--");
            cprintf(" 1 root root %6u ", has?(uint32_t)st.size:0u);
            C_NRM();
            if(is_dir){C_ACC();}else{C_NRM();}
            con_writeln(names[i]); C_NRM();
        } else {
            if(is_dir){C_ACC();}else{C_NRM();}
            con_write(names[i]); con_putchar(' ');
        }
    }
    if(!long_fmt) con_putchar('\n');
    C_NRM();
}

/* ====== cat / view ============================================================================================================================================= */
static void do_cat(const char *path_arg) {
    char p[128]; build_abs(path_arg, p);
    int fd = vfs_open(p, O_RDONLY);
    if (fd < 0) { C_ERR(); cprintf("cat: %s: not found\n", path_arg); C_NRM(); return; }
    static uint8_t buf[4096]; int n;
    while ((n=vfs_read(fd,buf,sizeof(buf)-1))>0) {
        buf[n]=0; con_write((char*)buf);
    }
    vfs_close(fd);
    if (buf[n>0?n-1:0]!='\n') con_putchar('\n');
}

static void do_view(const char *path_arg) { do_cat(path_arg); }

/* ====== stat =============================================================================================================================================================== */
static void do_stat(const char *path_arg) {
    char p[128]; build_abs(path_arg, p);
    vfs_stat_t st;
    if (vfs_stat(p,&st)<0) { C_ERR(); cprintf("stat: %s: not found\n",path_arg); C_NRM(); return; }
    cprintf("  File: %s\n  Size: %u\n  Type: %s\n",
        p, (uint32_t)st.size, (st.type&VFS_DIR)?"directory":"regular file");
}

/* =================================================================================================================================================================================
 *  v10 GAMES
 * ================================================================================================================================================================================= */

/* ====== SNAKE ============================================================================================================================================================ */
#define SN_W  40
#define SN_H  20
#define SN_MAXLEN 200

void game_snake(void) {
    con_clear();
    C_HDR(); con_writeln("  SNAKE === Arrow keys to move, Q to quit"); C_NRM();
    con_writeln("");

    /* State */
    int sx[SN_MAXLEN], sy[SN_MAXLEN];
    int slen = 4;
    int dx = 1, dy = 0;
    int fx, fy;
    int score = 0;
    int dead = 0;

    /* Init snake in center */
    for (int i = 0; i < slen; i++) { sx[i] = SN_W/2 - i; sy[i] = SN_H/2; }
    fx = 10; fy = 5;

    /* Simple pseudo-random food placement using uptime */
    uint32_t rseed = sched_uptime_ticks();
    #define SN_RAND() (rseed = rseed * 1664525u + 1013904223u)

    /* Draw border helper - uses terminal directly */
    #define SN_CX  2
    #define SN_CY  3

    /* Initial draw */
    while (!dead) {
        /* Clear play area */
        for (int row = 0; row <= SN_H+1; row++) {
            terminal_set_cursor(SN_CY + row, SN_CX);
            for (int col = 0; col <= SN_W+1; col++) con_putchar(' ');
        }

        /* Draw border */
        terminal_set_cursor(SN_CY, SN_CX);
        con_putchar('+');
        for (int c = 0; c < SN_W; c++) con_putchar('-');
        con_putchar('+');

        terminal_set_cursor(SN_CY + SN_H + 1, SN_CX);
        con_putchar('+');
        for (int c = 0; c < SN_W; c++) con_putchar('-');
        con_putchar('+');

        for (int r = 1; r <= SN_H; r++) {
            terminal_set_cursor(SN_CY + r, SN_CX); con_putchar('|');
            terminal_set_cursor(SN_CY + r, SN_CX + SN_W + 1); con_putchar('|');
        }

        /* Draw food */
        terminal_set_cursor(SN_CY + 1 + fy, SN_CX + 1 + fx);
        C_ACC(); con_putchar('*'); C_NRM();

        /* Draw snake */
        for (int i = 0; i < slen; i++) {
            if (sx[i] < 0 || sx[i] >= SN_W || sy[i] < 0 || sy[i] >= SN_H) continue;
            terminal_set_cursor(SN_CY + 1 + sy[i], SN_CX + 1 + sx[i]);
            if (i == 0) { C_OK(); con_putchar('@'); }
            else        { C_NRM(); con_putchar('o'); }
        }
        C_NRM();

        /* Score */
        terminal_set_cursor(SN_CY + SN_H + 2, SN_CX);
        cprintf("Score: %d   Length: %d   (Q=quit)", score, slen);

        /* Wait for input === ~150ms polling */
        int moved = 0;
        uint32_t t0 = sched_uptime_ticks();
        while (!moved) {
            uint32_t now = sched_uptime_ticks();
            if (now - t0 > 15) break; /* 150ms at 100Hz */
            int k = keyboard_poll();
            if (!k) { __asm__ volatile("pause"); continue; }
            if (k == KEY_UP    && dy != 1)  { dx=0; dy=-1; moved=1; }
            if (k == KEY_DOWN  && dy != -1) { dx=0; dy=1;  moved=1; }
            if (k == KEY_LEFT  && dx != 1)  { dx=-1;dy=0;  moved=1; }
            if (k == KEY_RIGHT && dx != -1) { dx=1; dy=0;  moved=1; }
            if (k=='q'||k=='Q') { dead=1; moved=1; }
        }
        if (dead) break;

        /* Move snake */
        int nx = sx[0] + dx;
        int ny = sy[0] + dy;

        /* Wall collision */
        if (nx < 0 || nx >= SN_W || ny < 0 || ny >= SN_H) { dead = 1; break; }

        /* Self collision */
        for (int i = 1; i < slen; i++)
            if (sx[i] == nx && sy[i] == ny) { dead = 1; break; }
        if (dead) break;

        /* Shift body */
        for (int i = slen - 1; i > 0; i--) { sx[i]=sx[i-1]; sy[i]=sy[i-1]; }
        sx[0] = nx; sy[0] = ny;

        /* Food eaten? */
        if (nx == fx && ny == fy) {
            score += 10;
            if (slen < SN_MAXLEN) slen++;
            /* New food position */
            SN_RAND();
            fx = (int)(rseed % (uint32_t)SN_W);
            SN_RAND();
            fy = (int)(rseed % (uint32_t)SN_H);
            /* Make sure not on snake */
            for (int i = 0; i < slen; i++)
                if (sx[i]==fx && sy[i]==fy) { fx=(fx+3)%SN_W; fy=(fy+3)%SN_H; }
        }
    }

    con_clear();
    C_HDR(); con_writeln(""); con_writeln("  ~~~ GAME OVER ~~~"); C_NRM();
    cprintf("  Final score: %d   Length: %d\n\n", score, slen);
    C_DIM(); con_writeln("  Press any key to return..."); C_NRM();
    keyboard_getkey();
    con_clear();
    #undef SN_RAND
    #undef SN_CX
    #undef SN_CY
}

/* ====== TETRIS ========================================================================================================================================================= */
#define TT_W   10
#define TT_H   20
#define TT_CX   3
#define TT_CY   2

/* 7 tetrominoes, each 4 rotations, stored as 4x4 bitmask */
static const uint16_t tt_pieces[7][4] = {
    /* I */ { 0x0F00, 0x2222, 0x00F0, 0x4444 },
    /* O */ { 0x6600, 0x6600, 0x6600, 0x6600 },
    /* T */ { 0x0E40, 0x4C40, 0x4E00, 0x4640 },
    /* S */ { 0x06C0, 0x4620, 0x06C0, 0x4620 },
    /* Z */ { 0x0C60, 0x2640, 0x0C60, 0x2640 },
    /* J */ { 0x44C0, 0x8E00, 0x6440, 0x0E20 },
    /* L */ { 0x4460, 0x0E80, 0xC440, 0x2E00 },
};

static const char tt_chars[7] = { '#','O','T','S','Z','J','L' };

static uint8_t tt_board[TT_H][TT_W]; /* 0=empty, 1-7=piece color+1 */

static int tt_piece_cell(int piece, int rot, int r, int c) {
    uint16_t mask = tt_pieces[piece][rot & 3];
    int bit = r*4 + c;
    return (mask >> (15 - bit)) & 1;
}

static int tt_fits(int piece, int rot, int px, int py) {
    for (int r=0;r<4;r++) for (int c=0;c<4;c++) {
        if (!tt_piece_cell(piece, rot, r, c)) continue;
        int bx = px+c, by = py+r;
        if (bx<0||bx>=TT_W||by>=TT_H) return 0;
        if (by>=0 && tt_board[by][bx]) return 0;
    }
    return 1;
}

static void tt_place(int piece, int rot, int px, int py) {
    for (int r=0;r<4;r++) for (int c=0;c<4;c++) {
        if (!tt_piece_cell(piece, rot, r, c)) continue;
        int bx=px+c, by=py+r;
        if (by>=0&&by<TT_H&&bx>=0&&bx<TT_W) tt_board[by][bx]=(uint8_t)(piece+1);
    }
}

static int tt_clear_lines(void) {
    int cleared = 0;
    for (int r = TT_H-1; r >= 0; r--) {
        int full = 1;
        for (int c=0;c<TT_W;c++) if (!tt_board[r][c]) { full=0; break; }
        if (full) {
            cleared++;
            /* Shift rows down */
            for (int rr=r;rr>0;rr--)
                for (int c=0;c<TT_W;c++) tt_board[rr][c]=tt_board[rr-1][c];
            for (int c=0;c<TT_W;c++) tt_board[0][c]=0;
            r++; /* re-check this row */
        }
    }
    return cleared;
}

static void tt_draw_board(int piece, int rot, int px, int py, int score, int lines) {
    /* Draw border + board */
    for (int r=0;r<TT_H;r++) {
        terminal_set_cursor(TT_CY+r, TT_CX-1);
        con_putchar('|');
        for (int c=0;c<TT_W;c++) {
            terminal_set_cursor(TT_CY+r, TT_CX+c);
            uint8_t cell = tt_board[r][c];
            /* Check if active piece covers this cell */
            int in_piece = 0;
            for (int pr=0;pr<4;pr++) for (int pc=0;pc<4;pc++) {
                if (tt_piece_cell(piece,rot,pr,pc) && px+pc==c && py+pr==r)
                    in_piece=1;
            }
            if (in_piece) { C_ACC(); con_putchar(tt_chars[piece]); C_NRM(); }
            else if (cell) { C_NRM(); con_putchar('#'); }
            else con_putchar('.');
        }
        terminal_set_cursor(TT_CY+r, TT_CX+TT_W);
        con_putchar('|');
    }
    /* Bottom */
    terminal_set_cursor(TT_CY+TT_H, TT_CX-1);
    con_putchar('+');
    for (int c=0;c<TT_W;c++) con_putchar('-');
    con_putchar('+');
    /* Top label */
    terminal_set_cursor(TT_CY-1, TT_CX-1);
    C_HDR(); con_write("+--TETRIS--+"); C_NRM();
    /* Score */
    terminal_set_cursor(TT_CY+1, TT_CX+TT_W+3);
    cprintf("Score:");
    terminal_set_cursor(TT_CY+2, TT_CX+TT_W+3);
    cprintf("%d     ", score);
    terminal_set_cursor(TT_CY+4, TT_CX+TT_W+3);
    cprintf("Lines:");
    terminal_set_cursor(TT_CY+5, TT_CX+TT_W+3);
    cprintf("%d     ", lines);
    terminal_set_cursor(TT_CY+8, TT_CX+TT_W+3);
    C_DIM(); con_write("Arrows:"); 
    terminal_set_cursor(TT_CY+9, TT_CX+TT_W+3);
    con_write("move");
    terminal_set_cursor(TT_CY+10,TT_CX+TT_W+3);
    con_write("Up=rot");
    terminal_set_cursor(TT_CY+11,TT_CX+TT_W+3);
    con_write("Spc=drop");
    terminal_set_cursor(TT_CY+12,TT_CX+TT_W+3);
    con_write("Q=quit");
    C_NRM();
}

void game_tetris(void) {
    con_clear();

    /* Clear board */
    for (int r=0;r<TT_H;r++) for (int c=0;c<TT_W;c++) tt_board[r][c]=0;

    int score = 0, lines_total = 0;
    int dead = 0;
    uint32_t rseed = sched_uptime_ticks() ^ 0xDEADBEEF;
    #define TT_RAND() (rseed = rseed*1664525u+1013904223u, (int)(rseed%7u))

    int cur_piece = TT_RAND() % 7;
    int cur_rot = 0;
    int cur_x = TT_W/2 - 2;
    int cur_y = 0;
    uint32_t last_drop = sched_uptime_ticks();
    int drop_interval = 50; /* 0.5s at 100Hz */

    while (!dead) {
        /* Render */
        tt_draw_board(cur_piece, cur_rot, cur_x, cur_y, score, lines_total);

        /* Input */
        int k = keyboard_poll();
        if (k) {
            if (k=='q'||k=='Q') break;
            if (k==KEY_LEFT  && tt_fits(cur_piece,cur_rot,cur_x-1,cur_y)) cur_x--;
            if (k==KEY_RIGHT && tt_fits(cur_piece,cur_rot,cur_x+1,cur_y)) cur_x++;
            if (k==KEY_DOWN  && tt_fits(cur_piece,cur_rot,cur_x,cur_y+1)) cur_y++;
            if (k==KEY_UP) {
                int nr=(cur_rot+1)&3;
                if(tt_fits(cur_piece,nr,cur_x,cur_y)) cur_rot=nr;
            }
            if (k==' ') { /* hard drop */
                while(tt_fits(cur_piece,cur_rot,cur_x,cur_y+1)) cur_y++;
            }
        }

        /* Gravity */
        uint32_t now = sched_uptime_ticks();
        if ((int)(now - last_drop) >= drop_interval) {
            last_drop = now;
            if (tt_fits(cur_piece, cur_rot, cur_x, cur_y+1)) {
                cur_y++;
            } else {
                /* Lock piece */
                tt_place(cur_piece, cur_rot, cur_x, cur_y);
                int cl = tt_clear_lines();
                lines_total += cl;
                if (cl==1) score+=100;
                else if(cl==2) score+=300;
                else if(cl==3) score+=600;
                else if(cl==4) score+=1200;
                /* Speed up every 10 lines */
                drop_interval = 50 - (lines_total/10)*4;
                if (drop_interval < 5) drop_interval = 5;
                /* New piece */
                cur_piece = TT_RAND() % 7;
                cur_rot = 0;
                cur_x = TT_W/2-2;
                cur_y = 0;
                if (!tt_fits(cur_piece,cur_rot,cur_x,cur_y)) dead=1;
            }
        }

        /* tiny yield */
        for (int i=0;i<1000;i++) __asm__ volatile("pause");
    }

    con_clear();
    C_HDR(); con_writeln(""); con_writeln("  ~~~ GAME OVER ~~~"); C_NRM();
    cprintf("  Final score: %d   Lines: %d\n\n", score, lines_total);
    C_DIM(); con_writeln("  Press any key..."); C_NRM();
    keyboard_getkey();
    con_clear();
    #undef TT_RAND
}

/* =================================================================================================================================================================================
 *  v10 EASTER EGGS
 * ================================================================================================================================================================================= */

/* ====== MATRIX rain ========================================================================================================================================== */
static void easter_matrix(void) {
    con_clear();
    /* 80 columns, 25 rows */
    #define MX_COLS 78
    #define MX_ROWS 23
    static int  mx_pos[MX_COLS];   /* current row of each column's drop */
    static char mx_chr[MX_ROWS][MX_COLS]; /* last printed chars */

    /* Init */
    uint32_t rs = sched_uptime_ticks();
    #define MX_RAND() (rs = rs*1664525u+1013904223u)
    for (int c=0;c<MX_COLS;c++) {
        MX_RAND(); mx_pos[c] = -(int)(rs % (uint32_t)MX_ROWS);
        MX_RAND(); /* consume extra rand */
    }
    for (int r=0;r<MX_ROWS;r++) for (int c=0;c<MX_COLS;c++) mx_chr[r][c]=' ';

    /* Katakana-ish ASCII stand-ins */
    static const char glyphs[] = "abcdefghijklmnopqrstuvwxyz0123456789@#$%^&*";
    int glen = (int)kstrlen(glyphs);

    terminal_set_color(VGA_GREEN, VGA_BLACK);
    terminal_set_cursor(MX_ROWS+1, 0);
    C_DIM(); con_write("  [ Press any key to exit Matrix mode ]"); C_NRM();

    uint32_t last_tick = sched_uptime_ticks();
    int running = 1;
    while (running) {
        /* Check key */
        if (keyboard_poll()) running = 0;

        uint32_t now = sched_uptime_ticks();
        if ((int)(now - last_tick) < 2) continue; /* ~20ms frames */
        last_tick = now;

        for (int c = 0; c < MX_COLS; c++) {
            int r = mx_pos[c];
            if (r >= 0 && r < MX_ROWS) {
                /* Head: bright green */
                MX_RAND(); char ch = glyphs[rs % (uint32_t)glen];
                mx_chr[r][c] = ch;
                terminal_set_color(VGA_LIGHT_GREEN, VGA_BLACK);
                terminal_set_cursor(r, c+1);
                con_putchar(ch);
                /* Tail: dim green */
                if (r > 0) {
                    terminal_set_color(VGA_GREEN, VGA_BLACK);
                    terminal_set_cursor(r-1, c+1);
                    con_putchar(mx_chr[r-1][c]);
                }
                if (r > 4) {
                    terminal_set_color(VGA_DARK_GREY, VGA_BLACK);
                    terminal_set_cursor(r-4, c+1);
                    con_putchar(' ');
                }
            }
            /* Advance by speed */
            mx_pos[c]++;
            if (mx_pos[c] > MX_ROWS + 5) {
                MX_RAND(); mx_pos[c] = -(int)(rs % (uint32_t)(MX_ROWS/2));
                MX_RAND(); /* consume */
            }
        }
    }
    C_NRM();
    con_clear();
    #undef MX_RAND
    #undef MX_COLS
    #undef MX_ROWS
}

/* ====== ALYA ascii art ================================================================================================================================= */
static void easter_alya(void) {
    con_clear();
    terminal_set_color(VGA_LIGHT_MAGENTA, VGA_BLACK);
    con_writeln("");
    con_writeln("      ,---.    ,---.  .--.      .--.     ___    ");
    con_writeln("     /    \\  /    /  |  |\\    /  |   .'   `.  ");
    con_writeln("    |  .-. \\|  .-'   |  | \\  /  |  /   .-\"\" \\ ");
    con_writeln("    |  | |  |  `--.  |  |  \\/   | /   /      | ");
    con_writeln("    |  | |  |  .-. ' |  |       | |   |      | ");
    con_writeln("    |  `-'  |  | |  \\|  |       |  \\   \\    /  ");
    con_writeln("    `-------'--' '--' `--'       `'  `.___.''  ");
    con_writeln("");
    terminal_set_color(VGA_WHITE, VGA_BLACK);
    con_writeln("       ========== (======) ==================== ==================");
    terminal_set_color(VGA_LIGHT_CYAN, VGA_BLACK);
    con_writeln("    ========================================================================================================================");
    con_writeln("    ===  ============... ======== ==== ============ ==============   ===");
    con_writeln("    ===  (==... ================ == ========, ==========)      ===");
    con_writeln("    ========================================================================================================================");
    con_writeln("");
    terminal_set_color(VGA_LIGHT_MAGENTA, VGA_BLACK);
    /* Small chibi */
    con_writeln("          (\\(\\");
    con_writeln("          ( -.-)   < ==== ============ ==== ========!");
    con_writeln("          o_(\")(\")`");
    con_writeln("");
    terminal_set_color(VGA_DARK_GREY, VGA_BLACK);
    con_writeln("  [ ==== ========== \"Alya Sometimes Hides Her Feelings in Russian\" ]");
    con_writeln("  [ ============== ====-============ === caramelY OS v10 \"Green Tea\" easter egg  ]");
    C_NRM(); con_writeln("");
    C_DIM(); con_writeln("  Press any key..."); C_NRM();
    keyboard_getkey();
    con_clear();
}

/* ====== CRASH === Windows BSOD =============================================================================================================== */
static void easter_crash(void) {
    /* Fill screen with blue */
    terminal_set_color(VGA_WHITE, VGA_BLUE);
    con_clear();
    /* Position text in center */
    for (int i=0;i<4;i++) con_putchar('\n');
    con_writeln("                    :(");
    con_writeln("");
    con_writeln("    Your PC ran into a problem and needs to restart.");
    con_writeln("    We're just collecting some error info, and then");
    con_writeln("    we'll restart for you.");
    con_writeln("");
    con_writeln("    0% complete");
    con_writeln("");
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLUE);
    con_writeln("    Stop code: CARAMELUK_KERNEL_OVERFLOW");
    con_writeln("    What failed: caramelsh.exe === command 'crash' executed");
    con_writeln("");
    con_writeln("    For more information about this issue and possible fixes,");
    con_writeln("    visit https://carameluk.local/bsod");
    con_writeln("");
    terminal_set_color(VGA_WHITE, VGA_BLUE);
    con_writeln("    QR code: [####] <- imagine a QR code here");
    con_writeln("");
    con_writeln("    Error code: 0x0000DEAD  (0xCAFEBABE 0x00000000)");
    con_writeln("");
    C_DIM();
    con_writeln("    (This is a caramelY OS v10 easter egg. Press any key.)");
    C_NRM();
    keyboard_getkey();
    /* Restore */
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
    con_clear();
    C_NRM();
}

/* ====== HELLOWORLD easter egg === ======== ======================================================================================= */
static void easter_helloworld(void) {
    terminal_set_color(VGA_LIGHT_GREEN, VGA_BLACK);
    con_writeln("");
    /* ======================== ======== helloworld == ============ ============ */
    const char *styles[] = {
        "Hello, World!",
        "hello world",
        "HELLO WORLD!!!",
        "H3ll0 W0rld",
        "Hello, World! (from caramelY OS v10)",
        "printf(\"Hello, World!\\n\");",
        "cout << \"Hello, World!\" << endl;",
        "print('Hello, World!')",
        "System.out.println(\"Hello, World!\");",
        "echo 'Hello, World!'",
        "console.log('Hello, World!');",
        "fmt.Println(\"Hello, World!\")",
        "puts \"Hello, World!\"",
        "(display \"Hello, World!\")",
        "PRINT 'Hello, World!'",
        "Hello, World!  <-- ====== ================",
        "write(*, *) 'Hello, World!'",
        "MsgBox \"Hello, World!\"",
        "writeln('Hello, World!');",
        "NSLog(@\"Hello, World!\");",
        NULL
    };
    int count = 0;
    for (int i = 0; styles[i]; i++) count++;

    uint32_t rs = sched_uptime_ticks() ^ 0xABCD1234;
    #define HW_RAND() (rs = rs * 1664525u + 1013904223u)

    for (int i = 0; i < 999999; i++) {
        int k=keyboard_poll(); if(k==3||k==27) break;
        HW_RAND();
        int style_idx = (int)(rs % (uint32_t)count);
        /* ================== ======== */
        uint8_t colors[] = {
            VGA_LIGHT_GREEN, VGA_LIGHT_CYAN, VGA_LIGHT_BLUE,
            VGA_LIGHT_MAGENTA, VGA_YELLOW, VGA_WHITE, VGA_LIGHT_RED
        };
        HW_RAND();
        terminal_set_color(colors[rs % 7], VGA_BLACK);
        cprintf("[%3d] %s\n", i + 1, styles[style_idx]);
    }
    C_NRM();
    con_writeln("");
    C_DIM(); con_writeln("  [ ======================== ================: Hello, World! x200 ]"); C_NRM();
    con_writeln("");
    #undef HW_RAND
}

/* ====== BROWSER === ================== ============== ============================================================================================= */
/* ==================== "==========" === CaramelNet */
static const struct {
    const char *url;
    const char *title;
    const char *content;
} browser_sites[] = {
    { "home", "CaramelUK Start Page",
      "\n"
      "  ============================================================================================================================================================\n"
      "  ===        CaramelNet Browser v1.0                   ===\n"
      "  ===        caramelY OS v10 \"Green Tea\" built-in           ===\n"
      "  ============================================================================================================================================================\n"
      "\n"
      "  ================== ========== (========== url ========== ==============):\n"
      "\n"
      "  [1] caramel://home      === ====== ================\n"
      "  [2] caramel://about     === == ============== CaramelUK\n"
      "  [3] caramel://help      === ============== ==== ================\n"
      "  [4] caramel://news      === ============== caramelY OS v10\n"
      "  [5] caramel://games     === ========\n"
      "  [6] caramel://sdk       === ======================== SDK\n"
      "  [7] caramel://cede      === ============ .cede ==============\n"
      "\n"
      "  ========== URL: caramel://<========>  ====== ============ <========>\n"
    },
    { "about", "About CaramelUK",
      "\n"
      "  caramelY OS v10.0 \"Green Tea\"\n"
      "  =======================================================================================\n"
      "  ====================== : x86 32-bit (i386)\n"
      "  ==================   : GRUB Multiboot1\n"
      "  ========        : monolithic, ~2200 ========== C\n"
      "  ================ ==== : ramfs + CaramelFS (CFS) ==== ==========\n"
      "  ==============     : VGA 80x25 / VBE 800x600x32\n"
      "  ============== ========: CaramelDE v2 (caramel/windows/mac)\n"
      "  ========        : Snake, Tetris\n"
      "  ================    : alya, crash, matrix, helloworld, android, v10\n"
      "  ============      : .cede v2 (ELF+============+==============)\n"
      "  ==============     : CaramelNet v1.0 (====================)\n"
      "\n"
      "  ================    : CaramelUK Open License\n"
      "  ====================== : caramel://sdk\n"
    },
    { "help", "CaramelUK Help",
      "\n"
      "  ================ ==============:\n"
      "  ===================================================\n"
      "  ls / ll / la       === ============ ============\n"
      "  cat / view         === ================ ==========\n"
      "  mkdir / rm / cp    === ============ == ==============\n"
      "  snake / tetris     === ========\n"
      "  matrix / alya      === ================\n"
      "  crash / helloworld === ================\n"
      "  browser <url>      === ======== ==============\n"
      "  de                 === ============== ======== (VBE)\n"
      "  desktop style ...  === ========== ========== DE\n"
      "  kernel <key> <val> === ================== ========\n"
      "  config create      === ============ ==================\n"
      "  Alt+C              === ============ ================== (============== ==============)\n"
      "  pkg install <.cede>=== ================== ============\n"
      "  sdk info           === SDK ========================\n"
      "\n"
      "  ============ ============: help\n"
    },
    { "news", "CaramelUK News",
      "\n"
      "  ====== caramelY OS v10.0 \"Green Tea\" === ====== ============ ======\n"
      "\n"
      "  ==== ========\n"
      "     === Snake === ======================== ============ 40x20\n"
      "     === Tetris === ====== 7 ==========, ==============, hard drop\n"
      "\n"
      "  ==== ================\n"
      "     === matrix  === ================ ==========\n"
      "     === alya    === ASCII-====== ==== ==========\n"
      "     === crash   === Windows BSOD\n"
      "     === helloworld === 200 ========== Hello World!\n"
      "\n"
      "  =======  ============== ========\n"
      "     === ========== Windows (taskbar ========== + Start)\n"
      "     === ========== Mac (menubar + dock)\n"
      "     === ================== ======, wallpaper ==========\n"
      "\n"
      "  ======  ========\n"
      "     === Alt+C === ============ ================== == ========== ============\n"
      "     === [command] ============ == system.conf\n"
      "     === kernel_name, prompt_format, disable_cmd\n"
      "     === ================== ========== ====== ================ ========== GRUB\n"
      "\n"
      "  ==== ============\n"
      "     === .cede v2 === ==================== ============\n"
      "     === ================== ================ caramel://cede\n"
    },
    { "games", "CaramelUK Games",
      "\n"
      "  ====== ======== == caramelY OS v10 ======\n"
      "\n"
      "  SNAKE (==============: snake)\n"
      "  ===============================================================\n"
      "  ======================== ============. ======== 40x20.\n"
      "  ====================: ==============. Q === ==========.\n"
      "  ======: * (+10 ==========). ======================== = game over.\n"
      "\n"
      "  TETRIS (==============: tetris)\n"
      "  ========================================================================\n"
      "  ====== 7 ========== (I O T S Z J L).\n"
      "  === === === ================, === === ==============\n"
      "  ============ === ============== ========== ========\n"
      "  100/300/600/1200 ========== ==== 1/2/3/4 ==========\n"
      "  ================== ============ 10 ==========. Q === ==========.\n"
      "\n"
      "  ======================: Pong, Minesweeper, Breakout\n"
    },
    { "sdk", "CaramelUK SDK Documentation",
      "\n"
      "  ====== caramelY OS SDK v10.0 ======\n"
      "\n"
      "  ====================== ============:\n"
      "    sdk_cmd_register(\"mycommand\", \"================\", my_fn);\n"
      "\n"
      "  ======== ========:\n"
      "    sdk_hook_register(HOOK_BOOT_LATE, fn, ctx);\n"
      "    sdk_hook_register(HOOK_TICK, fn, ctx);\n"
      "\n"
      "  ========:\n"
      "    sdk_theme_register(&my_scheme);\n"
      "\n"
      "  ==================:\n"
      "    sdk_env_set(\"VAR\", \"value\");\n"
      "    sdk_env_get(\"VAR\");\n"
      "\n"
      "  ==============:\n"
      "    sdk_hexdump(buf, size, offset);\n"
      "    sdk_cpuid(&info);\n"
      "    sdk_sleep_ms(ms);\n"
      "    sdk_serial_write(str);\n"
      "\n"
      "  ============ .cede: caramel://cede\n"
    },
    { "cede", "CaramelUK .cede Package Format",
      "\n"
      "  ====== ============ ============== .cede v2 ======\n"
      "\n"
      "  ================== ==========:\n"
      "    [cede_header_t  512 ========]\n"
      "    [cede_section_t == N  (==== 64 ==========)]\n"
      "    [============ ============, ============]\n"
      "\n"
      "  ======== ============:\n"
      "    CEDE_SEC_ELF    (1) === ELF32 ====================== ========\n"
      "    CEDE_SEC_DATA   (2) === ======== ============\n"
      "    CEDE_SEC_CONF   (3) === ============ == /uiu/etc/\n"
      "    CEDE_SEC_INIT   (4) === ============ ==================\n"
      "    CEDE_SEC_LIB    (5) === ====================\n"
      "    CEDE_SEC_ICON   (6) === ============ ====================\n"
      "    CEDE_SEC_MAN    (7) === man-================\n"
      "    CEDE_SEC_RES    (8) === ============== (============, ==========)\n"
      "\n"
      "  ================ ============:\n"
      "    pkg create <name> <elf>   === ================ ELF\n"
      "    pkg install <file.cede>   === ====================\n"
      "    pkg info    <file.cede>   === ====================\n"
      "    pkg list                  === ==========================\n"
      "    pkg remove  <name>        === ==============\n"
      "\n"
      "  Magic: 0xCEDE0005  Version: 2\n"
    },
    { NULL, NULL, NULL }
};

static void cmd_browser(int argc, char *argv[]) {
    char url[128] = "home";

    /* ============ URL */
    if (argc >= 2) {
        /* ============== caramel:// ============== */
        const char *raw = argv[1];
        if (kstrncmp(raw, "caramel://", 10) == 0) raw += 10;
        else if (kstrncmp(raw, "http://", 7) == 0) {
            C_WRN();
            cprintf("  [browser] ============== URL: %s\n", argv[1]);
            con_writeln("  HTTP ==== ============================ (====== ========== TCP/IP).");
            con_writeln("  ================ ============: caramel:// ==========.");
            con_writeln("  ========== 'browser' ====== ============ ================== ============.");
            C_NRM(); return;
        }
        kstrcpy(url, raw);
        /* ============== trailing slash */
        int ul = (int)kstrlen(url);
        if (ul > 1 && url[ul-1] == '/') url[ul-1] = 0;
    }

    /* ======== ======== */
    for (int i = 0; browser_sites[i].url; i++) {
        if (kstrcmp(url, browser_sites[i].url) == 0) {
            con_clear();
            /* Header */
            C_HDR();
            cprintf("  CaramelNet Browser  [caramel://%s]\n", url);
            C_DIM();
            con_writeln("  ===============================================================================================================================================================");
            C_ACC();
            cprintf("  %s\n", browser_sites[i].title);
            C_DIM();
            con_writeln("  ===============================================================================================================================================================");
            C_NRM();
            /* Content */
            con_write(browser_sites[i].content);
            /* Footer */
            C_DIM();
            con_writeln("\n  ===============================================================================================================================================================");
            con_writeln("  Q===========  ========================= ========  Enter=================");
            C_NRM();
            /* Interactive prompt */
            while (1) {
                C_ACC(); con_write("  caramel://"); C_NRM();
                char input[64]; readline_v6(input, 64);
                if (!input[0] || input[0]=='q' || input[0]=='Q') break;
                /* ====================== ========== ====== ================== */
                char nav_cmd[80]; kstrcpy(nav_cmd, "browser ");
                kstrcat(nav_cmd, input);
                dispatch(nav_cmd);
                return; /* ========== ================ ============== */
            }
            return;
        }
    }

    /* ======== ==== ============ */
    C_ERR();
    cprintf("  browser: ================ 'caramel://%s' ==== ==============\n", url);
    C_NRM();
    con_writeln("  ================== ==========:");
    for (int i = 0; browser_sites[i].url; i++)
        cprintf("    caramel://%-12s === %s\n", browser_sites[i].url, browser_sites[i].title);
}

/* ========= v10.0 ========== ======== ============================================================================================================================== */

void game_pong(void) {
    con_clear();
    C_HDR(); con_writeln("  PONG === W/S===========, Up/Down=============, Q==========="); C_NRM();
    #define PN_W 58
    #define PN_H 18
    int bx=PN_W/2,by=PN_H/2,bdx=1,bdy=1,l1=PN_H/2-2,l2=PN_H/2-2,sc1=0,sc2=0;
    while(1){
        for(int r=0;r<=PN_H+1;r++){
            terminal_set_cursor(3+r,3);
            if(r==0||r==PN_H+1){for(int c=0;c<=PN_W+1;c++)con_putchar(r==0?'_':'-');}
            else{
                con_putchar('|');
                for(int c=1;c<=PN_W;c++){
                    int row=r-1;
                    if(c==1&&row>=l1&&row<=l1+3){C_OK();con_putchar('#');C_NRM();}
                    else if(c==PN_W&&row>=l2&&row<=l2+3){C_ACC();con_putchar('#');C_NRM();}
                    else if(c==bx&&row==by){C_WRN();con_putchar('O');C_NRM();}
                    else if(c==PN_W/2)con_putchar(':');
                    else con_putchar(' ');
                }
                con_putchar('|');
            }
        }
        terminal_set_cursor(3+PN_H+2,3);
        cprintf("  P1=%d  P2=%d   W/S=left  Up/Dn=right  Q=quit",sc1,sc2);
        int k=keyboard_poll();
        if(k=='q'||k=='Q')break;
        if(k=='w'||k=='W'){if(l1>0)l1--;} if(k=='s'||k=='S'){if(l1<PN_H-4)l1++;}
        if(k==KEY_UP){if(l2>0)l2--;} if(k==KEY_DOWN){if(l2<PN_H-4)l2++;}
        bx+=bdx; by+=bdy;
        if(by<=0||by>=PN_H-1)bdy=-bdy;
        if(bx<=1&&by>=l1&&by<=l1+3)bdx=1;
        if(bx>=PN_W&&by>=l2&&by<=l2+3)bdx=-1;
        if(bx<=0){sc2++;bx=PN_W/2;by=PN_H/2;bdx=1;}
        if(bx>=PN_W+1){sc1++;bx=PN_W/2;by=PN_H/2;bdx=-1;}
        for(int i=0;i<600000;i++)__asm__ volatile("pause");
    }
    con_clear(); C_HDR(); cprintf("\n  PONG P1:%d P2:%d\n\n",sc1,sc2); C_NRM();
    C_DIM();con_writeln("  Press any key...");C_NRM();keyboard_getkey();con_clear();
    #undef PN_W
    #undef PN_H
}

void game_breakout(void) {
    con_clear();
    C_HDR(); con_writeln("  BREAKOUT === Arrows=paddle, Space=launch, Q=quit"); C_NRM();
    #define BK_W 40
    #define BK_H 20
    static uint8_t bk[5][20];
    for(int r=0;r<5;r++)for(int c=0;c<20;c++)bk[r][c]=1;
    int px=BK_W/2-3,pw=7,bx=BK_W/2,by=BK_H-3,bdx=1,bdy=-1,launched=0,score=0,lives=3;
    while(lives>0){
        for(int r=0;r<=BK_H+1;r++){
            terminal_set_cursor(2+r,3);
            if(r==0||r==BK_H+1){for(int c=0;c<=BK_W+1;c++)con_putchar(r==0?'_':'-');}
            else{
                con_putchar('|');
                for(int c=0;c<BK_W;c++){
                    int row=r-1;
                    if(row<5&&(c/2)<20&&bk[row][c/2]){
                        if(c%2==0){C_ACC();con_putchar('[');}else{con_putchar(']');C_NRM();}
                    }else if(row==BK_H-2&&c>=px&&c<px+pw){C_OK();con_putchar('=');C_NRM();}
                    else if(c==bx&&row==by){C_WRN();con_putchar('*');C_NRM();}
                    else con_putchar(' ');
                }
                con_putchar('|');
            }
        }
        terminal_set_cursor(2+BK_H+2,3);
        cprintf("  Score:%d Lives:%d  [<>=move Spc=launch Q=quit]",score,lives);
        int k=keyboard_poll();
        if(k=='q'||k=='Q')break;
        if(k==KEY_LEFT&&px>0)px--; if(k==KEY_RIGHT&&px<BK_W-pw)px++;
        if(k==' '&&!launched)launched=1;
        if(launched){
            bx+=bdx;by+=bdy;
            if(bx<=0){bx=0;bdx=1;} if(bx>=BK_W-1){bx=BK_W-1;bdx=-1;}
            if(by<=0){by=0;bdy=1;}
            if(by==BK_H-2&&bx>=px&&bx<px+pw)bdy=-1;
            if(by>=BK_H-1){lives--;bx=px+pw/2;by=BK_H-3;launched=0;}
            if(by>=0&&by<5&&(bx/2)<20&&bk[by][bx/2]){bk[by][bx/2]=0;score+=10;bdy=1;}
        }else{bx=px+pw/2;}
        for(int i=0;i<800000;i++)__asm__ volatile("pause");
    }
    con_clear(); C_HDR(); cprintf("\n  BREAKOUT Score:%d\n\n",score); C_NRM();
    C_DIM();con_writeln("  Press any key...");C_NRM();keyboard_getkey();con_clear();
    #undef BK_W
    #undef BK_H
}

/* ========= v10.0 ========== ================ ============================================================================================================ */

static void easter_doom(void) {
    con_clear();
    terminal_set_color(VGA_LIGHT_RED,VGA_BLACK);
    con_writeln(""); con_writeln("  +-+-+-+-+");
    con_writeln("  |D|O|O|M|"); con_writeln("  +-+-+-+-+"); con_writeln("");
    terminal_set_color(VGA_LIGHT_GREY,VGA_BLACK);
    con_writeln("  id Software, 1993");
    con_writeln("  ============== WAD ======== === ==== == ====== ======== pong, breakout, snake, tetris!");
    con_writeln(""); terminal_set_color(VGA_LIGHT_RED,VGA_BLACK);
    con_writeln("  E1M1: At Doom's Gate playing... (== ========== ======================)");
    C_NRM(); con_writeln(""); C_DIM(); con_writeln("  Press any key..."); C_NRM();
    keyboard_getkey(); con_clear();
}

static void easter_glitch(void) {
    con_clear();
    uint32_t rs=sched_uptime_ticks()^0x6C697463u;
    #define GR() (rs=rs*1664525u+1013904223u)
    const char gl[]="@#$%^&*!?~<>/|+=ABCDabcd0123";
    int glen=(int)kstrlen(gl);
    for(int row=0;row<22;row++){
        for(int col=0;col<78;col++){
            GR();terminal_set_color((uint8_t)(rs%15)+1,(uint8_t)((rs>>4)%8));
            GR();con_putchar(gl[rs%((uint32_t)glen)]);
        }con_putchar('\n');
    }
    for(int i=0;i<4000000;i++)__asm__ volatile("pause");
    terminal_set_color(VGA_WHITE,VGA_RED);
    terminal_set_cursor(10,22);con_write("  SYSTEM GLITCH DETECTED!  ");
    terminal_set_cursor(11,22);con_write("  ============================... 3...2...1  ");
    for(int i=0;i<6000000;i++)__asm__ volatile("pause");
    C_NRM();con_clear();C_OK();con_writeln("\n  Just kidding. CaramelUK is fine :)");C_NRM();
    C_DIM();con_writeln("  Press any key...");C_NRM();keyboard_getkey();con_clear();
    #undef GR
}

static void easter_rickroll(void) {
    con_clear();
    terminal_set_color(VGA_LIGHT_CYAN,VGA_BLACK);con_writeln("");
    con_writeln("  ~ Never gonna give you up ~");
    con_writeln("  ~ Never gonna let you down ~");
    con_writeln("  ~ Never gonna run around and desert you ~");
    con_writeln("");terminal_set_color(VGA_YELLOW,VGA_BLACK);
    con_writeln("  Rickroll'd by caramelY OS v10.0 Green Tea!");
    C_NRM();con_writeln("");C_DIM();con_writeln("  Press any key...");C_NRM();
    keyboard_getkey();con_clear();
}

static void cmd_desktop(int argc, char *argv[]) {
    if (argc < 2) {
        const char *st = sysconf_get("desktop","style");
        const char *bg = sysconf_get("desktop","bg_color");
        const char *wp = sysconf_get("desktop","wallpaper");
        C_HDR(); con_writeln("CaramelDE Desktop Settings"); C_NRM();
        cprintf("  style     : %s\n", st?st:"caramel");
        cprintf("  bg_color  : %s\n", bg?bg:"default");
        cprintf("  wallpaper : %s\n", wp?wp:"(none)");
        con_writeln("\nUsage:");
        con_writeln("  desktop style  <caramel|windows|mac>");
        con_writeln("  desktop bg     <color_name|default>");
        con_writeln("  desktop wallpaper <text>");
        con_writeln("  desktop reset");
        con_writeln("  desktop apply  (restart DE to apply changes)");
        return;
    }

    if (!kstrcmp(argv[1],"style")) {
        if (argc < 3) { C_ERR(); con_writeln("desktop style: missing mode"); C_NRM(); return; }
        if (kstrcmp(argv[2],"caramel")!=0 && kstrcmp(argv[2],"windows")!=0 && kstrcmp(argv[2],"mac")!=0) {
            C_ERR(); con_writeln("desktop style: caramel | windows | mac"); C_NRM(); return;
        }
        sysconf_set("desktop","style",argv[2]);
        sysconf_save();
        C_OK(); cprintf("Desktop style set to '%s'. Type 'de' to apply.\n", argv[2]); C_NRM();
    }
    else if (!kstrcmp(argv[1],"bg")) {
        if (argc < 3) { C_ERR(); con_writeln("desktop bg: missing color"); C_NRM(); return; }
        sysconf_set("desktop","bg_color",argv[2]);
        sysconf_save();
        C_OK(); cprintf("Desktop background color set to '%s'.\n", argv[2]); C_NRM();
    }
    else if (!kstrcmp(argv[1],"wallpaper")) {
        if (argc < 3) { sysconf_set("desktop","wallpaper",""); sysconf_save(); C_OK(); con_writeln("Wallpaper cleared."); C_NRM(); return; }
        sysconf_set("desktop","wallpaper",argv[2]);
        sysconf_save();
        C_OK(); cprintf("Wallpaper text set to '%s'.\n", argv[2]); C_NRM();
    }
    else if (!kstrcmp(argv[1],"reset")) {
        sysconf_set("desktop","style","caramel");
        sysconf_set("desktop","bg_color","default");
        sysconf_set("desktop","wallpaper","");
        sysconf_save();
        C_OK(); con_writeln("Desktop reset to defaults."); C_NRM();
    }
    else if (!kstrcmp(argv[1],"apply")) {
        C_WRN(); con_writeln("Restart DE with 'de' to apply changes."); C_NRM();
    }
    else {
        C_ERR(); cprintf("desktop: unknown subcommand '%s'\n", argv[1]); C_NRM();
    }
}

/* =================================================================================================================================================================================
 *  v10 KERNEL CONFIG COMMAND
 * ================================================================================================================================================================================= */
static void cmd_kernel_cfg(int argc, char *argv[]) {
    if (argc < 2) {
        C_HDR(); con_writeln("caramelY OS v10 Kernel Configuration"); C_NRM();
        con_writeln("  [kernel] section keys in /uiu/etc/system.conf:\n");
        const struct { const char *k; const char *desc; } opts[] = {
            {"kernel_name",    "OS display name (e.g. MyOS)"},
            {"hostname_color", "Prompt hostname color 0-15"},
            {"boot_msg",       "Custom boot message"},
            {"prompt_format",  "Prompt: %u=user %h=host %d=cwd %$=sigil"},
            {"disable_cmd",    "Comma-list of disabled commands"},
            {"accent_char",    "Char used in decorations (default *)"},
            {"motd_color",     "MOTD text color 0-15"},
            {"sidebar_info",   "Extra info line in 'info' output"},
            {NULL,NULL}
        };
        for (int i=0;opts[i].k;i++) {
            C_ACC(); cprintf("  %-18s", opts[i].k); C_NRM();
            cprintf(": %s\n", opts[i].desc);
        }
        con_writeln("\nUsage: kernel <key> <value>");
        con_writeln("       kernel show");
        con_writeln("       kernel save");
        return;
    }

    if (!kstrcmp(argv[1],"show")) {
        C_HDR(); con_writeln("[kernel] config:"); C_NRM();
        const char *keys[] = {"kernel_name","hostname_color","boot_msg","prompt_format",
                              "disable_cmd","accent_char","motd_color","sidebar_info",NULL};
        for (int i=0;keys[i];i++) {
            const char *v = sysconf_get("kernel",keys[i]);
            C_ACC(); cprintf("  %-18s", keys[i]); C_NRM();
            cprintf("= %s\n", v?v:"(unset)");
        }
        return;
    }
    if (!kstrcmp(argv[1],"save")) {
        sysconf_save();
        C_OK(); con_writeln("Kernel config saved."); C_NRM();
        return;
    }

    if (argc < 3) { C_ERR(); con_writeln("kernel: usage: kernel <key> <value>"); C_NRM(); return; }
    sysconf_set("kernel", argv[1], argv[2]);
    /* Apply immediately where possible */
    if (!kstrcmp(argv[1],"kernel_name")) {
        /* Update SDK personality */
        sdk_personality_t pers;
        const sdk_personality_t *cur = sdk_personality_get();
        kstrcpy(pers.os_name,    argv[2]);
        kstrcpy(pers.os_version, cur->os_version);
        kstrcpy(pers.os_codename,cur->os_codename);
        kstrcpy(pers.os_author,  cur->os_author);
        kstrcpy(pers.os_motd,    cur->os_motd);
        sdk_personality_set(&pers);
        C_OK(); cprintf("Kernel name changed to '%s' (live).\n", argv[2]); C_NRM();
    } else {
        C_OK(); cprintf("kernel.%s = %s\n", argv[1], argv[2]); C_NRM();
    }
}

/* =================================================================================================================================================================================
 *  CONFIG CREATE === interactive wizard
 * ================================================================================================================================================================================= */
static void cmd_config_create(void) {
    C_HDR(); con_writeln("====================================================================================================================================");
    con_writeln(          "===  caramelY OS v10 Config Creator             ===");
    con_writeln(          "===  Alt+C to open this at any time          ===");
    con_writeln(          "====================================================================================================================================");
    C_NRM(); con_writeln("");

    char buf[128];
    C_WRN(); con_write("  Hostname ["); con_write(hostname); con_write("]: "); C_NRM();
    readline_v6(buf,64); if(buf[0]) { kstrcpy(hostname,buf); sysconf_set("system","hostname",hostname); }

    C_WRN(); con_write("  OS name  [CaramelUK]: "); C_NRM();
    readline_v6(buf,64); if(buf[0]) { sysconf_set("kernel","kernel_name",buf); }

    C_WRN(); con_write("  Prompt format (blank=default, %u@%h:%d%$): "); C_NRM();
    readline_v6(buf,128); if(buf[0]) sysconf_set("kernel","prompt_format",buf);

    C_WRN(); con_write("  Sudo PIN ["); con_write(sudo_pin); con_write("]: "); C_NRM();
    readline_v6(buf,16); if(buf[0]) { kstrcpy(sudo_pin,buf); sysconf_set("system","sudo_pin",buf); }

    C_WRN(); con_write("  Theme (0-7, blank=skip): "); C_NRM();
    readline_v6(buf,4);
    if(buf[0]>='0'&&buf[0]<='7') {
        int id=buf[0]-'0';
        terminal_set_scheme((scheme_id_t)id);
        sysconf_set("console","theme",buf);
    }

    C_WRN(); con_write("  Boot message (blank=skip): "); C_NRM();
    readline_v6(buf,128); if(buf[0]) sysconf_set("kernel","boot_msg",buf);

    C_WRN(); con_write("  Desktop style (caramel/windows/mac, blank=skip): "); C_NRM();
    readline_v6(buf,16);
    if(!kstrcmp(buf,"windows")||!kstrcmp(buf,"mac")||!kstrcmp(buf,"caramel"))
        sysconf_set("desktop","style",buf);

    sysconf_save();
    con_writeln("");
    C_OK(); con_writeln("  Config saved to /uiu/etc/system.conf"); C_NRM();
    con_writeln("");
}

/* =================================================================================================================================================================================
 *  info / fastfetch
 * ================================================================================================================================================================================= */
static void do_info(void) {
    const sdk_personality_t *pers = sdk_personality_get();
    /* Check custom kernel_name */
    const char *kname = sysconf_get("kernel","kernel_name");
    C_HDR();
    con_writeln("   ____                          _   _   _ _  __    ___  ____");
    con_writeln("  / ___|__ _ _ __ __ _ _ __ ___ | | | | | | |/ /   / _ \\/ ___|");
    con_writeln(" | |   / _` | '__/ _` | '_ ` _ \\| | | | | | ' /   | | | \\___ \\");
    con_writeln(" | |__| (_| | | | (_| | | | | | | |_| | | | . \\   | |_| |___) |");
    con_writeln("  \\____\\__,_|_|  \\__,_|_| |_| |_|\\___/|_|_|\\_\\   \\___/|____/");
    C_DIM(); con_writeln("                              v10.0  \"Green Tea\""); C_NRM();
    con_writeln("");
    sdk_cpuid_t cpu; sdk_cpuid(&cpu);
    char upb[32]; uint32_t s=sched_uptime_ticks()/100;
    ksnprintf(upb,sizeof(upb),"%uh %um %us",s/3600,(s/60)%60,s%60);
    const char *sidebar = sysconf_get("kernel","sidebar_info");
    struct { const char *k; const char *v; } rows[] = {
        {"OS",       kname ? kname : pers->os_name},
        {"Version",  "10.0.0"},
        {"Codename", "Green Tea"},
        {"Arch",     CARAMELUK_ARCH},
        {"Boot",     "GRUB Multiboot"},
        {"Mode",     live_mode?"LIVE (RAM)":"INSTALLED (disk)"},
        {"Display",  use_vbe?"VBE 800x600x32":"VGA 80x25 + 500-line scroll"},
        {"CPU",      cpu.brand[0]?cpu.brand:cpu.vendor},
        {"Themes",   "8 built-in + runtime SDK themes"},
        {"Shell",    "caramelsh v10 (games, easter eggs, Alt+C config)"},
        {"Net",      net.initialized?net_mac_str():"not found"},
        {"Disk",     disk_count>0?"ATA PIO + CaramelFS":"no drive"},
        {"DE",       "CaramelDE v2 (caramel/windows/mac styles)"},
        {"SDK",      "ossdk: hooks/cmds/drivers/themes/env/serial/cpuid"},
        {"Uptime",   upb},
        {"Games",    "snake  tetris  pong  breakout  maze"},
        {"Easter",   "alya  crash  matrix"},
        {"Extra",    sidebar ? sidebar : "(set with: kernel sidebar_info <text>)"},
        {NULL,NULL}
    };
    for (int i=0;rows[i].k;i++) {
        if (!rows[i].v || !rows[i].v[0]) continue;
        C_ACC(); con_write("  "); int l=(int)kstrlen(rows[i].k);
        con_write(rows[i].k); for(int j=l;j<12;j++) con_putchar(' ');
        C_NRM(); con_write(": "); con_writeln(rows[i].v);
    }
    C_ACC(); con_write("  RAM        : "); C_NRM();
    char mb[16]; kuitoa(g_mem_upper/1024,mb,10); con_write(mb); con_writeln(" MB");
    C_ACC(); con_write("  Heap free  : "); C_NRM();
    kuitoa(heap_free_bytes(),mb,10); con_write(mb); con_writeln(" B");
    /* Color swatch */
    C_ACC(); con_write("  Colors     : "); C_NRM();
    for (int c=0;c<16;c++){ terminal_set_color((uint8_t)c,(uint8_t)c); con_write(" "); }
    C_NRM(); con_writeln("");
    C_DIM(); con_writeln(pers->os_motd); C_NRM();
    con_writeln("");
}

/* ====== Script runner ==================================================================================================================================== */
void dispatch(char *line);  /* forward decl (already used above) */

static void run_script(const char *path_arg) {
    char p[128]; build_abs(path_arg, p);
    int fd = vfs_open(p, O_RDONLY);
    if (fd < 0) { C_ERR(); cprintf("sh: %s: not found\n", path_arg); C_NRM(); return; }
    static uint8_t sb[8192]; int n = vfs_read(fd, sb, sizeof(sb)-1); vfs_close(fd);
    if (n <= 0) return; sb[n] = 0;
    char *cur = (char*)sb;
    while (*cur) {
        char *eol = cur;
        while (*eol && *eol != '\n') eol++;
        char save = *eol; *eol = 0;
        char *trimmed = cur;
        while (*trimmed == ' ' || *trimmed == '\t') trimmed++;
        if (*trimmed && *trimmed != '#') {
            C_DIM(); cprintf("  + %s\n", trimmed); C_NRM();
            dispatch(trimmed);
        }
        *eol = save;
        cur = (*eol == '\n') ? eol+1 : eol;
    }
}

/* ====== hwinfo ========================================================================================================================================================= */
static void do_hwinfo(void) {
    sdk_cpuid_t cpu; sdk_cpuid(&cpu);
    C_HDR(); con_writeln("Hardware Information"); C_NRM();
    con_writeln("===============================================================================================================");
    cprintf("  CPU Vendor : %s\n", cpu.vendor);
    cprintf("  CPU Brand  : %s\n", cpu.brand[0]?cpu.brand:"(unavailable)");
    cprintf("  Stepping   : %u  Model: %u  Family: %u\n",cpu.stepping,cpu.model,cpu.family);
    cprintf("  FPU: %s  MMX: %s  SSE: %s  SSE2: %s  APIC: %s\n",
        cpu.has_fpu?"yes":"no", cpu.has_mmx?"yes":"no",
        cpu.has_sse?"yes":"no", cpu.has_sse2?"yes":"no",
        cpu.has_apic?"yes":"no");
    cprintf("  RAM        : %u MB (%u KB)\n", g_mem_upper/1024, g_mem_upper);
    cprintf("  Heap Base  : 0x%x  Size: %uKB\n", 0x400000u, HEAP_SIZE/1024);
    cprintf("  Free Heap  : %u B\n", heap_free_bytes());
    cprintf("  CR0        : 0x%x\n", cpu_cr0());
    con_writeln("===============================================================================================================");
    cprintf("  Disks      : %d ATA drive(s)\n", disk_count);
    for (int i=0;i<DISK_MAX_DRIVES;i++){
        if (!disk_drives[i].present) continue;
        cprintf("    hd%c: %u sectors (%u MB)  %s\n",
            'a'+i, disk_drives[i].sectors, disk_drives[i].sectors/2048,
            disk_drives[i].model);
    }
    cprintf("  Network    : %s\n", net.initialized?"RTL8139 detected":"none");
    cprintf("  Display    : %s\n", use_vbe?"VBE LFB 800x600x32bpp":"VGA text 80x25");
}

/* ====== /proc virtual files ================================================================================================================== */
static void proc_write(const char *name) {
    char p[64]; kstrcpy(p, "/proc/"); kstrcat(p, name);
    int fd = vfs_open(p, O_WRONLY|O_CREAT|O_TRUNC);
    if (fd < 0) return;
    char buf[512];
    if (kstrcmp(name,"version")==0) {
        ksnprintf(buf,sizeof(buf),
            "CaramelUK version 10.0.0 (carameluk@localhost) "
            "(gcc version 13.0 (CaramelUK GCC)) #1 SMP PREEMPT\n");
    } else if (kstrcmp(name,"uptime")==0) {
        uint32_t s=sched_uptime_ticks()/100;
        ksnprintf(buf,sizeof(buf),"%u.00 0.00\n",s);
    } else if (kstrcmp(name,"cpuinfo")==0) {
        sdk_cpuid_t cpu; sdk_cpuid(&cpu);
        ksnprintf(buf,sizeof(buf),
            "processor\t: 0\nvendor_id\t: %s\n"
            "model name\t: %s\n"
            "cpu family\t: %u\nmodel\t\t: %u\nstepping\t: %u\n"
            "fpu\t\t: %s\ncpuid level\t: 1\n",
            cpu.vendor, cpu.brand[0]?cpu.brand:"Unknown",
            cpu.family, cpu.model, cpu.stepping,
            cpu.has_fpu?"yes":"no");
    } else if (kstrcmp(name,"meminfo")==0) {
        uint32_t total=(g_mem_upper)*1024, free2=heap_free_bytes();
        ksnprintf(buf,sizeof(buf),
            "MemTotal:     %u kB\nMemFree:      %u kB\n"
            "MemAvailable: %u kB\nHeapUsed:     %u kB\n",
            total/1024, free2/1024, free2/1024, heap_used_bytes()/1024);
    } else if (kstrcmp(name,"cmdline")==0) {
        kstrcpy(buf,"carameluk root=/dev/ram0 rw console=tty0\n");
    } else {
        buf[0]=0;
    }
    vfs_write(fd,(uint8_t*)buf,(uint32_t)kstrlen(buf)); vfs_close(fd);
}

static void init_proc_files(void) {
    vfs_mkdir("/proc");
    const char *pfiles[] = {"version","uptime","cpuinfo","meminfo","cmdline","mounts",NULL};
    for (int i=0; pfiles[i]; i++) proc_write(pfiles[i]);
}

/* ==============================================================================================================================================================================
 *  COMMAND DISABLED CHECK
 * ============================================================================================================================================================================== */
static int cmd_is_disabled(const char *cmd) {
    const char *dis = sysconf_get("kernel","disable_cmd");
    if (!dis || !dis[0]) return 0;
    /* dis is comma-separated list */
    char tmp[256]; kstrcpy(tmp, dis);
    char *p = tmp;
    while (*p) {
        char *comma = p;
        while (*comma && *comma != ',') comma++;
        char save = *comma; *comma = 0;
        if (kstrcmp(p, cmd) == 0) return 1;
        *comma = save;
        p = (*comma == ',') ? comma+1 : comma;
    }
    return 0;
}

/* ==============================================================================================================================================================================
 *  Main dispatcher
 * ============================================================================================================================================================================== */
void dispatch(char *line) {
    while (*line == ' ') line++;
    if (!*line) return;

    /* Output redirection */
    char redir_path[128] = {0};
    int  redir_append    = 0;
    char *redir = kstrstr(line, " >> ");
    if (redir) { *redir=0; redir_append=1; build_abs(redir+4, redir_path); }
    else { redir = kstrstr(line, " > ");
           if (redir) { *redir=0; build_abs(redir+3, redir_path); } }

    /* History */
    if (hist_count < HIST_SIZE) kstrcpy(history[hist_count++], line);
    else {
        kmemmove(history[0], history[1], sizeof(char)*(HIST_SIZE-1)*CMD_MAX);
        kstrcpy(history[HIST_SIZE-1], line);
    }

    if (redir_path[0]) {
        redirect_fd = vfs_open(redir_path,
            O_WRONLY|O_CREAT|(redir_append?O_APPEND:O_TRUNC));
    }

    char *argv[64]; int argc = parse_args(line, argv, 64);
    if (argc == 0) { if(redirect_fd>=0){vfs_close(redirect_fd);redirect_fd=-1;} return; }
    const char *cmd = argv[0];

    /* ====== Check if command is disabled ====== */
    if (cmd_is_disabled(cmd)) {
        C_ERR(); cprintf("%s: command disabled by kernel config\n", cmd); C_NRM();
        goto done;
    }

    /* sudo */
    if (!kstrcmp(cmd,"sudo")) {
        if (argc<2){C_ERR();con_writeln("sudo: missing command");C_NRM();goto done;}
        if (!do_sudo_auth()) goto done;
        int old=sudo_mode; sudo_mode=1;
        char sub[CMD_MAX]; kstrcpy(sub, line+5);
        dispatch(sub); sudo_mode=old;
        goto done;
    }
    /* su */
    if (!kstrcmp(cmd,"su")) {
        C_WRN(); con_write("PIN: "); C_NRM();
        char pin2[32]; int pp=0;
        while(1){int k=keyboard_getkey();if(k=='\n'||k=='\r'){pin2[pp]=0;con_putchar('\n');break;}
            if((k=='\b'||k==127)&&pp>0){pp--;terminal_putchar('\b');con_erase();terminal_putchar('\b');}
            else if(k>=' '&&k<='~'&&pp<31){pin2[pp++]=(char)k;con_putchar('*');}}
        if(!kstrcmp(pin2,sudo_pin)){sudo_mode=1;kstrcpy(username,"root");C_OK();con_writeln("Switched to root.");C_NRM();}
        else{C_ERR();con_writeln("Authentication failure.");C_NRM();}
        goto done;
    }

    /* ====== v7: [command] alias/remap section in system.conf ====== */
    {
        const char *alias_val = sysconf_get("command", cmd);
        if (alias_val && alias_val[0]) {
            /* Build new command line: alias_val + rest of args */
            char aliased[CMD_MAX];
            kstrcpy(aliased, alias_val);
            for (int ai = 1; ai < argc; ai++) {
                kstrcat(aliased, " ");
                kstrcat(aliased, argv[ai]);
            }
            dispatch(aliased);
            goto done;
        }
    }

    /* ====== Check SDK custom commands ====== */
    {
        sdk_cmd_t *sc = sdk_cmd_find(cmd);
        if (sc) { sc->fn(argc, argv); goto done; }
    }

    /* ====== Built-in commands ====== */
    if (!kstrcmp(cmd,"ls")||!kstrcmp(cmd,"dir"))
        do_ls(argc,argv);
    else if (!kstrcmp(cmd,"ll")){ char *na[]={"ls","-l",argv[1],NULL};do_ls(3,na); }
    else if (!kstrcmp(cmd,"la")){ char *na[]={"ls","-a",argv[1],NULL};do_ls(3,na); }
    else if (!kstrcmp(cmd,"cat"))  { if(argc<2){C_ERR();con_writeln("cat: missing arg");C_NRM();}else for(int i=1;i<argc;i++) do_cat(argv[i]); }
    else if (!kstrcmp(cmd,"view")||!kstrcmp(cmd,"less")) { if(argc<2){C_ERR();con_writeln("view: missing arg");C_NRM();}else do_view(argv[1]); }
    else if (!kstrcmp(cmd,"stat")) { if(argc<2){C_ERR();con_writeln("stat: missing arg");C_NRM();}else do_stat(argv[1]); }
    else if (!kstrcmp(cmd,"file")) {
        if(argc<2) goto done;
        char p[128]; build_abs(argv[1],p);
        int fd2=vfs_open(p,O_RDONLY); if(fd2<0){C_ERR();cprintf("file: %s not found\n",argv[1]);C_NRM();goto done;}
        uint8_t mb2[16]; vfs_read(fd2,mb2,16); vfs_close(fd2);
        file_fmt_t f=fmt_detect(mb2,16,argv[1]);
        cprintf("%s: %s (%s)\n",p,fmt_name(f),fmt_mime(f));
    }
    else if (!kstrcmp(cmd,"hd")||!kstrcmp(cmd,"hexdump")) {
        if(argc<2){C_ERR();con_writeln("hd: missing file");C_NRM();goto done;}
        char p[128]; build_abs(argv[1],p);
        int fd2=vfs_open(p,O_RDONLY); if(fd2<0){C_ERR();cprintf("hd: %s not found\n",argv[1]);C_NRM();goto done;}
        static uint8_t hb[4096]; int n=vfs_read(fd2,hb,sizeof(hb)); vfs_close(fd2);
        int limit=(argc>=3)?kstrtoi(argv[2]):n;
        sdk_hexdump(hb,(size_t)(limit<n?limit:n),0);
    }
    else if (!kstrcmp(cmd,"wc")) {
        for(int i=1;i<argc;i++){
            char p[128]; build_abs(argv[i],p);
            int fd2=vfs_open(p,O_RDONLY); if(fd2<0){C_ERR();cprintf("wc: %s not found\n",argv[i]);C_NRM();continue;}
            static uint8_t wb[8192]; int n=vfs_read(fd2,wb,sizeof(wb)-1); vfs_close(fd2);
            if(n>0){wb[n]=0;wc_result_t r=fmt_wc((char*)wb,(uint32_t)n);cprintf("%d %d %d %s\n",r.lines,r.words,r.chars,argv[i]);}
        }
    }
    else if (!kstrcmp(cmd,"grep")) {
        int recursive=0; const char *pat=NULL; int fstart=argc;
        for(int i=1;i<argc;i++){
            if(!kstrcmp(argv[i],"-r")||!kstrcmp(argv[i],"-R")){recursive=1;continue;}
            if(!pat){pat=argv[i];continue;}
            if(fstart==argc) fstart=i;
        }
        if(!pat||fstart>=argc){C_ERR();con_writeln("grep: usage: grep [-r] <pattern> <file...>");C_NRM();goto done;}
        for(int fi=fstart;fi<argc;fi++){
            char p[128]; build_abs(argv[fi],p);
            int fd2=vfs_open(p,O_RDONLY); if(fd2<0) continue;
            static uint8_t gb[4096]; int n=vfs_read(fd2,gb,sizeof(gb)-1); vfs_close(fd2);
            if(n<=0) continue; gb[n]=0;
            char *pp=(char*)gb; int lineno=1;
            while(*pp){
                char *eol=pp; while(*eol&&*eol!='\n') eol++;
                char sv=*eol; *eol=0;
                if(kstrstr(pp,pat)){C_ACC();cprintf("%s:%d:",p,lineno);C_NRM();con_writeln(pp);}
                *eol=sv; pp=(*eol=='\n')?eol+1:eol; lineno++;
            }
        }
        (void)recursive;
    }
    else if (!kstrcmp(cmd,"sort")) {
        if(argc<2){C_ERR();con_writeln("sort: missing file");C_NRM();goto done;}
        char p[128]; build_abs(argv[1],p);
        int fd2=vfs_open(p,O_RDONLY); if(fd2<0) goto done;
        static char sb2[4096]; int n=vfs_read(fd2,(uint8_t*)sb2,sizeof(sb2)-1); vfs_close(fd2);
        if(n<=0) goto done; sb2[n]=0;
        static char *lines2[256]; int lc=0;
        lines2[lc++]=sb2;
        for(int i=0;i<n&&lc<255;i++) if(sb2[i]=='\n'){sb2[i]=0;if(i+1<n)lines2[lc++]=sb2+i+1;}
        for(int i=0;i<lc-1;i++) for(int j=0;j<lc-i-1;j++)
            if(kstrcmp(lines2[j],lines2[j+1])>0){char*t=lines2[j];lines2[j]=lines2[j+1];lines2[j+1]=t;}
        for(int i=0;i<lc;i++) con_writeln(lines2[i]);
    }
    else if (!kstrcmp(cmd,"uniq")) {
        if(argc<2){C_ERR();con_writeln("uniq: missing file");C_NRM();goto done;}
        char p[128]; build_abs(argv[1],p);
        int fd2=vfs_open(p,O_RDONLY); if(fd2<0) goto done;
        static uint8_t ub2[4096]; int n=vfs_read(fd2,ub2,sizeof(ub2)-1); vfs_close(fd2);
        if(n<=0) goto done; ub2[n]=0;
        char *pp=(char*)ub2, last2[256]="";
        while(*pp){ char *e=pp; while(*e&&*e!='\n') e++; char sv=*e; *e=0;
            if(kstrcmp(pp,last2)!=0){con_writeln(pp);kstrcpy(last2,pp);} *e=sv; pp=(*e=='\n')?e+1:e; }
    }
    else if (!kstrcmp(cmd,"head")) {
        if(argc<2) goto done;
        int nlines=(argc>=3&&!kstrcmp(argv[1],"-n"))?kstrtoi(argv[2]):10;
        const char *file=(argc>=3&&!kstrcmp(argv[1],"-n"))?argv[3]:argv[1];
        char p[128]; build_abs(file,p);
        int fd2=vfs_open(p,O_RDONLY); if(fd2<0) goto done;
        static uint8_t hb2[4096]; int n=vfs_read(fd2,hb2,sizeof(hb2)-1); vfs_close(fd2);
        if(n<=0) goto done; hb2[n]=0;
        char *pp=(char*)hb2; int row=0;
        while(*pp&&row<nlines){char *e=pp;while(*e&&*e!='\n')e++;char sv=*e;*e=0;con_writeln(pp);*e=sv;pp=(*e=='\n')?e+1:e;row++;}
    }
    else if (!kstrcmp(cmd,"tail")) {
        if(argc<2) goto done;
        int nlines=(argc>=3&&!kstrcmp(argv[1],"-n"))?kstrtoi(argv[2]):10;
        const char *file=(argc>=3&&!kstrcmp(argv[1],"-n"))?argv[3]:argv[1];
        char p[128]; build_abs(file,p);
        int fd2=vfs_open(p,O_RDONLY); if(fd2<0) goto done;
        static uint8_t tb2[4096]; int n=vfs_read(fd2,tb2,sizeof(tb2)-1); vfs_close(fd2);
        if(n<=0) goto done; tb2[n]=0;
        char *lns[512]; int lc=0; lns[lc++]=(char*)tb2;
        for(int i=0;i<n&&lc<511;i++) if(tb2[i]=='\n'){tb2[i]=0;if(i+1<n)lns[lc++]=(char*)tb2+i+1;}
        int start=lc>nlines?lc-nlines:0;
        for(int i=start;i<lc;i++) con_writeln(lns[i]);
    }
    else if (!kstrcmp(cmd,"cut")) {
        char delim='\t'; int field=1;
        const char *file=NULL;
        for(int i=1;i<argc;i++){
            if(argv[i][0]=='-'&&argv[i][1]=='d') delim=argv[i][2]?argv[i][2]:'\t';
            else if(argv[i][0]=='-'&&argv[i][1]=='f') field=kstrtoi(argv[i]+2);
            else file=argv[i];
        }
        if(!file){C_ERR();con_writeln("cut: missing file");C_NRM();goto done;}
        char p[128]; build_abs(file,p);
        int fd2=vfs_open(p,O_RDONLY); if(fd2<0) goto done;
        static uint8_t cb2[4096]; int n=vfs_read(fd2,cb2,sizeof(cb2)-1); vfs_close(fd2);
        if(n<=0) goto done; cb2[n]=0;
        char *pp=(char*)cb2;
        while(*pp){
            char *eol=pp; while(*eol&&*eol!='\n') eol++;
            char sv=*eol; *eol=0;
            char *fp=pp; int f=1;
            while(f<field&&*fp){while(*fp&&*fp!=delim)fp++;if(*fp==delim){fp++;f++;}}
            char *fe=fp; while(*fe&&*fe!=delim) fe++;
            char sfp=*fe; *fe=0; con_writeln(fp); *fe=sfp;
            *eol=sv; pp=(*eol=='\n')?eol+1:eol;
        }
    }
    else if (!kstrcmp(cmd,"tr")) {
        if(argc<4){C_ERR();con_writeln("tr: usage: tr <from> <to> <file>");C_NRM();goto done;}
        char p[128]; build_abs(argv[3],p);
        int fd2=vfs_open(p,O_RDONLY); if(fd2<0) goto done;
        static uint8_t tb3[4096]; int n=vfs_read(fd2,tb3,sizeof(tb3)-1); vfs_close(fd2);
        if(n<=0) goto done;
        size_t fl=kstrlen(argv[1]),tl=kstrlen(argv[2]);
        for(int i=0;i<n;i++){
            char c=(char)tb3[i];
            for(size_t j=0;j<fl;j++) if(c==argv[1][j]){c=(j<tl)?argv[2][j]:0;break;}
            if(c) con_putchar(c);
        }
    }
    else if (!kstrcmp(cmd,"tee")) {
        if(argc<2){C_ERR();con_writeln("tee: missing file");C_NRM();goto done;}
        char p[128]; build_abs(argv[1],p);
        C_WRN(); con_writeln("tee: type line then Enter:"); C_NRM();
        char tb4[CMD_MAX]; readline_v6(tb4,CMD_MAX);
        int fd2=vfs_open(p,O_WRONLY|O_CREAT|O_TRUNC);
        if(fd2>=0){vfs_write(fd2,(uint8_t*)tb4,(uint32_t)kstrlen(tb4));vfs_write(fd2,(uint8_t*)"\n",1);vfs_close(fd2);}
        con_writeln(tb4);
    }
    else if (!kstrcmp(cmd,"find")) {
        if(argc<2) goto done;
        const char *needle=argv[1]; const char *where=(argc>=3)?argv[2]:"/";
        const char *dirs[]={"/","/home","/syls","/syls/bin","/uiu","/uiu/etc","/etc","/data","/tmp",NULL};
        for(int i=0;dirs[i];i++){
            char ns[64][VFS_NAME_MAX]; int c2=0; vfs_listdir(dirs[i],ns,&c2);
            for(int j=0;j<c2;j++){
                char nm[VFS_NAME_MAX]; kstrcpy(nm,ns[j]);
                size_t nl=kstrlen(nm); if(nl&&nm[nl-1]=='/') nm[nl-1]=0;
                if(kstrcmp(nm,needle)==0){
                    con_write(dirs[i]);
                    if(dirs[i][kstrlen(dirs[i])-1]!='/') con_putchar('/');
                    con_writeln(ns[j]);
                }
            }
        }
        (void)where;
    }
    else if (!kstrcmp(cmd,"tree")) {
        char p[128]; if(argc<2) kstrcpy(p,cwd); else build_abs(argv[1],p);
        con_writeln(p);
        char ns[64][VFS_NAME_MAX]; int c2=0; vfs_listdir(p,ns,&c2);
        for(int i=0;i<c2;i++){
            size_t nl=kstrlen(ns[i]); int is_dir=nl&&ns[i][nl-1]=='/';
            C_DIM(); con_write(i==c2-1?"========= ":"========= ");
            if(is_dir) C_ACC(); else C_NRM(); con_writeln(ns[i]);
        }
        C_NRM();
    }
    /* Directory / file ops */
    else if (!kstrcmp(cmd,"cd")) {
        if(argc<2) kstrcpy(cwd,"/home");
        else { char p[128]; build_abs(argv[1],p);
            vfs_stat_t st;
            if(vfs_stat(p,&st)<0||!(st.type&VFS_DIR)){C_ERR();cprintf("cd: %s: not a directory\n",argv[1]);C_NRM();}
            else kstrcpy(cwd,p); }
    }
    else if (!kstrcmp(cmd,"pwd"))   con_writeln(cwd);
    else if (!kstrcmp(cmd,"mkdir")) {
        if(argc<2) goto done;
        char p[128]; build_abs(argv[1],p);
        if(vfs_mkdir(p)<0){C_ERR();cprintf("mkdir: %s: failed\n",argv[1]);C_NRM();}
        else cprintf("mkdir: created '%s'\n",p);
    }
    else if (!kstrcmp(cmd,"rmdir")||(!kstrcmp(cmd,"rm")&&argc>=2&&!kstrcmp(argv[1],"-d"))) {
        const char *a=(!kstrcmp(cmd,"rmdir"))?argv[1]:argv[2];
        if(!a) goto done;
        char p[128]; build_abs(a,p);
        if(vfs_unlink(p)<0){C_ERR();cprintf("rmdir: %s: failed\n",a);C_NRM();}
    }
    else if (!kstrcmp(cmd,"touch")) {
        for(int i=1;i<argc;i++){char p[128];build_abs(argv[i],p);vfs_create(p);}
    }
    else if (!kstrcmp(cmd,"rm")) {
        if(argc<2) goto done;
        int force=0;
        for(int i=1;i<argc;i++){
            if(argv[i][0]=='-'){
                for(int j=1;argv[i][j];j++) if(argv[i][j]=='f') force=1;
                continue;
            }
            if(force&&!sudo_mode){C_ERR();con_writeln("rm -f: requires sudo");C_NRM();goto done;}
            char p[128]; build_abs(argv[i],p);
            if(vfs_unlink(p)<0){C_ERR();cprintf("rm: %s: not found\n",argv[i]);C_NRM();}
            else cprintf("removed '%s'\n",p);
        }
    }
    else if (!kstrcmp(cmd,"cp")) {
        if(argc<3) goto done;
        char sp[128],dp[128]; build_abs(argv[1],sp); build_abs(argv[2],dp);
        int fs=vfs_open(sp,O_RDONLY);
        if(fs<0){C_ERR();cprintf("cp: %s: not found\n",argv[1]);C_NRM();goto done;}
        int fd2=vfs_open(dp,O_WRONLY|O_CREAT|O_TRUNC); if(fd2<0){vfs_close(fs);goto done;}
        uint8_t t[512]; int n;
        while((n=vfs_read(fs,t,512))>0) vfs_write(fd2,t,(uint32_t)n);
        vfs_close(fs); vfs_close(fd2); cprintf("'%s' -> '%s'\n",sp,dp);
    }
    else if (!kstrcmp(cmd,"mv")) {
        if(argc<3) goto done;
        char sp[128],dp[128]; build_abs(argv[1],sp); build_abs(argv[2],dp);
        int fs=vfs_open(sp,O_RDONLY); int fd2=vfs_open(dp,O_WRONLY|O_CREAT|O_TRUNC);
        if(fs<0||fd2<0){if(fs>=0)vfs_close(fs);if(fd2>=0)vfs_close(fd2);goto done;}
        uint8_t t[512]; int n;
        while((n=vfs_read(fs,t,512))>0) vfs_write(fd2,t,(uint32_t)n);
        vfs_close(fs); vfs_close(fd2); vfs_unlink(sp);
    }
    else if (!kstrcmp(cmd,"write")) {
        if(argc<3) goto done;
        char p[128]; build_abs(argv[1],p);
        int fd2=vfs_open(p,O_WRONLY|O_CREAT|O_TRUNC); if(fd2<0) goto done;
        for(int i=2;i<argc;i++){vfs_write(fd2,(uint8_t*)argv[i],(uint32_t)kstrlen(argv[i]));if(i<argc-1)vfs_write(fd2,(uint8_t*)" ",1);}
        vfs_write(fd2,(uint8_t*)"\n",1); vfs_close(fd2);
    }
    else if (!kstrcmp(cmd,"append")) {
        if(argc<3) goto done;
        char p[128]; build_abs(argv[1],p);
        int fd2=vfs_open(p,O_WRONLY|O_CREAT|O_APPEND); if(fd2<0) goto done;
        for(int i=2;i<argc;i++){vfs_write(fd2,(uint8_t*)argv[i],(uint32_t)kstrlen(argv[i]));if(i<argc-1)vfs_write(fd2,(uint8_t*)" ",1);}
        vfs_write(fd2,(uint8_t*)"\n",1); vfs_close(fd2);
    }
    else if (!kstrcmp(cmd,"ln"))    { cprintf("ln: symlink %s -> %s (in-memory only)\n",argc>2?argv[2]:"?",argc>1?argv[1]:"?"); }
    else if (!kstrcmp(cmd,"chmod")) {
        if(!sudo_mode){C_ERR();con_writeln("chmod: requires sudo");C_NRM();goto done;}
        if(argc<3) goto done;
        cprintf("chmod: %s -> mode %s (in-memory)\n",argv[2],argv[1]);
    }
    else if (!kstrcmp(cmd,"chown")) {
        if(!sudo_mode){C_ERR();con_writeln("chown: requires sudo");C_NRM();goto done;}
        if(argc<3) goto done;
        cprintf("chown: %s owner -> %s (in-memory)\n",argv[2],argv[1]);
    }
    /* Process / system */
    else if (!kstrcmp(cmd,"ps"))     sched_print_tasks();
    else if (!kstrcmp(cmd,"kill"))   { if(argc<2){C_ERR();con_writeln("kill: missing pid");C_NRM();}else cprintf("kill: SIGTERM -> pid %s (stub)\n",argv[1]); }
    else if (!kstrcmp(cmd,"sleep")) {
        if(argc<2) goto done;
        uint32_t ms=(uint32_t)(kstrtoi(argv[1])*1000);
        sdk_sleep_ms(ms);
    }
    else if (!kstrcmp(cmd,"wait"))   { C_DIM();con_writeln("Waiting... (press any key)");C_NRM(); keyboard_getkey(); }
    else if (!kstrcmp(cmd,"sh"))     { if(argc<2){C_ERR();con_writeln("sh: missing script");C_NRM();}else run_script(argv[1]); }
    else if (!kstrcmp(cmd,"source")||!kstrcmp(cmd,".")) {
        if(argc<2){C_ERR();con_writeln("source: missing file");C_NRM();}else run_script(argv[1]);
    }
    /* System info */
    else if (!kstrcmp(cmd,"uname")) {
        if(argc>1&&!kstrcmp(argv[1],"-a"))
            con_writeln("CaramelUK 10.0.0 carameluk-kernel 10.0.0 #1 SMP x86 GNU/CaramelUK");
        else if(argc>1&&!kstrcmp(argv[1],"-r"))
            con_writeln("10.0.0-carameluk");
        else con_writeln("CaramelUK");
    }
    else if (!kstrcmp(cmd,"uptime")) {
        uint32_t s=sched_uptime_ticks()/100;
        cprintf("up %uh %um %us  load: 0.00 0.00 0.00  users: 1\n",s/3600,(s/60)%60,s%60);
    }
    else if (!kstrcmp(cmd,"mem")||!kstrcmp(cmd,"free")) {
        uint32_t tot=heap_free_bytes()+heap_used_bytes();
        cprintf("%-16s%8s%8s%8s\nMem:     %8u%8u%8u\nSwap:    %8u%8u%8u\n",
            "","total","used","free",tot,heap_used_bytes(),heap_free_bytes(),0u,0u,0u);
    }
    else if (!kstrcmp(cmd,"dmesg")) {
        C_HDR(); con_writeln("[dmesg] caramelY OS v10.0 boot log:"); C_NRM();
        con_writeln("[    0.000] CaramelUK 10.0.0 \"Green Tea\" kernel starting");
        con_writeln("[    0.001] GDT: 5 descriptors installed");
        con_writeln("[    0.001] IDT: 256 entries + PIC 8259 remapped IRQ0-15 -> INT32-47");
        con_writeln("[    0.002] PIT: 100Hz, pit_sleep() available");
        con_writeln("[    0.003] Heap: 4MB @ 0x400000, first-fit allocator");
        con_writeln("[    0.003] Keyboard: PS/2 with E0 extended keys, Ctrl/Alt/Caps");
        cprintf("[    0.004] Display: %s\n",use_vbe?"VBE LFB 800x600x32bpp":"VGA 80x25 + 500-line scrollback");
        con_writeln("[    0.005] VFS: ramfs initialized, 16 fd table");
        con_writeln("[    0.005] OS SDK: hooks/cmds/drivers/themes/env/serial/cpuid ready");
        con_writeln("[    0.006] Scheduler: preemptive round-robin, priorities 1-10");
        con_writeln("[    0.007] Readline v7: Alt+C hotkey, backspace fix, redraw-based");
        cprintf("[    0.008] Disk: %d ATA PIO drive(s) detected\n",disk_count);
        cprintf("[    0.009] Network: %s\n",net.initialized?"RTL8139 detected":"not found");
        con_writeln("[    0.010] CaramelDE v2: caramel/windows/mac desktop styles");
        con_writeln("[    0.011] /proc: virtual files initialized");
        con_writeln("[    0.012] Games: snake, tetris loaded");
        con_writeln("[    0.013] Easter eggs: alya, crash, matrix loaded");
        con_writeln("[    0.014] caramelsh v10.0 ready");
    }
    else if (!kstrcmp(cmd,"date")) {
        uint32_t s=sched_uptime_ticks()/100;
        cprintf("caramelY OS  uptime %u seconds\n(RTC not implemented === install NTP module)\n",s);
    }
    else if (!kstrcmp(cmd,"hostname")) {
        if(argc>1){kstrcpy(hostname,argv[1]);sysconf_set("system","hostname",hostname);}
        else con_writeln(hostname);
    }
    else if (!kstrcmp(cmd,"whoami"))  con_writeln(username);
    else if (!kstrcmp(cmd,"id"))      cprintf("uid=%s(%s) gid=0(root) groups=0(root),27(sudo)\n",sudo_mode?"0":"1000",username);
    else if (!kstrcmp(cmd,"info"))    do_info();
    else if (!kstrcmp(cmd,"hwinfo"))  do_hwinfo();
    else if (!kstrcmp(cmd,"lscpu"))   { sdk_cpuid_t cpu; sdk_cpuid(&cpu); cprintf("Vendor: %s\nModel: %s\nFamily: %u Model: %u Stepping: %u\nFPU: %s SSE: %s SSE2: %s\n",cpu.vendor,cpu.brand[0]?cpu.brand:"unknown",cpu.family,cpu.model,cpu.stepping,cpu.has_fpu?"yes":"no",cpu.has_sse?"yes":"no",cpu.has_sse2?"yes":"no"); }
    else if (!kstrcmp(cmd,"env"))     sdk_env_list();
    else if (!kstrcmp(cmd,"set")&&argc>=3)  sdk_env_set(argv[1],argv[2]);
    else if (!kstrcmp(cmd,"unset"))   { if(argc>=2) sdk_env_unset(argv[1]); }
    else if (!kstrcmp(cmd,"export"))  { if(argc>=2){ char *eq=kstrchr(argv[1],'='); if(eq){*eq=0;sdk_env_set(argv[1],eq+1);}else sdk_env_set(argv[1],"");} }
    else if (!kstrcmp(cmd,"printenv")){ if(argc>=2){const char*v=sdk_env_get(argv[1]);if(v)con_writeln(v);}else sdk_env_list(); }
    /* Disk / FS */
    else if (!kstrcmp(cmd,"lsblk"))  {
        con_writeln("NAME  TYPE  SIZE   MODEL");
        for(int i=0;i<DISK_MAX_DRIVES;i++){
            if(!disk_drives[i].present) continue;
            cprintf("hd%c   disk  %4uM  %s\n",'a'+i,disk_drives[i].sectors/2048,disk_drives[i].model);
        }
        if(!disk_count){C_WRN();con_writeln("No block devices found");C_NRM();}
    }
    else if (!kstrcmp(cmd,"df")) {
        con_writeln("Filesystem  1K-blocks   Used  Avail  Use%  Mounted");
        con_writeln("ramfs             n/a    n/a    n/a     -  /");
        if(cfs.mounted){
            uint32_t t=cfs.sb.total_blocks*512/1024, f=cfs.sb.free_blocks*512/1024;
            cprintf("caramelfs    %8u %6u %6u  %3u%%  /data\n",t,t-f,f,t?(t-f)*100/t:0);
        }
    }
    else if (!kstrcmp(cmd,"du")) {
        if(argc<2) goto done;
        char p[128]; build_abs(argv[1],p); vfs_stat_t st;
        if(vfs_stat(p,&st)==0) cprintf("%u\t%s\n",(st.size+1023)/1024,p);
    }
    else if (!kstrcmp(cmd,"mount")) {
        int drv=0;
        if(argc>=2&&argv[1][0]=='h'&&argv[1][1]=='d') drv=argv[1][2]-'a';
        if(!disk_drives[drv].present){C_ERR();cprintf("mount: hd%c: not found\n",'a'+drv);C_NRM();goto done;}
        if(cfs_mount(drv)<0){C_WRN();con_writeln("Not formatted === run 'mkfs'");C_NRM();goto done;}
        live_mode=0; C_OK(); cprintf("Mounted hd%c on /data\n",'a'+drv); C_NRM();
    }
    else if (!kstrcmp(cmd,"umount")) { live_mode=1; cfs_sync(); cfs.mounted=0; C_OK(); con_writeln("Unmounted."); C_NRM(); }
    else if (!kstrcmp(cmd,"mkfs")) {
        int drv=0; if(argc>=2) drv=argv[argc-1][2]-'a';
        if(!disk_drives[drv].present){C_ERR();con_writeln("mkfs: no drive");C_NRM();goto done;}
        C_WRN(); cprintf("Format hd%c? [y/N] ",'a'+drv); C_NRM();
        char a[4]; readline_v6(a,4);
        if(a[0]!='y'&&a[0]!='Y'){con_writeln("Cancelled.");goto done;}
        if(cfs_format(drv,"caramelfs")<0){C_ERR();con_writeln("mkfs: failed");C_NRM();}
        else{C_OK();cprintf("Formatted hd%c as CaramelFS\n",'a'+drv);C_NRM();}
    }
    else if (!kstrcmp(cmd,"sync"))   { if(cfs.mounted){cfs_sync();C_OK();con_writeln("Synced.");C_NRM();}else{C_WRN();con_writeln("No disk mounted.");C_NRM();} }
    /* Network */
    else if (!kstrcmp(cmd,"ifconfig")) {
        if(argc==1){con_writeln("lo:    1210.0.0.1  LOOPBACK  UP");net_print_info();}
        else if(argc>=3){
            uint8_t ip[4]={0}; int o2=0; uint32_t v=0;
            for(char *pp=(char*)argv[2];*pp&&o2<4;pp++){
                if(*pp>='0'&&*pp<='9') v=v*10+(uint32_t)(*pp-'0');
                else if(*pp=='.'){ip[o2++]=(uint8_t)v;v=0;}
            } ip[o2]=(uint8_t)v;
            net_set_ip(ip[0],ip[1],ip[2],ip[3]); con_writeln("IP updated.");
        }
    }
    else if (!kstrcmp(cmd,"netstat")) net_print_stats();

    else if (!kstrcmp(cmd,"ai")) {
        /* ====== ================== AI ====== */
        if (argc < 2) {
            if (g_ai.loaded) {
                ai_chat_loop();
            } else {
                C_WRN(); con_writeln("ai: ============ ==== ==================");
                con_writeln("  ==========================:");
                con_writeln("    ai load /ai/model.crml  === ==================");
                con_writeln("    ai chat                 === ============");
                con_writeln("    ai ask <============>         === ============");
                con_writeln("    ai info                 === ========");
                con_writeln("    ai create /ai/name.crml === ==============");
                con_writeln("    ai unload               === ==================");
                con_writeln("  ==============: .crml .dict");
                con_writeln("  ====================== ======== ============ == /ai/ == ==================.");
                C_NRM();
            }
        } else if (!kstrcmp(argv[1],"load")) {
            if (argc < 3) { C_ERR(); con_writeln("ai load: ========== ========"); C_NRM(); }
            else {
                char aip[128]; build_abs(argv[2], aip);
                int n2 = ai_load(aip);
                if (n2 >= 0) {
                    C_OK(); cprintf("============ ==================: %d ======\n", n2); C_NRM();
                }
            }
        } else if (!kstrcmp(argv[1],"chat")) {
            ai_chat_loop();
        } else if (!kstrcmp(argv[1],"ask")) {
            if (argc < 3) { C_ERR(); con_writeln("ai ask: ========== ============"); C_NRM(); }
            else {
                /* ============== ====== ================== == ======== ============ */
                static char question[512]; question[0]=0;
                for (int i=2;i<argc;i++){kstrcat(question,argv[i]);if(i<argc-1)kstrcat(question," ");}
                static char answer[AI_MAX_STR];
                ai_ask(question, answer, AI_MAX_STR);
                C_OK(); con_write("AI: "); C_NRM(); con_writeln(answer);
            }
        } else if (!kstrcmp(argv[1],"info")) {
            ai_info();
        } else if (!kstrcmp(argv[1],"unload")) {
            ai_unload();
            C_OK(); con_writeln("============ ==================."); C_NRM();
        } else if (!kstrcmp(argv[1],"create")) {
            if (argc < 3) { C_ERR(); con_writeln("ai create: ========== ========"); C_NRM(); }
            else {
                char aip[128]; build_abs(argv[2], aip);
                /* ============== ========== /ai/ ======== ====== */
                vfs_mkdir("/ai");
                ai_create_interactive(aip);
            }
        } else {
            C_ERR(); cprintf("ai: ====================== ============== '%s'\n", argv[1]); C_NRM();
        }
    }
    else if (!kstrcmp(cmd,"ping")) {
        if(argc<2){ C_ERR(); con_writeln("ping: ========== ========"); C_NRM(); goto done; }
        int count = 4;
        for(int i=1;i<argc;i++) if(!kstrcmp(argv[i],"-c")&&i+1<argc){count=kstrtoi(argv[i+1]);break;}
        cprintf("PING %s: 64 bytes ============\n", argv[1]);
        for(int i=1;i<=count;i++){
            uint32_t t0=pit_get_ticks();
            pit_sleep(10);  /* ================== ================ */
            uint32_t dt=(pit_get_ticks()-t0)*10;
            cprintf("64 bytes ==== %s: icmp_seq=%d ttl=64 time=%u ms\n",argv[1],i,dt);
        }
        cprintf("--- %s ping ==================== ---\n",argv[1]);
        cprintf("%d ============== ====================, %d ================, 0%% ============\n",count,count);
    }
    else if (!kstrcmp(cmd,"arp"))    { if(argc<2) goto done; cprintf("ARP: broadcasting for %s...\n",argv[1]); }
    else if (!kstrcmp(cmd,"route"))  con_writeln("Destination  Gateway   Iface\n0.0.0.0      10.0.2.2  eth0\n1210.0.0.0    *         lo");
    /* Themes */
    else if (!kstrcmp(cmd,"theme")) {
        if(argc<2){ cprintf("Theme: %s  (%d/%d)\n",SCH->name,(int)terminal_get_scheme()+1,sdk_theme_count()); goto done; }
        int id=kstrtoi(argv[1]);
        if(id>=0&&id<sdk_theme_count()){
            terminal_set_scheme((scheme_id_t)id);
            if(!use_vbe){con_clear();terminal_print_logo();}
            /* BUG FIX v7: save theme id correctly as string, not int */
            char tstr[4]; kitoa(id,tstr,10);
            sysconf_set("console","theme",tstr);
        } else {C_ERR();cprintf("theme: 0-%d\n",sdk_theme_count()-1);C_NRM();}
    }
    else if (!kstrcmp(cmd,"themes")) {
        const char *names[]={"0-caramel","1-matrix","2-ocean","3-nord","4-retro","5-dracula","6-solarized","7-gruvbox"};
        for(int i=0;i<8;i++){C_ACC();con_write("  ");C_NRM();con_writeln(names[i]);}
        if(sdk_theme_count()>SCHEME_COUNT){
            con_writeln("  Runtime themes:"); for(int i=SCHEME_COUNT;i<sdk_theme_count();i++){
                const color_scheme_t *rt=sdk_theme_get(i);
                cprintf("  %d-%s\n",i,rt?rt->name:"(unnamed)");
            }
        }
    }
    /* Config === extended in v10 */
    else if (!kstrcmp(cmd,"sysconf")) {
        if(argc<2){con_writeln("sysconf: get|set|save|show [section] [key] [val]");goto done;}
        if(!kstrcmp(argv[1],"get")&&argc>=4){const char*v=sysconf_get(argv[2],argv[3]);v?con_writeln(v):(void)(C_WRN(),con_writeln("(unset)"),C_NRM());}
        else if(!kstrcmp(argv[1],"set")&&argc>=5){sysconf_set(argv[2],argv[3],argv[4]);C_OK();con_writeln("OK");C_NRM();}
        else if(!kstrcmp(argv[1],"save")){sysconf_save();C_OK();con_writeln("Saved.");C_NRM();}
        else if(!kstrcmp(argv[1],"show")){
            for(int si=0;si<g_syscfg.count;si++){
                C_HDR();cprintf("[%s]\n",g_syscfg.sections[si].name);C_NRM();
                for(int ki=0;ki<g_syscfg.sections[si].count;ki++){
                    C_ACC();con_write("  ");con_write(g_syscfg.sections[si].entries[ki].key);
                    C_NRM();con_write(" = ");con_writeln(g_syscfg.sections[si].entries[ki].val);
                }
            }
        }
    }
    /* v7: config create wizard */
    else if (!kstrcmp(cmd,"config")) {
        if (argc>=2 && !kstrcmp(argv[1],"create")) {
            cmd_config_create();
        } else {
            con_writeln("config: subcommands: create");
            con_writeln("  config create   === interactive configuration wizard");
            con_writeln("  Tip: press Alt+C at any time to open this wizard");
        }
    }
    /* Packages */
    else if (!kstrcmp(cmd,"pkg")) {
        if(argc<2){con_writeln("pkg: install|info|list|remove|create");goto done;}
        if(!kstrcmp(argv[1],"list")){
            int any=0;
            for(int si=0;si<g_pkgcfg.count;si++){
                const char *inst=cfg_get(&g_pkgcfg,g_pkgcfg.sections[si].name,"installed");
                if(inst&&!kstrcmp(inst,"yes")){
                    const char *ver=cfg_get(&g_pkgcfg,g_pkgcfg.sections[si].name,"version");
                    const char *desc=cfg_get(&g_pkgcfg,g_pkgcfg.sections[si].name,"description");
                    C_ACC();cprintf("  %-20s",g_pkgcfg.sections[si].name);
                    C_NRM();cprintf("%-10s  %s\n",ver?ver:"?",desc?desc:"");any=1;
                }
            }
            if(!any){C_WRN();con_writeln("(====== ========================== ==============)");C_NRM();}
            goto done;
        }
        /* pkg remove <name> */
        if(!kstrcmp(argv[1],"remove")) {
            if(argc<3){C_ERR();con_writeln("pkg remove: ========== ====== ============");C_NRM();goto done;}
            cede_remove(argv[2]);
            goto done;
        }
        /* pkg create <name> <elf_path> === ============== .cede ==== ELF */
        if(!kstrcmp(argv[1],"create")) {
            if(argc<4){C_ERR();con_writeln("pkg create: usage: pkg create <name> <elf_path>");C_NRM();goto done;}
            char ep[128]; build_abs(argv[3],ep);
            int fd2=vfs_open(ep,O_RDONLY);
            if(fd2<0){C_ERR();cprintf("pkg create: %s ==== ============\n",argv[3]);C_NRM();goto done;}
            static uint8_t elf_buf[32768];
            int en=vfs_read(fd2,elf_buf,sizeof(elf_buf)); vfs_close(fd2);
            if(en<=0){C_ERR();con_writeln("pkg create: ============ ========");C_NRM();goto done;}
            static uint8_t cede_out[65536];
            int cn=cede_wrap_elf(elf_buf,(uint32_t)en,argv[2],"1.0.0",cede_out,sizeof(cede_out));
            if(cn<=0){C_ERR();con_writeln("pkg create: ============ ================");C_NRM();goto done;}
            char outpath[128]; kstrcpy(outpath,argv[2]); kstrcat(outpath,".cede");
            int ofd=vfs_open(outpath,O_WRONLY|O_CREAT|O_TRUNC);
            if(ofd<0){C_ERR();cprintf("pkg create: ==== ============== ============== %s\n",outpath);C_NRM();goto done;}
            vfs_write(ofd,cede_out,(uint32_t)cn); vfs_close(ofd);
            C_OK(); cprintf("============: %s (%d ========)\n",outpath,cn); C_NRM();
            goto done;
        }
        /* pkg install / info */
        if(argc<3) goto done;
        char p[128]; build_abs(argv[2],p);
        int fd2=vfs_open(p,O_RDONLY); if(fd2<0){C_ERR();cprintf("pkg: %s ==== ============\n",argv[2]);C_NRM();goto done;}
        static uint8_t pb[32768]; int n=vfs_read(fd2,pb,sizeof(pb)); vfs_close(fd2);
        if(n<=0) goto done;
        cede_pkg_t pkg2;
        if(cede_parse(&pkg2,pb,(uint32_t)n)<0){C_ERR();con_writeln("pkg: ================ .cede ========");C_NRM();goto done;}
        if(!kstrcmp(argv[1],"info")) cede_info(&pkg2);
        else if(!kstrcmp(argv[1],"install")) cede_install(&pkg2);
    }
    else if (!kstrcmp(cmd,"readelf")) {
        if(argc<2) goto done;
        char p[128]; build_abs(argv[1],p);
        int fd2=vfs_open(p,O_RDONLY); if(fd2<0) goto done;
        static uint8_t eb[8192]; int n=vfs_read(fd2,eb,sizeof(eb)); vfs_close(fd2);
        if(n>0) elf_info(eb,(uint32_t)n);
    }
    else if (!kstrcmp(cmd,"exec")) {
        if(argc<2) goto done;
        char p[128]; build_abs(argv[1],p);
        int fd2=vfs_open(p,O_RDONLY); if(fd2<0){C_ERR();cprintf("exec: %s not found\n",argv[1]);C_NRM();goto done;}
        static uint8_t xb[16384]; int n=vfs_read(fd2,xb,sizeof(xb)); vfs_close(fd2);
        if(n>0&&elf_validate(xb,(uint32_t)n)){
            elf_load_result_t r=elf_load(xb,(uint32_t)n);
            if(r.valid)((void(*)(void))(uintptr_t)r.entry)();
            else{C_ERR();cprintf("exec: %s\n",r.error);C_NRM();}
        }
    }
    /* SDK commands */
    else if (!kstrcmp(cmd,"sdk")) {
        if(argc<2){con_writeln("sdk: cmds|hooks|drivers|modules|themes|env|info");goto done;}
        if(!kstrcmp(argv[1],"cmds"))    sdk_cmd_list();
        else if(!kstrcmp(argv[1],"modules")) sdk_module_list();
        else if(!kstrcmp(argv[1],"themes")){
            cprintf("Total themes: %d (%d built-in + %d runtime)\n",
                sdk_theme_count(),SCHEME_COUNT,sdk_theme_count()-SCHEME_COUNT);
        }
        else if(!kstrcmp(argv[1],"info")){
            cprintf("caramelY OS SDK v%d.%d.%d\n",
                CARAMELUK_VERSION_MAJOR,CARAMELUK_VERSION_MINOR,CARAMELUK_VERSION_PATCH);
            con_writeln("Available: sdk_cmd_register, sdk_hook_register, sdk_theme_register,");
            con_writeln("           sdk_driver_register, sdk_irq_install, sdk_env_set,");
            con_writeln("           sdk_hexdump, sdk_cpuid, sdk_serial_write, sdk_sleep_ms");
        }
        else if(!kstrcmp(argv[1],"load")){
            if(argc<3){C_ERR();con_writeln("sdk load: missing path");C_NRM();}
            else sdk_module_load(argv[2]);
        }
    }
    else if (!kstrcmp(cmd,"serial")) {
        sdk_serial_init();
        if(argc<2){C_WRN();con_writeln("serial: type message:");C_NRM();char sb3[128];readline_v6(sb3,128);sdk_serial_write(sb3);sdk_serial_write("\n");}
        else{for(int i=1;i<argc;i++){sdk_serial_write(argv[i]);sdk_serial_write(" ");}sdk_serial_write("\n");}
        C_OK(); con_writeln("Sent via COM1."); C_NRM();
    }
    else if (!kstrcmp(cmd,"modinfo")) {
        if(argc<2) goto done;
        cprintf("Module: %s (use 'sdk load <path>')\n",argv[1]);
    }
    else if (!kstrcmp(cmd,"malloc")) {
        if(argc<2) goto done;
        uint32_t sz=(uint32_t)kstrtoi(argv[1]);
        void *ptr=kmalloc((size_t)sz);
        if(!ptr){C_ERR();con_writeln("malloc: FAILED");C_NRM();goto done;}
        uint8_t *b=(uint8_t*)ptr;
        for(uint32_t i=0;i<sz;i++) b[i]=(uint8_t)(i&0xFF);
        int ok=1; for(uint32_t i=0;i<sz;i++) if(b[i]!=(uint8_t)(i&0xFF)){ok=0;break;}
        C_OK(); cprintf("OK  ptr=0x%x  size=%u  verify=%s\n",(uint32_t)(uintptr_t)ptr,sz,ok?"PASS":"FAIL"); C_NRM();
        kfree(ptr);
    }
    else if (!kstrcmp(cmd,"which")) {
        if(argc<2) goto done;
        if(sdk_cmd_find(argv[1])){con_write(argv[1]);con_writeln(" (sdk registered command)");goto done;}
        const char *spaths[]={"/syls/bin","/bin","/uiu/bin",NULL};
        for(int i=0;spaths[i];i++){
            char p[128]; kstrcpy(p,spaths[i]); kstrcat(p,"/"); kstrcat(p,argv[1]);
            vfs_stat_t st; if(vfs_stat(p,&st)==0){con_writeln(p);goto done;}
        }
        con_write(argv[1]); con_writeln(" (built-in)");
    }
    else if (!kstrcmp(cmd,"man")) {
        if(argc<2){C_ERR();con_writeln("man: missing command");C_NRM();goto done;}
        char mp[128]; kstrcpy(mp,"/uiu/etc/man/"); kstrcat(mp,argv[1]);
        vfs_stat_t st;
        if(vfs_stat(mp,&st)==0) do_cat(mp);
        else cprintf("No manual entry for '%s'  (write to /uiu/etc/man/%s)\n",argv[1],argv[1]);
    }
    else if (!kstrcmp(cmd,"history")||!kstrcmp(cmd,"hist")) {
        for(int i=0;i<hist_count;i++){C_DIM();cprintf("%3d  ",i+1);C_NRM();con_writeln(history[i]);}
    }
    else if (!kstrcmp(cmd,"clear"))  con_clear();
    else if (!kstrcmp(cmd,"reset"))  { con_clear(); terminal_print_logo(); }
    else if (!kstrcmp(cmd,"logo"))   { if(use_vbe)vbe_draw_logo();else terminal_print_logo(); }
    else if (!kstrcmp(cmd,"echo"))   {
        int newline=1, start=1;
        if(argc>1&&!kstrcmp(argv[1],"-n")){newline=0;start=2;}
        for(int i=start;i<argc;i++){if(i>start)con_putchar(' ');con_write(argv[i]);}
        if(newline) con_putchar('\n');
    }
    else if (!kstrcmp(cmd,"printf")) {
        if(argc>=2) con_write(argv[1]);
        if(argc>=3) con_write(argv[2]);
        con_putchar('\n');
    }
    else if (!kstrcmp(cmd,"de")) {
        if(!use_vbe){C_ERR();con_writeln("de: requires VBE mode (make run-vbe)");C_NRM();goto done;}
        /* Apply desktop style before launching */
        const char *dstyle = sysconf_get("desktop","style");
        if (dstyle && dstyle[0]) {
            C_DIM(); cprintf("  Desktop style: %s\n", dstyle); C_NRM();
        }
        C_OK();con_writeln("Launching CaramelDE v2... (Alt+F1 to return)");C_NRM();
        pit_sleep(300); de_run();
        con_clear(); terminal_print_logo();
    }
    else if (!kstrcmp(cmd,"install")) {
        C_HDR(); con_writeln("=== caramelY OS v10 Installer ==="); C_NRM();
        if(!disk_count){C_ERR();con_writeln("No disk. Add -hda disk.img to QEMU.");C_NRM();goto done;}
        C_WRN(); con_write("Install to hda? [y/N] "); C_NRM();
        char a[4]; readline_v6(a,4);
        if(a[0]!='y'&&a[0]!='Y'){con_writeln("Cancelled.");goto done;}
        con_writeln("Formatting...");
        if(cfs_format(0,"carameluk-root")<0){C_ERR();con_writeln("Failed.");C_NRM();goto done;}
        cfs_path_mkdir("/home"); cfs_path_mkdir("/syls"); cfs_path_mkdir("/syls/bin");
        cfs_path_mkdir("/uiu");  cfs_path_mkdir("/uiu/etc");
        cfs_path_mkdir("/data"); cfs_path_mkdir("/tmp");
        live_mode=0; C_OK(); con_writeln("Installation complete! Disk mounted at /data."); C_NRM();
    }
    else if (!kstrcmp(cmd,"live")) { live_mode=1; cfs_sync(); cfs.mounted=0; C_OK(); con_writeln("Live mode active."); C_NRM(); }
    else if (!kstrcmp(cmd,"modules")) {
        if(!g_mbi||!(g_mbi->flags&(1<<3))||!g_mbi->mods_count){con_writeln("No GRUB modules.");goto done;}
        mb_module_t *m=(mb_module_t*)(uintptr_t)g_mbi->mods_addr;
        for(uint32_t i=0;i<g_mbi->mods_count;i++){
            cprintf("[%u] 0x%x..0x%x  %s\n",i,m[i].mod_start,m[i].mod_end,
                m[i].cmdline?(const char*)(uintptr_t)m[i].cmdline:"(none)");
        }
    }
    else if (!kstrcmp(cmd,"aiy")) {
        C_HDR(); con_writeln("[aiy] CaramelUK Assistant v7"); C_NRM();
        if(argc<2){con_writeln("aiy: status|help|diskinfo|netinfo|sched|hwinfo");goto done;}
        if(!kstrcmp(argv[1],"status")){C_OK();con_writeln("[OK] All systems nominal");C_NRM();}
        else if(!kstrcmp(argv[1],"help")) dispatch((char*)"help");
        else if(!kstrcmp(argv[1],"diskinfo")){dispatch((char*)"lsblk");dispatch((char*)"df");}
        else if(!kstrcmp(argv[1],"netinfo")){dispatch((char*)"ifconfig");dispatch((char*)"netstat");}
        else if(!kstrcmp(argv[1],"sched")) sched_print_tasks();
        else if(!kstrcmp(argv[1],"hwinfo")) do_hwinfo();
    }
    /* ====== v10 NEW COMMANDS ====== */
    else if (!kstrcmp(cmd,"snake"))  game_snake();
    else if (!kstrcmp(cmd,"tetris")) game_tetris();
    else if (!kstrcmp(cmd,"matrix")) easter_matrix();
    else if (!kstrcmp(cmd,"alya")) { easter_alya(); }
    else if (!kstrcmp(cmd,"android"))  { easter_android(); }
    else if (!kstrcmp(cmd,"v10"))      { easter_v10_jubilee(); }
    else if (!kstrcmp(cmd,"lollipop")) { easter_v10_jubilee(); }
    else if (!kstrcmp(cmd,"pong"))     { game_pong(); }
    //DUPL   easter_alya();
    else if (!kstrcmp(cmd,"crash"))  easter_crash();
    else if (!kstrcmp(cmd,"helloworld")) easter_helloworld();
    else if (!kstrcmp(cmd,"browser")||!kstrcmp(cmd,"surf")||!kstrcmp(cmd,"www")||!kstrcmp(cmd,"firefox")) {
        /* ======== ============== URL === ============== ======, ========== ============== */
        if (argc >= 2) {
            browser_open_url(argv[1]);
        }
        browser_run();
    }
    /* ====== v10.0 NEW ====== */
    else if (!kstrcmp(cmd,"osbuilder")||!kstrcmp(cmd,"mkos")) {
        if (argc>=2&&!kstrcmp(argv[1],"show")) osbuilder_show();
        else if (argc>=2&&!kstrcmp(argv[1],"apply")) osbuilder_apply();
        else osbuilder_run();
    }
    else if (!kstrcmp(cmd,"fat32")) {
        if (!fat32.mounted) {
            if (disk_count==0){C_ERR();con_writeln("fat32: ====== ==========");C_NRM();goto done;}
            if (fat32_mount(0)<0){C_ERR();con_writeln("fat32: ==== FAT32 ====== ============");C_NRM();goto done;}
        }
        if (argc<2||!kstrcmp(argv[1],"ls")) {
            static fat32_dirent_t ents[64]; int n2=fat32_readdir(fat32.bpb.root_cluster,ents,64);
            C_HDR();cprintf("FAT32 / (%d entries):\n",n2);C_NRM();
            for(int i=0;i<n2;i++){
                char nm[13]; int ni=0;
                for(int j=0;j<8&&ents[i].name[j]!=' ';j++) nm[ni++]=ents[i].name[j];
                if(ents[i].ext[0]!=' '){nm[ni++]='.';for(int j=0;j<3&&ents[i].ext[j]!=' ';j++)nm[ni++]=ents[i].ext[j];}
                nm[ni]=0;
                if(ents[i].attr&0x10){C_ACC();}else{C_NRM();}
                cprintf("  %-14s  %u bytes\n",nm,ents[i].size);
            }
            C_NRM();
        } else if (!kstrcmp(argv[1],"cat")&&argc>=3) {
            static fat32_dirent_t fe;
            if(fat32_find(argv[2],&fe)<0){C_ERR();cprintf("fat32: %s ==== ============\n",argv[2]);C_NRM();goto done;}
            uint32_t cl=((uint32_t)fe.cluster_hi<<16)|fe.cluster_lo;
            static uint8_t fb[4096]; int fn=fat32_readfile(cl,fe.size,fb,sizeof(fb)-1);
            if(fn>0){fb[fn]=0;con_write((char*)fb);}
        }
    }
    else if (!kstrcmp(cmd,"pong"))    game_pong();
    else if (!kstrcmp(cmd,"breakout")) game_breakout();
    else if (!kstrcmp(cmd,"doom"))    easter_doom();
    else if (!kstrcmp(cmd,"glitch"))  easter_glitch();
    else if (!kstrcmp(cmd,"rickroll")) easter_rickroll();
    else if (!kstrcmp(cmd,"wine")||!kstrcmp(cmd,"wincompat")) {
        if (argc < 2) {
            C_HDR(); con_writeln("WineCompat === ======== ========================== == Windows .exe"); C_NRM();
            con_writeln("  ==========================:");
            con_writeln("    wine <program.exe> [args...]");
            con_writeln("    wincompat info <program.exe>");
            con_writeln("  ============================ API:");
            con_writeln("    kernel32: GetStdHandle WriteConsole ExitProcess Sleep GetTickCount HeapAlloc");
            con_writeln("    msvcrt:   printf puts malloc free strlen strcmp strcpy memcpy memset exit");
            con_writeln("    user32:   MessageBoxA");
            con_writeln("  ======================: ============ PE32 x86, ==================== ====================, ====== GDI/DirectX");
            con_writeln("  ==============: browser === caramel://wincompat");
            goto done;
        }
        if (!kstrcmp(argv[1],"info") && argc >= 3) {
            char ep[128]; build_abs(argv[2],ep);
            int fd2=vfs_open(ep,O_RDONLY);
            if(fd2<0){C_ERR();cprintf("wincompat: %s ==== ============\n",argv[2]);C_NRM();goto done;}
            static uint8_t pb2[65536]; int n2=vfs_read(fd2,pb2,sizeof(pb2)); vfs_close(fd2);
            if(n2>0) wincompat_info(pb2,(uint32_t)n2);
            goto done;
        }
        /* wine program.exe [args] */
        char ep2[128]; build_abs(argv[1],ep2);
        /* ================== ==================== */
        int elen=(int)kstrlen(ep2);
        int has_exe=(elen>4 && !kstrcmp(ep2+elen-4,".exe"));
        if(!has_exe) { kstrcat(ep2,".exe"); }
        wincompat_run(ep2, argc-1, argv+1);
    }
    else if (!kstrcmp(cmd,"desktop")) cmd_desktop(argc, argv);
    else if (!kstrcmp(cmd,"kernel")) cmd_kernel_cfg(argc, argv);

    else if (!kstrcmp(cmd,"store")||!kstrcmp(cmd,"shop")) {
        store_run();
    }
    else if (!kstrcmp(cmd,"games")||!kstrcmp(cmd,"gamelauncher")||!kstrcmp(cmd,"gl")) {
        gamelauncher_run();
    }
    else if (!kstrcmp(cmd,"maze")) {
        game_maze();
    }
    else if (!kstrcmp(cmd,"cpuinfo")) {
        sdk_cpuid_t cpu; sdk_cpuid(&cpu);
        C_HDR(); con_writeln("=== CPU Detection ==="); C_NRM();
        cprintf("  Vendor:  %s\n", cpu.vendor);
        cprintf("  Brand:   %s\n", cpu.brand[0]?cpu.brand:"(unavailable)");
        cprintf("  Family:  %u  Model: %u  Stepping: %u\n", cpu.family, cpu.model, cpu.stepping);
        cprintf("  FPU: %s  MMX: %s  SSE: %s  SSE2: %s  APIC: %s\n",
            cpu.has_fpu?"yes":"no", cpu.has_mmx?"yes":"no",
            cpu.has_sse?"yes":"no", cpu.has_sse2?"yes":"no",
            cpu.has_apic?"yes":"no");
        cprintf("  RAM: %u MB\n", g_mem_upper/1024);
    }
    else if (!kstrcmp(cmd,"help")) {
        C_HDR(); con_writeln("caramelY OS v10.0 \"Green Tea\" === Command Reference"); C_NRM();
        con_writeln("  Run 'info' for system details, 'man <cmd>' for command help\n");
        const char *grps[][2] = {
            {"Files",   "ls ll la cat view less head tail file hd hexdump wc grep sort uniq cut tr tee"},
            {"Edit",    "write append touch rm cp mv mkdir rmdir tree find stat chmod chown ln"},
            {"Script",  "sh source . echo printf sleep wait"},
            {"Disk",    "lsblk df du mount umount mkfs sync install live"},
            {"System",  "uname info hwinfo lscpu uptime mem free ps kill dmesg date which man modules"},
            {"Network", "ifconfig netstat ping arp route"},
            {"Config",  "sysconf theme themes hostname whoami id env set unset export printenv"},
            {"Users",   "sudo su whoami id"},
            {"Packages","pkg install|info|list|remove|create  readelf exec"},
            {"SDK",     "sdk serial modinfo malloc"},
            {"Browser", "browser <url>  surf  www  (caramel:// ==========)"},
            {"DE",      "de  desktop style caramel|windows|mac"},
            {"Kernel",  "kernel show|save|<key> <val>"},
            {"Games",   "snake  tetris  pong  breakout  maze"},
            {"Easter",  "alya  crash  matrix  helloworld"},
            {"Config",  "config create  (====== Alt+C == ========== ============)"},
            {"History", "history  =========================  Tab=====================  Ctrl+AEKUW"},
            {NULL,NULL}
        };
        for(int i=0;grps[i][0];i++){
            C_HDR(); cprintf("  %-10s",grps[i][0]); C_NRM(); con_writeln(grps[i][1]);
        }
        if(sdk_cmd_find(NULL)!=NULL) sdk_cmd_list();
        con_writeln("\n  Scroll: PgUp/PgDn  |  Alt+C: config wizard  |  Tab-complete\n");
    }
    else if (!kstrcmp(cmd,"reboot")) {
        con_writeln("Rebooting..."); cfs_sync();
        outb(0x64,(uint8_t)0xFE); while(1) cpu_hlt();
    }
    else if (!kstrcmp(cmd,"halt")||!kstrcmp(cmd,"poweroff")) {
        con_writeln("Halting..."); cfs_sync(); cpu_cli(); cpu_hlt();
        while(1) cpu_hlt();
    }

    else if (!kstrcmp(cmd,"kmod")) {
        if (argc<2) { kmod_list(); goto done; }
        if (!kstrcmp(argv[1],"load")) {
            if(argc<3){C_ERR();con_writeln("kmod load: path?");C_NRM();}
            else { char kp[128]; build_abs(argv[2],kp); kmod_load(kp); }
        } else if (!kstrcmp(argv[1],"unload")&&argc>=3) {
            kmod_unload(argv[2]);
        } else if (!kstrcmp(argv[1],"info")&&argc>=3) {
            kmod_info(argv[2]);
        } else { kmod_list(); }
    }
    else if (!kstrcmp(cmd,"abbr")) {
        if (argc<2||!kstrcmp(argv[1],"--list")||!kstrcmp(argv[1],"-l")) {
            fish_abbr_list();
        } else if (!kstrcmp(argv[1],"--add")&&argc>=4) {
            fish_abbr_add(argv[2],argv[3]);
            C_OK();cprintf("abbr: '%s' -> '%s'\n",argv[2],argv[3]);C_NRM();
        } else { con_writeln("abbr: --list | --add <abbr> <exp>"); }
    }
    else if (!kstrcmp(cmd,"edn")) {
        C_HDR();con_writeln("EDN warnings === Extended Debug Notices:");C_NRM();
        C_DIM();con_writeln("  (view with 'dmesg' === EDN entries shown inline)");C_NRM();
    }
    else if (!kstrcmp(cmd,"panic")&&sudo_mode) {
        PANIC("Manual test panic (sudo panic)");
    }
    else {
        C_ERR(); cprintf("%s: command not found (type 'help')\n", cmd); C_NRM();
    }

done:
    if (redirect_fd >= 0) { vfs_close(redirect_fd); redirect_fd = -1; }
}

/* =================================================================================================================================================================================
 *  Kernel entry point
 * ================================================================================================================================================================================= */
/* ====== ============-====== == ============ (uptime ====== HH:MM:SS) ======================================= */
static void update_statusbar(void) {
    if (use_vbe) return;
    uint32_t secs = sched_uptime_ticks() / 100;
    uint32_t h = secs / 3600;
    uint32_t m = (secs % 3600) / 60;
    uint32_t s2 = secs % 60;
    char clk[16]; char tmp[8]; clk[0]=0;
    if(h<10)kstrcat(clk,"0"); kuitoa(h,tmp,10); kstrcat(clk,tmp); kstrcat(clk,":");
    if(m<10)kstrcat(clk,"0"); kuitoa(m,tmp,10); kstrcat(clk,tmp); kstrcat(clk,":");
    if(s2<10)kstrcat(clk,"0"); kuitoa(s2,tmp,10); kstrcat(clk,tmp);
    char right_buf[64];
    kstrcpy(right_buf, keyboard_ru() ? "[RU] " : "[EN] ");
    kstrcat(right_buf, clk);
    kstrcat(right_buf, "  help | fish | kmod");
    terminal_draw_statusbar(
        "caramelY OS v1.0 \"Green Tea\"",
        right_buf);
}


/* ====== ================ Android 4.3 "Jelly Bean" + 4.4 "KitKat" =============== */
static void easter_android(void) {
    con_clear();
    /* Android 4.3 Jelly Bean === ================== ====== */
    terminal_set_color(VGA_LIGHT_GREEN, VGA_BLACK);
    con_writeln("");
    con_writeln("     Android 4.3  \"Jelly Bean\"   &   4.4  \"KitKat\"");
    con_writeln("");
    terminal_set_color(VGA_LIGHT_CYAN, VGA_BLACK);
    /* ASCII ============== */
    con_writeln("              .---.  .---.          ");
    con_writeln("             /     V     V         ");
    con_writeln("             | () | | () |    o o   ");
    con_writeln("              (____)(____)          ");
    con_writeln("          .-------------------.      ");
    con_writeln("         |  ANDROID  4.3/4.4  |     ");
    con_writeln("         |  [=====|=======]   |     ");
    con_writeln("         |  [=====|=======]   |     ");
    con_writeln("          -------------------/      ");
    con_writeln("           |   |         |   |       ");
    con_writeln("           |   |         |   |       ");
    con_writeln("           ^   ^         ^   ^       ");
    con_writeln("");
    terminal_set_color(VGA_YELLOW, VGA_BLACK);
    con_writeln("   ============================================================================================================");
    con_writeln("   ===  Android 4.3 - Jelly Bean (2013) ===");
    con_writeln("   ===  * Bluetooth Smart ==================      ===");
    con_writeln("   ===  * OpenGL ES 3.0                  ===");
    con_writeln("   ===  * ==================== ======================         ===");
    con_writeln("   ============================================================================================================");
    con_writeln("   ===  Android 4.4 - KitKat (2013)      ===");
    terminal_set_color(VGA_LIGHT_RED, VGA_BLACK);
    con_writeln("   ===  ================================================================================================ ===");
    con_writeln("   ===  ===     KIT KAT  4.4              === ===");
    con_writeln("   ===  ================================================================================================ ===");
    terminal_set_color(VGA_YELLOW, VGA_BLACK);
    con_writeln("   ===  * Project Svelte (============ RAM)    ===");
    con_writeln("   ===  * ART runtime (============ Dalvik)    ===");
    con_writeln("   ===  * Full-screen immersive mode     ===");
    con_writeln("   ============================================================================================================");
    con_writeln("");
    terminal_set_color(VGA_LIGHT_GREEN, VGA_BLACK);
    con_writeln("   caramelY OS v10 \"Green Tea\" ======== ============== Android!");
    con_writeln("   ============ 4.x ======================== ====================== Android.");
    terminal_set_color(VGA_DARK_GREY, VGA_BLACK);
    con_writeln("");
    con_writeln("   ============== ========== ==============...");
    C_NRM();
    keyboard_getkey();
    con_clear();
    terminal_print_logo();
}

/* ====== ================ ================== === caramelY OS v10 ========================================================= */
static void easter_v10_jubilee(void) {
    con_clear();
    terminal_set_color(VGA_YELLOW, VGA_BLACK);
    con_writeln("");
    con_writeln("  ========================================================================================================================================================================");
    con_writeln("  ===                                                      ===");
    con_writeln("  ===     ====  caramelY OS === ================== ============ v10  ====     ===");
    con_writeln("  ===                                                      ===");
    con_writeln("  ========================================================================================================================================================================");
    terminal_set_color(VGA_LIGHT_CYAN, VGA_BLACK);
    con_writeln("  ===  v1  === ============== ========, VGA, ls/cat/cd                 ===");
    con_writeln("  ===  v2  === IDT, PIT, kmalloc, 5 ======, int 0x80           ===");
    con_writeln("  ===  v3  === VBE 800x600, ======================, VFS, RTL8139       ===");
    con_writeln("  ===  v4  === ATA, CaramelFS, .cede ============, 50+ ============     ===");
    con_writeln("  ===  v5  === 500-line scrollback, DE, ============== ============      ===");
    con_writeln("  ===  v6  === OS SDK, 8 ======, ksnprintf, redraw-readline    ===");
    con_writeln("  ===  v7  === ======== (Snake/Tetris), ================, Alt+C         ===");
    con_writeln("  ===  v8  === ================== == VBE, FAT32, browser, store       ===");
    con_writeln("  ===  v9  === RU ==================, LocalAI, ping, KEY_UTF8        ===");
    terminal_set_color(VGA_YELLOW, VGA_BLACK);
    con_writeln("  ===  v10 === LOLLIPOP: ========, ========== ==========, Pong,           ===");
    con_writeln("  ===         Android ================, ============, helloworld===       ===");
    con_writeln("  ========================================================================================================================================================================");
    terminal_set_color(VGA_LIGHT_GREEN, VGA_BLACK);
    con_writeln("  ===                                                      ===");
    con_writeln("  ===   10 ============. ========== ========== ========. ======== ========.           ===");
    con_writeln("  ===   CaramelUK === ======== ==== ================== == ======== ==== x86!      ===");
    con_writeln("  ===                                                      ===");
    con_writeln("  ========================================================================================================================================================================");
    con_writeln("");
    terminal_set_color(VGA_LIGHT_MAGENTA, VGA_BLACK);
    con_writeln("   ========== caramelY OS v10:");
    for (int i = 0; i < 16; i++) {
        terminal_set_color((uint8_t)i, (uint8_t)i);
        terminal_write("  ");
    }
    C_NRM();
    con_writeln("");
    con_writeln("");
    C_DIM(); con_writeln("  ============== ========== ==============..."); C_NRM();
    keyboard_getkey();
    con_clear();
    terminal_print_logo();
}

/* ======================================================================================================================================================
 * PONG === ASCII ============ ====== caramelY OS v10
 * W/S === ========== ==============, Up/Down === ============
 * Q === ==========
 * ====================================================================================================================================================== */
#define PONG_W  78
#define PONG_H  22
#define PONG_WIN 7   /* ========== ====== ============ */


void kernel_main(uint32_t mb_magic, mb_info_t *mbi) {
    (void)mb_magic;
    g_mbi = mbi;

    gdt_install();
    idt_install();
    pit_install(100);
    /* ======== ======== ========== BSS === ======================== ====== ============ ========== linker symbols */
    heap_init(HEAP_ADDR, HEAP_SIZE);
    terminal_init();
    terminal_set_scheme(SCHEME_CARAMEL);

    /* ====== VBE: GRUB ====== ================== framebuffer ========== gfxpayload=keep ==================
     * ==== ================== multiboot info bit12 (framebuffer present).
     * ================== ========== bpp>=24 == ========== =======1 (RGB linear).
     * ================== serial-======== ====== ==============.
     * ========================================================================================================================================================================================================= */
    use_vbe = 0;
    if (mbi && (mbi->flags & (1u << 12))) {
        sdk_serial_init();
        /* ======== framebuffer info == serial ====== ============== */
        char dbg[64];
        sdk_serial_write("[vbe] type=");
        kuitoa(mbi->fb_type, dbg, 10); sdk_serial_write(dbg);
        sdk_serial_write(" bpp=");
        kuitoa(mbi->fb_bpp, dbg, 10); sdk_serial_write(dbg);
        sdk_serial_write(" w=");
        kuitoa(mbi->fb_width, dbg, 10); sdk_serial_write(dbg);
        sdk_serial_write(" h=");
        kuitoa(mbi->fb_height, dbg, 10); sdk_serial_write(dbg);
        sdk_serial_write(" addr=0x");
        kuitoa(mbi->fb_addr_lo, dbg, 16); sdk_serial_write(dbg);
        sdk_serial_write("\n");

        if (mbi->fb_type == 1
            && (mbi->fb_bpp == 32 || mbi->fb_bpp == 24)
            && mbi->fb_addr_lo > 0x1000
            && mbi->fb_addr_hi == 0
            && mbi->fb_width  >= 320
            && mbi->fb_height >= 200
            && mbi->fb_pitch  > 0)
        {
            mb_fb_info_t fb;
            fb.addr_lo    = mbi->fb_addr_lo;
            fb.addr_hi    = mbi->fb_addr_hi;
            fb.pitch      = mbi->fb_pitch;
            fb.width      = mbi->fb_width;
            fb.height     = mbi->fb_height;
            fb.bpp        = mbi->fb_bpp;
            fb.type       = mbi->fb_type;
            fb.red_pos    = mbi->fb_red_pos;
            fb.red_mask   = mbi->fb_red_mask;
            fb.green_pos  = mbi->fb_green_pos;
            fb.green_mask = mbi->fb_green_mask;
            fb.blue_pos   = mbi->fb_blue_pos;
            fb.blue_mask  = mbi->fb_blue_mask;
            if (vbe_init(&fb) == 0) {
                use_vbe = 1;
                vbe_console_init();
                vbe_draw_logo();
                sdk_serial_write("[vbe] OK\n");
            } else {
                sdk_serial_write("[vbe] vbe_init failed\n");
            }
        } else {
            sdk_serial_write("[vbe] conditions not met, using VGA\n");
        }
    }
    if (!use_vbe) terminal_print_logo();

    cpu_sti();
    keyboard_init();
    sdk_serial_init();

    vfs_init();
    vfs_mkdir("/syls"); vfs_mkdir("/syls/bin"); vfs_mkdir("/syls/lib");
    vfs_mkdir("/uiu");  vfs_mkdir("/uiu/etc"); vfs_mkdir("/uiu/etc/man");
    vfs_mkdir("/data"); vfs_mkdir("/tmp");
    init_proc_files();

    disk_init();
    if (disk_count > 0 && disk_drives[0].present && cfs_mount(0)==0) live_mode=0;

    config_init();
    /* Apply saved settings */
    const char *hn = sysconf_get("system","hostname");
    if (hn) kstrcpy(hostname, hn);
    /* BUG FIX v7: read theme as string properly */
    const char *th = sysconf_get("console","theme");
    if (th && th[0]>='0' && th[0]<='9') {
        int id=kstrtoi(th);
        if(id>=0&&id<SCHEME_COUNT) terminal_set_scheme((scheme_id_t)id);
    }
    const char *pin = sysconf_get("system","sudo_pin");
    if (pin && pin[0]) kstrcpy(sudo_pin, pin);
    /* Apply kernel name if set */
    const char *kname = sysconf_get("kernel","kernel_name");
    if (kname && kname[0]) {
        sdk_personality_t pers;
        const sdk_personality_t *cur = sdk_personality_get();
        kstrcpy(pers.os_name,    kname);
        kstrcpy(pers.os_version, "10.0.0");
        kstrcpy(pers.os_codename,"Green Tea");
        kstrcpy(pers.os_author,  cur->os_author);
        kstrcpy(pers.os_motd,    cur->os_motd);
        sdk_personality_set(&pers);
    }

    net_init();
    sched_init();
    panic_init();
    kmod_init();
    fish_init();

    if (mbi && (mbi->flags & 1)) g_mem_upper = mbi->mem_upper;

    sdk_env_set("PATH",    "/syls/bin:/bin");
    sdk_env_set("HOME",    "/home/root");
    sdk_env_set("SHELL",   "/syls/bin/caramelsh");
    sdk_env_set("TERM",    "caramelterm-256color");
    sdk_env_set("OS",      "CaramelUK");
    sdk_env_set("VERSION", "1.0.0");
    sdk_env_set("USER",    "root");

    sdk_hook_fire(HOOK_BOOT_LATE);

    /* Custom boot message */
    const char *bmsg = sysconf_get("kernel","boot_msg");

    if (!use_vbe)
        update_statusbar();

    C_HDR();
    if (bmsg && bmsg[0]) con_writeln(bmsg);
    else con_writeln("caramelY OS v10.0 \"Green Tea\" === ready.");
    C_NRM();
    cprintf("  Mode:    %s  |  Scroll: PgUp/PgDn (500 lines)\n", live_mode?"LIVE":"DISK");
    cprintf("  Readline: Ctrl+A/E=line ends  Ctrl+K/U=kill  Ctrl+W=del word  Tab=complete\n");
    cprintf("  NEW v1:  snake  tetris  matrix  alya  crash  |  Alt+C=config wizard\n");
    cprintf("  Desktop: 'desktop style windows/mac/caramel'  |  'kernel' to tune OS\n");
    con_writeln("  Type 'help' for all commands.\n");

    char line[CMD_MAX];
    while (1) {
        print_prompt();
        readline_v6(line, CMD_MAX);
        if (!line[0]) continue;
        dispatch(line);
        proc_write("uptime"); proc_write("meminfo");
        if (!use_vbe)
            update_statusbar();
    }
}
