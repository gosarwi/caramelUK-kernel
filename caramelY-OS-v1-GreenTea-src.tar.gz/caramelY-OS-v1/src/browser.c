/* browser.c — CaramelFox Browser v1.0
 * CaramelUK v7 "Cupcake"
 */
#include "browser.h"
#include "vbe.h"
#include "vga.h"
#include "vfs.h"
#include "keyboard.h"
#include "util.h"
#include "pit.h"
#include "sched.h"
#include <stdint.h>
#include <stddef.h>

/* use_vbe объявлен в kernel.c — extern */


/* Локальная замена memcpy (не используем libc) */
static void br_memset(void *dst, int c, int n) {
    uint8_t *d = (uint8_t*)dst;
    for (int i = 0; i < n; i++) d[i] = (uint8_t)c;
}
#define kmemset(d,c,n) br_memset(d,c,n)

static int readline_br(char *out, int maxlen);  /* forward */

/* ─── Глобальное состояние ──────────────────────────────── */
static br_state_t BR;

/* ─── Цвета браузера ────────────────────────────────────── */
#define BR_C_BG        RGB(0xFF,0xFF,0xFF)   /* белый фон страницы */
#define BR_C_TEXT      RGB(0x1A,0x1A,0x1A)   /* тёмный текст */
#define BR_C_LINK      RGB(0x00,0x66,0xCC)   /* синие ссылки */
#define BR_C_H1        RGB(0x00,0x00,0x00)   /* заголовок h1 */
#define BR_C_H2        RGB(0x22,0x22,0x44)
#define BR_C_H3        RGB(0x33,0x33,0x55)
#define BR_C_HR        RGB(0xCC,0xCC,0xCC)
#define BR_C_CODE_BG   RGB(0xF4,0xF4,0xF4)
#define BR_C_CHROME    RGB(0x38,0x39,0x3A)   /* панель браузера */
#define BR_C_TAB_ACT   RGB(0xFF,0xFF,0xFF)
#define BR_C_TAB_INA   RGB(0x52,0x53,0x54)
#define BR_C_URLBAR    RGB(0xFF,0xFF,0xFF)
#define BR_C_URLBRD    RGB(0xAA,0xAA,0xAA)
#define BR_C_BTN       RGB(0x5A,0x5A,0x5A)
#define BR_C_BTN_H     RGB(0x80,0x80,0x80)

/* Высоты хром-панелей */
#define BR_TAB_H    28
#define BR_NAV_H    36
#define BR_STATUS_H 20
#define BR_CHROME_H (BR_TAB_H + BR_NAV_H)
#define BR_CONTENT_Y BR_CHROME_H
#define BR_CONTENT_H(total_h) ((total_h) - BR_CHROME_H - BR_STATUS_H)

/* ─── Встроенные страницы (caramel://) ──────────────────── */
static const struct { const char *url; const char *html; } builtin_pages[] = {

{ "home",
"<html><head><title>CaramelFox — New Tab</title></head><body>"
"<h1>CaramelFox</h1>"
"<p><b>CaramelUK OS v7 \"Cupcake\"</b> — встроенный браузер</p>"
"<hr>"
"<h2>Быстрый доступ</h2>"
"<ul>"
"<li><a href=\"caramel://about\">О системе</a></li>"
"<li><a href=\"caramel://help\">Справка по командам</a></li>"
"<li><a href=\"caramel://games\">Игры</a></li>"
"<li><a href=\"caramel://sdk\">SDK документация</a></li>"
"<li><a href=\"caramel://cede\">Формат пакетов .cede</a></li>"
"<li><a href=\"caramel://wincompat\">Совместимость с .exe</a></li>"
"<li><a href=\"caramel://news\">Что нового в v7</a></li>"
"</ul>"
"<hr>"
"<p><i>Навигация: Tab=ссылки Enter=открыть F5=обновить Ctrl+T=новая вкладка Ctrl+W=закрыть Alt+F4=выход</i></p>"
"</body></html>"
},

{ "about",
"<html><head><title>О CaramelUK</title></head><body>"
"<h1>CaramelUK OS v7.0 \"Cupcake\"</h1>"
"<hr>"
"<h2>Системная информация</h2>"
"<ul>"
"<li><b>Архитектура:</b> x86 32-bit (i386)</li>"
"<li><b>Загрузчик:</b> GRUB Multiboot1</li>"
"<li><b>Ядро:</b> monolithic kernel, C (gcc -m32)</li>"
"<li><b>Файловая система:</b> ramfs + CaramelFS (CFS)</li>"
"<li><b>Дисплей:</b> VGA 80x25 / VBE 800x600x32bpp</li>"
"<li><b>Рабочий стол:</b> CaramelDE v2</li>"
"<li><b>Браузер:</b> CaramelFox v1.0</li>"
"<li><b>Пакеты:</b> .cede v2</li>"
"<li><b>Совместимость:</b> .exe через WineCompat layer</li>"
"</ul>"
"<h2>Браузер CaramelFox</h2>"
"<p>CaramelFox — это встроенный браузер CaramelUK, вдохновлённый Firefox. "
"Поддерживает HTML-подобную разметку, вкладки, историю, прокрутку. "
"Загружает страницы из VFS (файлы .htm/.html) и внутренние caramel:// страницы.</p>"
"<hr>"
"<p><a href=\"caramel://home\">← На главную</a></p>"
"</body></html>"
},

{ "help",
"<html><head><title>Справка CaramelUK</title></head><body>"
"<h1>Справка по командам</h1>"
"<h2>Файлы</h2>"
"<p><code>ls ll la cat view head tail grep find tree</code></p>"
"<h2>Игры</h2>"
"<p><code>snake</code> — змейка | <code>tetris</code> — тетрис</p>"
"<h2>Пасхалки</h2>"
"<p><code>matrix</code> | <code>alya</code> | <code>crash</code> | <code>helloworld</code></p>"
"<h2>Браузер</h2>"
"<p><code>browser</code> или <code>surf</code> — открыть CaramelFox</p>"
"<h2>Рабочий стол</h2>"
"<p><code>de</code> — запустить CaramelDE (только VBE режим)</p>"
"<p><code>desktop style windows|mac|caramel</code></p>"
"<h2>Пакеты .cede</h2>"
"<p><code>pkg install file.cede</code> | <code>pkg create name elf</code></p>"
"<h2>Совместимость</h2>"
"<p><code>wine program.exe</code> | <code>wincompat</code></p>"
"<h2>Настройка</h2>"
"<p><code>config create</code> или <b>Alt+C</b> — мастер настройки</p>"
"<p><code>kernel kernel_name MyOS</code> — переименовать ОС</p>"
"<hr>"
"<p><a href=\"caramel://home\">← На главную</a></p>"
"</body></html>"
},

{ "games",
"<html><head><title>Игры CaramelUK</title></head><body>"
"<h1>Игры в CaramelUK v7</h1>"
"<h2>Snake</h2>"
"<p>Классическая змейка. Поле 40×20. Команда: <code>snake</code></p>"
"<p>Управление: стрелки — движение, Q — выход, * — еда (+10 очков)</p>"
"<h2>Tetris</h2>"
"<p>Полноценный тетрис. Команда: <code>tetris</code></p>"
"<p>← → — движение, ↑ — поворот, Пробел — жёсткий сброс, Q — выход</p>"
"<p>Очки: 100/300/600/1200 за 1/2/3/4 линии. Ускорение каждые 10 линий.</p>"
"<h2>Запланировано</h2>"
"<ul><li>Pong</li><li>Minesweeper</li><li>Breakout</li></ul>"
"<hr>"
"<p><a href=\"caramel://home\">← На главную</a></p>"
"</body></html>"
},

{ "sdk",
"<html><head><title>CaramelUK SDK</title></head><body>"
"<h1>CaramelUK OS SDK v7.0</h1>"
"<h2>Регистрация команд</h2>"
"<pre>sdk_cmd_register(\"cmd\", \"help text\", my_fn);</pre>"
"<h2>Хуки ядра</h2>"
"<pre>sdk_hook_register(HOOK_BOOT_LATE, fn, ctx);\nsdk_hook_register(HOOK_TICK, fn, ctx);</pre>"
"<h2>Темы</h2>"
"<pre>sdk_theme_register(&my_scheme);</pre>"
"<h2>Переменные среды</h2>"
"<pre>sdk_env_set(\"VAR\", \"value\");\nconst char *v = sdk_env_get(\"VAR\");</pre>"
"<h2>Утилиты</h2>"
"<pre>sdk_hexdump(buf, size, 0);\nsdk_sleep_ms(500);\nsdk_serial_write(\"debug\\n\");</pre>"
"<hr>"
"<p><a href=\"caramel://home\">← На главную</a></p>"
"</body></html>"
},

{ "cede",
"<html><head><title>Формат .cede v2</title></head><body>"
"<h1>Формат пакетов .cede v2</h1>"
"<h2>Структура файла</h2>"
"<pre>[cede_header_t   512 байт]\n[cede_section_t  64 байта × N]\n[данные секций, выровнены по 16 байт]</pre>"
"<h2>Типы секций</h2>"
"<ul>"
"<li><b>ELF (1)</b> — исполняемый ELF32</li>"
"<li><b>DATA (2)</b> — файл данных</li>"
"<li><b>CONF (3)</b> — конфиг в /uiu/etc/</li>"
"<li><b>INIT (4)</b> — скрипт установки</li>"
"<li><b>LIB (5)</b> — разделяемая библиотека</li>"
"<li><b>ICON (6)</b> — иконка приложения</li>"
"<li><b>MAN (7)</b> — man-страница</li>"
"<li><b>RES (8)</b> — ресурсы</li>"
"</ul>"
"<h2>Команды</h2>"
"<pre>pkg install app.cede\npkg create myapp /syls/bin/myapp\npkg info app.cede\npkg list\npkg remove myapp</pre>"
"<h2>Magic</h2>"
"<p>v2: <code>0xCEDE0005</code> | v1 (legacy): <code>0xCEDE0004</code></p>"
"<hr>"
"<p><a href=\"caramel://home\">← На главную</a></p>"
"</body></html>"
},

{ "news",
"<html><head><title>Что нового — CaramelUK v7</title></head><body>"
"<h1>CaramelUK v7.0 \"Cupcake\" — Что нового</h1>"
"<h2>Браузер CaramelFox</h2>"
"<p>Встроенный HTML-браузер с вкладками, историей, прокруткой. "
"Поддержка caramel:// страниц и VFS файлов .html.</p>"
"<h2>Совместимость .exe</h2>"
"<p>WineCompat layer — запуск Windows PE32 программ через <code>wine</code>. "
"Эмулирует основные Win32 API вызовы.</p>"
"<h2>Игры</h2>"
"<ul><li>Snake — классическая змейка 40×20</li>"
"<li>Tetris — все 7 фигур, ротация, hard drop</li></ul>"
"<h2>Пасхалки</h2>"
"<ul><li>matrix — цифровой дождь</li>"
"<li>alya — ASCII-арт из аниме</li>"
"<li>crash — Windows BSOD</li>"
"<li>helloworld — 200 строк Hello World!</li></ul>"
"<h2>Пакеты .cede v2</h2>"
"<p>Новые типы секций, контрольная сумма, быстрый запуск через кеш.</p>"
"<hr>"
"<p><a href=\"caramel://home\">← На главную</a></p>"
"</body></html>"
},

{ "wincompat",
"<html><head><title>WineCompat — .exe совместимость</title></head><body>"
"<h1>WineCompat — запуск .exe программ</h1>"
"<p>CaramelUK v7 включает слой совместимости с Windows PE32 программами.</p>"
"<h2>Использование</h2>"
"<pre>wine program.exe\nwine program.exe arg1 arg2\nwincompat info program.exe</pre>"
"<h2>Поддерживаемые API</h2>"
"<ul>"
"<li><b>Kernel32:</b> GetStdHandle, WriteConsole, ExitProcess, Sleep, GetTickCount</li>"
"<li><b>MSVCRT:</b> printf, puts, gets, malloc, free, strlen, strcmp, memcpy</li>"
"<li><b>User32:</b> MessageBox (текстовый вывод)</li>"
"</ul>"
"<h2>Ограничения</h2>"
"<ul>"
"<li>Только PE32 (32-bit), не PE32+</li>"
"<li>Нет графических WinAPI (GDI, DirectX)</li>"
"<li>Нет реестра, нет COM</li>"
"<li>Консольные приложения работают лучше всего</li>"
"</ul>"
"<h2>Как это работает</h2>"
"<p>WineCompat парсит PE32 заголовок, загружает секции .text/.data/.bss, "
"перехватывает импорты из kernel32.dll/msvcrt.dll и заменяет их "
"нативными функциями CaramelUK.</p>"
"<hr>"
"<p><a href=\"caramel://home\">← На главную</a></p>"
"</body></html>"
},

{ NULL, NULL }
};

/* ─── Утилиты строк ─────────────────────────────────────── */
static int br_startswith(const char *s, const char *pfx) {
    while (*pfx) { if (*s != *pfx) return 0; s++; pfx++; }
    return 1;
}
static void br_strlcpy(char *dst, const char *src, int maxn) {
    int i = 0;
    while (src[i] && i < maxn-1) { dst[i]=src[i]; i++; }
    dst[i] = 0;
}
static int br_strlen(const char *s) {
    int n = 0; while (s[n]) n++; return n;
}
static void br_strcat_n(char *dst, const char *src, int dstmax) {
    int dl = br_strlen(dst);
    int i = 0;
    while (src[i] && dl+i < dstmax-1) { dst[dl+i]=src[i]; i++; }
    dst[dl+i] = 0;
}

/* ─── HTML Парсер ────────────────────────────────────────── */
static void br_parse_html(br_tab_t *tab) {
    tab->node_count = 0;
    const char *p = tab->page_buf;
    int len = tab->page_len;

    /* Текущие стили */
    int bold = 0, italic = 0, indent = 0;
    int in_pre = 0;
    char pending_text[256]; pending_text[0] = 0;

    #define PUSH_NODE(T) do { \
        if (tab->node_count >= BR_MAX_NODES-1) break; \
        br_node_t *nn = &tab->nodes[tab->node_count++]; \
        kmemset(nn, 0, sizeof(br_node_t)); \
        nn->type = (T); nn->bold = (uint8_t)bold; \
        nn->italic = (uint8_t)italic; nn->indent = (uint8_t)indent; \
    } while(0)

    int i = 0;
    while (i < len) {
        if (p[i] == '<') {
            /* Flush pending text */
            if (pending_text[0] && !in_pre) {
                PUSH_NODE(NODE_TEXT);
                br_strlcpy(tab->nodes[tab->node_count-1].text, pending_text, 127);
                pending_text[0] = 0;
            }
            /* Parse tag */
            i++;
            char tag[64]; int ti = 0;
            int closing = 0;
            if (p[i] == '/') { closing = 1; i++; }
            while (i < len && p[i] != '>' && p[i] != ' ' && ti < 63)
                tag[ti++] = p[i++];
            tag[ti] = 0;
            /* Skip to > */
            /* Also grab attrs */
            char attrs[128]; int ai = 0;
            while (i < len && p[i] != '>') {
                if (ai < 127) attrs[ai++] = p[i];
                i++;
            }
            attrs[ai] = 0;
            if (i < len) i++; /* skip > */

            /* Convert tag to lowercase */
            for (int k = 0; tag[k]; k++)
                if (tag[k]>='A'&&tag[k]<='Z') tag[k]+=32;

            /* Process tag */
            if (!kstrcmp(tag,"h1")) { if(!closing){PUSH_NODE(NODE_H1);}  }
            else if (!kstrcmp(tag,"h2")) { if(!closing){PUSH_NODE(NODE_H2);} }
            else if (!kstrcmp(tag,"h3")) { if(!closing){PUSH_NODE(NODE_H3);} }
            else if (!kstrcmp(tag,"p"))  { if(!closing){PUSH_NODE(NODE_P);} }
            else if (!kstrcmp(tag,"br")) { PUSH_NODE(NODE_BR); }
            else if (!kstrcmp(tag,"hr")) { PUSH_NODE(NODE_HR); }
            else if (!kstrcmp(tag,"b")||!kstrcmp(tag,"strong")) { bold = closing?0:1; }
            else if (!kstrcmp(tag,"i")||!kstrcmp(tag,"em"))     { italic = closing?0:1; }
            else if (!kstrcmp(tag,"pre")) { in_pre = closing?0:1; }
            else if (!kstrcmp(tag,"code")) {
                if (!closing) { PUSH_NODE(NODE_CODE); }
            }
            else if (!kstrcmp(tag,"ul")||!kstrcmp(tag,"ol")) { indent = closing?0:1; }
            else if (!kstrcmp(tag,"li")) {
                if (!closing) { PUSH_NODE(NODE_LI); }
            }
            else if (!kstrcmp(tag,"title")) {
                /* grab title text until </title> */
                int ts = i;
                while (i < len-7) {
                    if (p[i]=='<' && p[i+1]=='/' && (p[i+2]=='t'||p[i+2]=='T')) break;
                    i++;
                }
                int tlen = i-ts; if(tlen>BR_MAX_TITLE-1) tlen=BR_MAX_TITLE-1;
                kmemcpy(tab->title, p+ts, (uint32_t)tlen);
                tab->title[tlen] = 0;
            }
            else if (!kstrcmp(tag,"a")) {
                if (!closing) {
                    PUSH_NODE(NODE_A);
                    /* Extract href */
                    const char *hf = kstrstr(attrs, "href=");
                    if (hf) {
                        hf += 5;
                        char quot = (*hf=='"'||*hf=='\'') ? *hf++ : 0;
                        int hi = 0;
                        while (*hf && hi < 63 && (quot ? *hf!=quot : *hf!=' '))
                            tab->nodes[tab->node_count-1].href[hi++] = *hf++;
                        tab->nodes[tab->node_count-1].href[hi] = 0;
                    }
                }
            }
            else if (!kstrcmp(tag,"img")) {
                PUSH_NODE(NODE_IMG);
                const char *alt = kstrstr(attrs,"alt=");
                if (alt) {
                    alt += 4;
                    char q = (*alt=='"'||*alt=='\'') ? *alt++ : 0;
                    int ai2 = 0;
                    while (*alt && ai2<31 && (q ? *alt!=q : *alt!=' '))
                        tab->nodes[tab->node_count-1].alt[ai2++] = *alt++;
                    tab->nodes[tab->node_count-1].alt[ai2] = 0;
                }
            }
            /* ignore other tags: html body head etc */

        } else if (p[i] == '&') {
            /* HTML entities */
            char ent[16]; int ei = 0; i++;
            while (i < len && p[i] != ';' && ei < 15) ent[ei++] = p[i++];
            ent[ei] = 0; if (i < len) i++;
            char ch = '?';
            if (!kstrcmp(ent,"lt"))   ch = '<';
            else if (!kstrcmp(ent,"gt"))   ch = '>';
            else if (!kstrcmp(ent,"amp"))  ch = '&';
            else if (!kstrcmp(ent,"quot")) ch = '"';
            else if (!kstrcmp(ent,"nbsp")) ch = ' ';
            int pl = br_strlen(pending_text);
            if (pl < 254) { pending_text[pl]=ch; pending_text[pl+1]=0; }
        } else {
            /* Normal text */
            char c = p[i++];
            if (!in_pre && (c=='\n'||c=='\r'||c=='\t')) c = ' ';
            /* Skip multiple spaces */
            int pl = br_strlen(pending_text);
            if (!in_pre && c==' ' && pl>0 && pending_text[pl-1]==' ') continue;
            if (pl < 254) { pending_text[pl]=c; pending_text[pl+1]=0; }
            /* Flush on newline in pre */
            if (in_pre && (c=='\n')) {
                PUSH_NODE(NODE_PRE);
                pending_text[pl] = 0; /* remove the \n */
                br_strlcpy(tab->nodes[tab->node_count-1].text, pending_text, 127);
                pending_text[0] = 0;
            }
            /* Flush long text */
            if (pl >= 120) {
                PUSH_NODE(NODE_TEXT);
                br_strlcpy(tab->nodes[tab->node_count-1].text, pending_text, 127);
                pending_text[0] = 0;
            }
        }
    }
    /* Flush remaining text */
    if (pending_text[0]) {
        PUSH_NODE(NODE_TEXT);
        br_strlcpy(tab->nodes[tab->node_count-1].text, pending_text, 127);
    }
    #undef PUSH_NODE
}

/* ─── Загрузка страницы ─────────────────────────────────── */
static void br_load_url(br_tab_t *tab, const char *url) {
    br_strlcpy(tab->url, url, BR_MAX_URL);
    tab->scroll = 0;
    tab->page_len = 0;
    tab->node_count = 0;
    br_strlcpy(tab->title, url, BR_MAX_TITLE);

    /* Убираем caramel:// префикс */
    const char *path = url;
    if (br_startswith(url, "caramel://")) path = url + 10;
    else if (br_startswith(url, "http://") || br_startswith(url, "https://")) {
        /* Внешние URL — нет TCP стека */
        const char *err = "<html><head><title>Нет подключения</title></head><body>"
            "<h1>Нет подключения к интернету</h1>"
            "<p>CaramelFox не может загрузить внешние страницы — "
            "нет полного TCP/IP стека.</p>"
            "<p>Доступны только <b>caramel://</b> страницы и локальные файлы.</p>"
            "<hr><p><a href=\"caramel://home\">← На главную</a></p>"
            "</body></html>";
        br_strlcpy(tab->page_buf, err, BR_PAGE_BUF);
        tab->page_len = br_strlen(err);
        br_parse_html(tab);
        return;
    }

    /* Поиск во встроенных страницах */
    for (int i = 0; builtin_pages[i].url; i++) {
        if (!kstrcmp(path, builtin_pages[i].url)) {
            br_strlcpy(tab->page_buf, builtin_pages[i].html, BR_PAGE_BUF);
            tab->page_len = br_strlen(tab->page_buf);
            br_parse_html(tab);
            return;
        }
    }

    /* Попытка загрузить из VFS */
    int fd = vfs_open((char*)path, O_RDONLY);
    if (fd < 0) {
        /* Попробуем с расширением .html */
        char trypath[128];
        br_strlcpy(trypath, path, 120);
        br_strcat_n(trypath, ".html", 128);
        fd = vfs_open(trypath, O_RDONLY);
    }
    if (fd >= 0) {
        tab->page_len = vfs_read(fd, (uint8_t*)tab->page_buf, BR_PAGE_BUF-1);
        vfs_close(fd);
        if (tab->page_len > 0) {
            tab->page_buf[tab->page_len] = 0;
            br_parse_html(tab);
            return;
        }
    }

    /* 404 */
    char notfound[512];
    kstrcpy(notfound, "<html><head><title>404 Not Found</title></head><body>"
        "<h1>404 — Страница не найдена</h1><p>URL: ");
    br_strcat_n(notfound, url, 512);
    kstrcat(notfound, "</p><hr><p><a href=\"caramel://home\">← На главную</a></p>"
        "</body></html>");
    br_strlcpy(tab->page_buf, notfound, BR_PAGE_BUF);
    tab->page_len = br_strlen(notfound);
    br_parse_html(tab);
}

/* ─── VBE Рендерер ──────────────────────────────────────── */
#define BR_FONT_W 8
#define BR_FONT_H 16
#define BR_LINE_H 18

static void br_vbe_render(void) {
    if (!vbe.active) return;
    int W = (int)vbe.width;
    int H = (int)vbe.height;
    br_tab_t *tab = &BR.tabs[BR.cur_tab];

    /* ── Хром — табы ── */
    vbe_fill_rect(0, 0, W, BR_TAB_H, BR_C_CHROME);
    int tx = 2;
    for (int t = 0; t < BR.tab_count; t++) {
        color32_t tc = (t == BR.cur_tab) ? BR_C_TAB_ACT : BR_C_TAB_INA;
        color32_t fg = (t == BR.cur_tab) ? RGB(0,0,0) : RGB(0xCC,0xCC,0xCC);
        vbe_fill_rect(tx, 2, 140, BR_TAB_H-2, tc);
        /* Tab title truncated */
        char ttitle[18]; br_strlcpy(ttitle, BR.tabs[t].title, 16);
        br_strcat_n(ttitle, " ×", 18);
        vbe_puts(tx+4, 6, ttitle, fg, tc);
        tx += 144;
        if (tx > W-150) break;
    }
    /* + new tab button */
    vbe_fill_rect(tx+2, 4, 22, BR_TAB_H-6, BR_C_BTN);
    vbe_puts(tx+6, 6, "+", RGB(0xFF,0xFF,0xFF), BR_C_BTN);

    /* ── Хром — навигация ── */
    vbe_fill_rect(0, BR_TAB_H, W, BR_NAV_H, BR_C_CHROME);

    /* Кнопки ← → ↺ */
    int bx = 4;
    vbe_fill_rect(bx, BR_TAB_H+4, 28, BR_NAV_H-8, BR_C_BTN);
    vbe_puts(bx+8, BR_TAB_H+8, "<", RGB(0xFF,0xFF,0xFF), BR_C_BTN);
    bx += 32;
    vbe_fill_rect(bx, BR_TAB_H+4, 28, BR_NAV_H-8, BR_C_BTN);
    vbe_puts(bx+8, BR_TAB_H+8, ">", RGB(0xFF,0xFF,0xFF), BR_C_BTN);
    bx += 32;
    vbe_fill_rect(bx, BR_TAB_H+4, 28, BR_NAV_H-8, BR_C_BTN);
    vbe_puts(bx+4, BR_TAB_H+8, "F5", RGB(0xFF,0xFF,0xFF), BR_C_BTN);
    bx += 36;

    /* URL bar */
    int url_x = bx, url_w = W - bx - 70;
    vbe_fill_rect(url_x, BR_TAB_H+4, url_w, BR_NAV_H-8, BR_C_URLBAR);
    vbe_draw_rect(url_x, BR_TAB_H+4, url_w, BR_NAV_H-8, BR_C_URLBRD);
    const char *disp_url = BR.url_editing ? BR.url_bar : tab->url;
    char url_disp[80]; br_strlcpy(url_disp, disp_url, 78);
    vbe_puts(url_x+6, BR_TAB_H+9, url_disp, RGB(0x20,0x20,0x20), BR_C_URLBAR);
    if (BR.url_editing) {
        /* Cursor */
        int cl = br_strlen(url_disp);
        vbe_fill_rect(url_x+6+cl*BR_FONT_W, BR_TAB_H+9, 2, 14, RGB(0,0,0));
    }
    /* Go button */
    vbe_fill_rect(W-64, BR_TAB_H+4, 60, BR_NAV_H-8, RGB(0x00,0x77,0xFF));
    vbe_puts(W-54, BR_TAB_H+9, "Перейти", RGB(0xFF,0xFF,0xFF), RGB(0x00,0x77,0xFF));

    /* ── Контент ── */
    int cy = BR_CONTENT_Y;
    int ch = BR_CONTENT_H(H);
    vbe_fill_rect(0, cy, W, ch, BR_C_BG);

    /* Отступы */
    int margin_l = 32, margin_r = 32;
    int content_w = W - margin_l - margin_r;

    int y = cy + 12 - tab->scroll * BR_LINE_H;
    int link_idx = 0; /* счётчик ссылок для подчёркивания */

    for (int ni = 0; ni < tab->node_count; ni++) {
        br_node_t *nd = &tab->nodes[ni];
        if (y > cy + ch) break;

        switch (nd->type) {
            case NODE_H1: {
                if (y+BR_FONT_H*2 < cy) { y += BR_FONT_H*2+8; break; }
                /* Большой заголовок — 2x масштаб через двойную отрисовку */
                int nx = margin_l;
                for (int ci = 0; nd->text[ci] && nx < W-margin_r; ci++) {
                    char ch2[2]={nd->text[ci],0};
                    /* Draw char twice for bold effect */
                    vbe_puts(nx,   y,   ch2, BR_C_H1, BR_C_BG);
                    vbe_puts(nx+1, y,   ch2, BR_C_H1, BR_C_BG);
                    vbe_puts(nx,   y+1, ch2, BR_C_H1, BR_C_BG);
                    nx += BR_FONT_W;
                }
                y += BR_FONT_H + 10;
                /* Underline */
                if (y > cy && y < cy+ch)
                    vbe_draw_hline(margin_l, y-4, content_w, BR_C_H1);
                y += 4;
                break;
            }
            case NODE_H2: {
                if (y+BR_FONT_H < cy) { y += BR_FONT_H+6; break; }
                int nx = margin_l;
                for (int ci = 0; nd->text[ci] && nx < W-margin_r; ci++) {
                    char ch2[2]={nd->text[ci],0};
                    vbe_puts(nx,   y, ch2, BR_C_H2, BR_C_BG);
                    vbe_puts(nx+1, y, ch2, BR_C_H2, BR_C_BG);
                    nx += BR_FONT_W;
                }
                y += BR_FONT_H + 6;
                break;
            }
            case NODE_H3: {
                if (y+BR_FONT_H < cy) { y += BR_FONT_H+4; break; }
                int nx = margin_l;
                for (int ci = 0; nd->text[ci] && nx < W-margin_r; ci++) {
                    char ch2[2]={nd->text[ci],0};
                    vbe_puts(nx, y, ch2, BR_C_H3, BR_C_BG);
                    vbe_puts(nx+1, y, ch2, BR_C_H3, BR_C_BG);
                    nx += BR_FONT_W;
                }
                y += BR_FONT_H + 4;
                break;
            }
            case NODE_TEXT:
            case NODE_A:
            case NODE_CODE:
            case NODE_PRE: {
                if (y+BR_FONT_H < cy) { y += BR_LINE_H; break; }
                uint32_t fg = BR_C_TEXT;
                uint32_t bg = BR_C_BG;
                if (nd->type == NODE_A) fg = BR_C_LINK;
                if (nd->type == NODE_CODE) { bg = BR_C_CODE_BG; }
                int nx = margin_l + nd->indent * 16;
                /* Word wrap */
                const char *txt = nd->text;
                while (*txt && nx < W-margin_r) {
                    char ch3[2] = {*txt, 0};
                    vbe_puts(nx, y, ch3, fg, bg);
                    if (nd->bold) vbe_puts(nx+1, y, ch3, fg, bg);
                    nx += BR_FONT_W;
                    txt++;
                }
                /* Underline for links */
                if (nd->type == NODE_A && y >= cy && y < cy+ch) {
                    int llen = br_strlen(nd->text) * BR_FONT_W;
                    vbe_draw_hline(margin_l, y+BR_FONT_H, llen, BR_C_LINK);
                    link_idx++;
                }
                y += BR_LINE_H;
                break;
            }
            case NODE_LI: {
                if (y+BR_FONT_H < cy) { y += BR_LINE_H; break; }
                int nx = margin_l + 16;
                vbe_puts(nx-10, y, "\x07", BR_C_TEXT, BR_C_BG); /* bullet */
                for (int ci = 0; nd->text[ci] && nx < W-margin_r; ci++) {
                    char ch4[2]={nd->text[ci],0};
                    vbe_puts(nx, y, ch4, BR_C_TEXT, BR_C_BG);
                    nx += BR_FONT_W;
                }
                y += BR_LINE_H;
                break;
            }
            case NODE_HR: {
                if (y >= cy && y < cy+ch)
                    vbe_draw_hline(margin_l, y+4, content_w, BR_C_HR);
                y += 12;
                break;
            }
            case NODE_BR: case NODE_P: {
                y += BR_LINE_H / 2;
                break;
            }
            case NODE_IMG: {
                if (y >= cy && y < cy+ch) {
                    char imgtxt[64];
                    kstrcpy(imgtxt, "[IMG: ");
                    kstrcat(imgtxt, nd->alt[0] ? nd->alt : "image");
                    kstrcat(imgtxt, "]");
                    vbe_fill_rect(margin_l, y, 200, 40, RGB(0xEE,0xEE,0xEE));
                    vbe_draw_rect(margin_l, y, 200, 40, BR_C_HR);
                    vbe_puts(margin_l+8, y+12, imgtxt, RGB(0x66,0x66,0x66), RGB(0xEE,0xEE,0xEE));
                }
                y += 48;
                break;
            }
            default: break;
        }
    }

    /* Скроллбар */
    if (tab->scroll > 0 || tab->node_count > 20) {
        int sb_x = W - 10;
        vbe_fill_rect(sb_x, cy, 10, ch, RGB(0xE0,0xE0,0xE0));
        int total_lines = tab->node_count;
        int visible = ch / BR_LINE_H;
        if (total_lines > 0) {
            int thumb_h = ch * visible / (total_lines + visible);
            if (thumb_h < 20) thumb_h = 20;
            int thumb_y = cy + (ch - thumb_h) * tab->scroll / (total_lines > visible ? total_lines - visible : 1);
            vbe_fill_rect(sb_x+1, thumb_y, 8, thumb_h, RGB(0x99,0x99,0x99));
        }
    }

    /* ── Статус бар ── */
    vbe_fill_rect(0, H-BR_STATUS_H, W, BR_STATUS_H, BR_C_CHROME);
    char status[128];
    kstrcpy(status, "CaramelFox v1.0  |  Tab=ссылки  Enter=перейти  F5=обновить  Ctrl+T=вкладка  Alt+F4=выход");
    vbe_puts(8, H-BR_STATUS_H+4, status, RGB(0xAA,0xAA,0xAA), BR_C_CHROME);
}

/* ─── VGA Рендерер (текстовый fallback) ─────────────────── */
static void br_vga_render(void) {
    terminal_clear();
    br_tab_t *tab = &BR.tabs[BR.cur_tab];

    /* Заголовок */
    terminal_set_color(VGA_BLACK, VGA_LIGHT_GREY);
    terminal_write(" CaramelFox | ");
    terminal_write(tab->title);
    terminal_write(" | ");
    terminal_write(tab->url);
    terminal_writeln("                                        ");
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
    terminal_writeln("─────────────────────────────────────────────────────────────────────────────────");

    int line = 0;
    int skip = tab->scroll;
    for (int ni = 0; ni < tab->node_count && line < 20; ni++) {
        br_node_t *nd = &tab->nodes[ni];
        if (skip > 0) { skip--; continue; }

        switch (nd->type) {
            case NODE_H1:
                terminal_set_color(VGA_WHITE, VGA_BLACK);
                terminal_writeln(nd->text);
                terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
                line++;
                break;
            case NODE_H2:
                terminal_set_color(VGA_YELLOW, VGA_BLACK);
                terminal_writeln(nd->text);
                terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
                line++;
                break;
            case NODE_H3:
                terminal_set_color(VGA_LIGHT_CYAN, VGA_BLACK);
                terminal_writeln(nd->text);
                terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
                line++;
                break;
            case NODE_A:
                terminal_set_color(VGA_LIGHT_BLUE, VGA_BLACK);
                terminal_write("[→] ");
                terminal_writeln(nd->text);
                terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
                line++;
                break;
            case NODE_HR:
                terminal_set_color(VGA_DARK_GREY, VGA_BLACK);
                terminal_writeln("────────────────────────────────────────────────────────");
                terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
                line++;
                break;
            case NODE_LI:
                terminal_write("  • ");
                terminal_writeln(nd->text);
                line++;
                break;
            case NODE_CODE: case NODE_PRE:
                terminal_set_color(VGA_LIGHT_GREEN, VGA_BLACK);
                terminal_write("  ");
                terminal_writeln(nd->text);
                terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
                line++;
                break;
            case NODE_BR: case NODE_P:
                terminal_writeln("");
                line++;
                break;
            case NODE_IMG:
                terminal_set_color(VGA_DARK_GREY, VGA_BLACK);
                terminal_write("  [IMG: ");
                terminal_write(nd->alt[0]?nd->alt:"image");
                terminal_writeln("]");
                terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
                line++;
                break;
            default:
                if (nd->text[0]) {
                    terminal_writeln(nd->text);
                    line++;
                }
                break;
        }
    }

    terminal_set_color(VGA_DARK_GREY, VGA_BLACK);
    terminal_writeln("─────────────────────────────────────────────────────────────────────────────────");
    terminal_write("URL: "); terminal_write(tab->url);
    terminal_writeln("  | Tab=ссылки  Enter=URL  PgUp/Dn=скролл  Q=выход");
    terminal_set_color(VGA_LIGHT_GREY, VGA_BLACK);
}

static void br_render(void) {
    if (vbe.active) br_vbe_render();
    else         br_vga_render();
}

/* ─── Простой readline для URL-строки ───────────────────── */
static int readline_br(char *out, int maxlen) {
    int len = 0;
    out[0] = 0;
    while (1) {
        int k = keyboard_getkey();
        if (k == '\n' || k == '\r') { out[len]=0; return len; }
        if (k == 27) return -1;  /* ESC */
        if ((k=='\b'||k==127) && len>0) { len--; out[len]=0; }
        else if (k>=' '&&k<='~'&&len<maxlen-1) { out[len++]=(char)k; out[len]=0; }
    }
}

/* ─── Навигация по ссылкам ──────────────────────────────── */
static int br_find_next_link(br_tab_t *tab, int from) {
    for (int i = from+1; i < tab->node_count; i++)
        if (tab->nodes[i].type == NODE_A && tab->nodes[i].href[0])
            return i;
    return -1;
}

/* ─── Главный цикл ──────────────────────────────────────── */
void browser_run(void) {
    kmemset(&BR, 0, sizeof(BR));
    BR.running = 1;
    BR.tab_count = 1;
    BR.cur_tab = 0;

    /* Открываем домашнюю страницу */
    br_load_url(&BR.tabs[0], "caramel://home");
    BR.tabs[0].active = 1;

    int focused_link = -1;

    while (BR.running) {
        br_render();

        int k = keyboard_getkey();
        int alt  = keyboard_alt();
        int ctrl = keyboard_ctrl();
        br_tab_t *tab = &BR.tabs[BR.cur_tab];

        /* Выход */
        if ((k=='q'||k=='Q') && !BR.url_editing) break;
        if (alt && k == KEY_F4) break;

        /* URL editing */
        if (k == 'l' && ctrl && !BR.url_editing) {
            /* Ctrl+L — фокус на URL бар */
            BR.url_editing = 1;
            br_strlcpy(BR.url_bar, tab->url, BR_MAX_URL);
            br_render();
            if (readline_br(BR.url_bar, BR_MAX_URL) >= 0 && BR.url_bar[0]) {
                /* Добавляем caramel:// если нет схемы */
                char full_url[BR_MAX_URL];
                if (!kstrstr(BR.url_bar,"://"))
                    kstrcpy(full_url, "caramel://");
                else full_url[0] = 0;
                br_strcat_n(full_url, BR.url_bar, BR_MAX_URL);
                br_load_url(tab, full_url);
                focused_link = -1;
            }
            BR.url_editing = 0;
            continue;
        }

        if (k == '\n' || k == '\r') {
            if (BR.url_editing) {
                /* уже обработано выше */
            } else if (focused_link >= 0 && focused_link < tab->node_count) {
                /* Открыть сфокусированную ссылку */
                char href[BR_MAX_URL];
                br_strlcpy(href, tab->nodes[focused_link].href, BR_MAX_URL);
                if (!kstrstr(href,"://")) {
                    char full[BR_MAX_URL]; kstrcpy(full,"caramel://");
                    br_strcat_n(full, href, BR_MAX_URL);
                    br_strlcpy(href, full, BR_MAX_URL);
                }
                br_load_url(tab, href);
                focused_link = -1;
            } else {
                /* Enter без ссылки — открыть URL bar */
                BR.url_editing = 1;
                br_strlcpy(BR.url_bar, tab->url, BR_MAX_URL);
                br_render();
                if (readline_br(BR.url_bar, BR_MAX_URL) >= 0 && BR.url_bar[0]) {
                    char full_url[BR_MAX_URL];
                    if (!kstrstr(BR.url_bar,"://"))
                        kstrcpy(full_url,"caramel://");
                    else full_url[0]=0;
                    br_strcat_n(full_url, BR.url_bar, BR_MAX_URL);
                    br_load_url(tab, full_url);
                    focused_link = -1;
                }
                BR.url_editing = 0;
            }
            continue;
        }

        /* Tab — следующая ссылка */
        if (k == '\t') {
            int next = br_find_next_link(tab, focused_link);
            if (next < 0) next = br_find_next_link(tab, -1); /* wrap */
            focused_link = next;
            continue;
        }

        /* F5 — обновить */
        if (k == KEY_F5) {
            br_load_url(tab, tab->url);
            focused_link = -1;
            continue;
        }

        /* Ctrl+T — новая вкладка */
        if (ctrl && (k=='t'||k=='T') && BR.tab_count < BR_MAX_TABS) {
            int idx = BR.tab_count++;
            kmemset(&BR.tabs[idx], 0, sizeof(br_tab_t));
            BR.cur_tab = idx;
            br_load_url(&BR.tabs[idx], "caramel://home");
            focused_link = -1;
            continue;
        }

        /* Ctrl+W — закрыть вкладку */
        if (ctrl && (k=='w'||k=='W') && BR.tab_count > 1) {
            for (int i = BR.cur_tab; i < BR.tab_count-1; i++)
                BR.tabs[i] = BR.tabs[i+1];
            BR.tab_count--;
            if (BR.cur_tab >= BR.tab_count) BR.cur_tab = BR.tab_count-1;
            focused_link = -1;
            continue;
        }

        /* Ctrl+Tab / Ctrl+1-8 — переключение вкладок */
        if (ctrl && k == '\t') {
            BR.cur_tab = (BR.cur_tab + 1) % BR.tab_count;
            focused_link = -1;
            continue;
        }

        /* Прокрутка */
        if (k == KEY_PGDN || k == KEY_DOWN) { tab->scroll += 3; continue; }
        if (k == KEY_PGUP || k == KEY_UP)   { if(tab->scroll>0)tab->scroll-=3; continue; }
        if (k == KEY_HOME) { tab->scroll = 0; continue; }
        if (k == KEY_END)  { tab->scroll = tab->node_count; continue; }

        /* Цифры 1-4 — переключение вкладок */
        if (k>='1'&&k<='8' && !ctrl && !alt) {
            int ti = k - '1';
            if (ti < BR.tab_count) { BR.cur_tab = ti; focused_link = -1; }
            continue;
        }
    }

    /* Очистка */
    if (vbe.active) vbe_clear(RGB(0x1E,0x1E,0x2E));
    else terminal_clear();
}

void browser_open_url(const char *url) {
    if (BR.tab_count == 0) {
        BR.tab_count = 1;
        BR.cur_tab = 0;
    }
    br_load_url(&BR.tabs[BR.cur_tab], url);
}
