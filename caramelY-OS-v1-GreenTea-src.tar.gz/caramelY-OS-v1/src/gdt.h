#ifndef GDT_H
#define GDT_H

#include <stdint.h>

/* GDT entry structure */
typedef struct __attribute__((packed)) {
    uint16_t limit_low;
    uint16_t base_low;
    uint8_t  base_mid;
    uint8_t  access;
    uint8_t  granularity;
    uint8_t  base_high;
} gdt_entry_t;

/* GDT pointer */
typedef struct __attribute__((packed)) {
    uint16_t limit;
    uint32_t base;
} gdt_ptr_t;

void gdt_install(void);

/* External asm flush */
extern void gdt_flush(gdt_ptr_t *ptr);

#endif
