#ifndef SCHED_H
#define SCHED_H

#include <stdint.h>
#include <stddef.h>

#define TASK_MAX        16
#define TASK_STACK_SIZE 4096

typedef enum {
    TASK_UNUSED  = 0,
    TASK_READY   = 1,
    TASK_RUNNING = 2,
    TASK_BLOCKED = 3,
    TASK_ZOMBIE  = 4,
} task_state_t;

/* Saved CPU registers for context switch */
typedef struct {
    uint32_t edi, esi, ebp, esp, ebx, edx, ecx, eax;
    uint32_t eip;
    uint32_t eflags;
} cpu_context_t;

typedef void (*task_fn_t)(void);

typedef struct task {
    uint32_t      pid;
    char          name[32];
    task_state_t  state;
    cpu_context_t ctx;
    uint32_t     *stack_base;   /* allocated stack */
    uint32_t      stack_size;
    uint32_t      ticks;        /* total ticks consumed */
    uint32_t      priority;     /* 1=low, 5=normal, 10=high */
    int           exit_code;
    struct task  *next;         /* run-queue list */
} task_t;

/* Public API */
void    sched_init(void);
task_t *task_create(const char *name, task_fn_t fn, uint32_t priority);
void    task_exit(int code);
void    task_yield(void);
void    task_block(void);
void    task_unblock(task_t *t);
void    sched_tick(void);          /* called from PIT IRQ */
task_t *sched_current(void);
void    sched_print_tasks(void);   /* ps command */
uint32_t sched_uptime_ticks(void);

/* Context switch (implemented in boot.s) */
extern void context_switch(cpu_context_t *old_ctx, cpu_context_t *new_ctx);

#endif
