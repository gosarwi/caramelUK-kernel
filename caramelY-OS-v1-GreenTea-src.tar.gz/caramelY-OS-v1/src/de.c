/* de.c — CaramelDE v10.0 "Lollipop" — Full GUI */
#include "de.h"
#include "vbe.h"
#include "vga.h"
#include "keyboard.h"
#include "vfs.h"
#include "util.h"
#include "pit.h"
#include "sched.h"
#include "kmalloc.h"
#include "net.h"
#include "disk.h"
#include "config.h"
#include "fileformat.h"
#include "ossdk.h"
#include <stdint.h>
#include <stddef.h>

extern void dispatch(char *line);

static de_state_t DE;
static int next_id = 1;
static int icon_sel = 0;
static char cap_buf[4096];
static int  cap_len = 0;
static int  capturing = 0;

/* ─── Draw helpers ──────────────────────────────────────── */
#define R(x,y,w,h,c)  vbe_fill_rect(x,y,w,h,c)
#define HL(x,y,w,c)   vbe_draw_hline(x,y,w,c)
#define VL(x,y,h,c)   vbe_draw_vline(x,y,h,c)
#define BOX(x,y,w,h,c) vbe_draw_rect(x,y,w,h,c)
#define T(x,y,s,f,b)  vbe_puts(x,y,s,f,b)
#define CX(w) ((w)->x+2)
#define CY(w) ((w)->y+DE_TITLEBAR_H+1)
#define CW(w) ((w)->w-4)
#define CH(w) ((w)->h-DE_TITLEBAR_H-3)

static void TF(int x,int y,color32_t fg,color32_t bg,const char*fmt,...){
    char buf[128]; int i=0;
    __builtin_va_list ap; __builtin_va_start(ap,fmt);
    while(*fmt&&i<124){
        if(*fmt!='%'){buf[i++]=*fmt++;continue;}
        fmt++;
        if(*fmt=='s'){const char*s=__builtin_va_arg(ap,const char*);if(s)while(*s&&i<124)buf[i++]=*s++;}
        else if(*fmt=='d'){int n=__builtin_va_arg(ap,int);char t[12];kitoa(n,t,10);for(int j=0;t[j]&&i<124;j++)buf[i++]=t[j];}
        else if(*fmt=='u'){uint32_t n=__builtin_va_arg(ap,uint32_t);char t[12];kuitoa(n,t,10);for(int j=0;t[j]&&i<124;j++)buf[i++]=t[j];}
        else if(*fmt=='%'){buf[i++]='%';}
        fmt++;
    }
    buf[i]=0; __builtin_va_end(ap);
    vbe_puts(x,y,buf,fg,bg);
}

/* Rounded rect (2px corners) */
static void RR(int x,int y,int w,int h,color32_t c){
    R(x+2,y,w-4,h,c); R(x,y+2,2,h-4,c); R(x+w-2,y+2,2,h-4,c);
    vbe_putpixel(x+1,y+1,c); vbe_putpixel(x+w-2,y+1,c);
    vbe_putpixel(x+1,y+h-2,c); vbe_putpixel(x+w-2,y+h-2,c);
}

/* ─── Notifications ─────────────────────────────────────── */
void de_notify(const char *msg, color32_t color){
    for(int i=0;i<DE_NOTIF_MAX;i++){
        if(!DE.notifs[i].active){
            kstrncpy(DE.notifs[i].msg,msg,63);
            DE.notifs[i].color=color;
            DE.notifs[i].expire=pit_get_ticks()+300;
            DE.notifs[i].active=1;
            return;
        }
    }
}
static void draw_notifs(void){
    int y=DE_SCR_H-DE_TASKBAR_H-8;
    for(int i=DE_NOTIF_MAX-1;i>=0;i--){
        if(!DE.notifs[i].active) continue;
        if(pit_get_ticks()>DE.notifs[i].expire){DE.notifs[i].active=0;continue;}
        int nw=200,nh=24,nx=DE_SCR_W-nw-8;
        RR(nx,y,nw,nh,C_SURFACE0); BOX(nx,y,nw,nh,DE.notifs[i].color);
        T(nx+8,y+4,DE.notifs[i].msg,DE.notifs[i].color,C_SURFACE0);
        y-=nh+4;
    }
}

/* ─── Clock ─────────────────────────────────────────────── */
static void clock_update(void){
    uint32_t now=pit_get_ticks();
    if(now-DE.last_clock>=100){
        DE.clock_sec+=(now-DE.last_clock)/100;
        DE.last_clock=now;
    }
}
static void clock_str(char *out){
    uint32_t s=DE.clock_sec; char t[8]; out[0]=0;
    if(s/3600<10)kstrcat(out,"0"); kuitoa(s/3600,t,10); kstrcat(out,t); kstrcat(out,":");
    if((s/60)%60<10)kstrcat(out,"0"); kuitoa((s/60)%60,t,10); kstrcat(out,t); kstrcat(out,":");
    if(s%60<10)kstrcat(out,"0"); kuitoa(s%60,t,10); kstrcat(out,t);
}

/* ─── Taskbar ────────────────────────────────────────────── */
static void draw_taskbar(void){
    R(0,0,DE_SCR_W,DE_TASKBAR_H,C_CRUST);
    HL(0,DE_TASKBAR_H-1,DE_SCR_W,C_SURFACE0);
    /* Launcher button */
    color32_t lb=DE.launcher_open?C_BLUE:C_SURFACE1;
    RR(2,2,72,DE_TASKBAR_H-4,lb);
    T(10,5,"  Apps",DE.launcher_open?C_CRUST:C_LAVENDER,lb);
    /* Window buttons */
    int wx=80;
    for(int i=0;i<DE.win_count;i++){
        de_win_t *w=&DE.wins[i];
        int isel=(i==DE.active);
        color32_t bg=w->minimized?C_SURFACE0:(isel?C_SURFACE2:C_MANTLE);
        color32_t fg=isel?C_TEXT:C_SUBTEXT;
        RR(wx,2,104,DE_TASKBAR_H-4,bg);
        if(isel) HL(wx+4,DE_TASKBAR_H-3,96,C_BLUE);
        char ttl[11]; kstrncpy(ttl,w->title,9); ttl[9]=0;
        T(wx+5,5,ttl,fg,bg);
        wx+=110;
    }
    /* Right side: net indicator + layout + clock */
    extern int keyboard_ru(void);
    char clk[16]; clock_str(clk);
    int cw2=(int)kstrlen(clk)*8+4;
    T(DE_SCR_W-cw2-4,5,clk,C_TEXT,C_CRUST);
    T(DE_SCR_W-cw2-44,5,keyboard_ru()?"[RU]":"[EN]",
      keyboard_ru()?C_PEACH:C_SAPPHIRE, C_CRUST);
    T(DE_SCR_W-cw2-56,5,"*",
      net.initialized?C_GREEN:C_MAROON, C_CRUST);
}

/* ─── Desktop ────────────────────────────────────────────── */
typedef struct { int x,y; app_id_t app; const char *label; color32_t ic; } DI;
static const DI ICONS[6]={
    {20, DE_TASKBAR_H+20, APP_TERMINAL,"Terminal", C_SKY    },
    {90, DE_TASKBAR_H+20, APP_FILES,   "Files",    C_YELLOW },
    {160,DE_TASKBAR_H+20, APP_EDITOR,  "Editor",   C_GREEN  },
    {230,DE_TASKBAR_H+20, APP_SYSMON,  "Monitor",  C_MAUVE  },
    {300,DE_TASKBAR_H+20, APP_SETTINGS,"Settings", C_PEACH  },
    {370,DE_TASKBAR_H+20, APP_ABOUT,   "About",    C_LAVENDER},
};
#define NICONS 6

static void draw_desktop(void){
    /* Gradient background — avoid variable name 't' next to hex */
    for(int py=DE_TASKBAR_H; py<DE_SCR_H-DE_TASKBAR_H; py++){
        uint32_t prog=(uint32_t)(py-DE_TASKBAR_H);
        uint32_t span=(uint32_t)(DE_SCR_H-2*DE_TASKBAR_H); if(!span)span=1;
        uint8_t rv=(uint8_t)(0x1Eu+(prog*6u/span));
        uint8_t gv=(uint8_t)(0x1Eu+(prog*4u/span));
        uint8_t bv=(uint8_t)(0x2Eu+(prog*14u/span));
        HL(0,py,DE_SCR_W,RGB(rv,gv,bv));
    }
    /* Desktop icons */
    for(int i=0;i<NICONS;i++){
        int sel=(i==icon_sel);
        int ix=ICONS[i].x, iy=ICONS[i].y, sz=56;
        color32_t bg=sel?C_SURFACE1:C_BASE;
        RR(ix,iy,sz,sz,bg);
        if(sel) BOX(ix,iy,sz,sz,ICONS[i].ic);
        /* Icon body */
        color32_t ibg=RGB(((ICONS[i].ic>>16)&0xFF)/3,
                          ((ICONS[i].ic>>8 )&0xFF)/3,
                          ((ICONS[i].ic    )&0xFF)/3);
        R(ix+8,iy+4,sz-16,sz-24,ibg);
        char sym[2]={ICONS[i].label[0],0};
        T(ix+sz/2-4,iy+8,sym,ICONS[i].ic,ibg);
        /* Label */
        int ll=(int)kstrlen(ICONS[i].label)*8;
        T(ix+(sz-ll)/2,iy+sz-14,ICONS[i].label,
          sel?ICONS[i].ic:C_SUBTEXT, C_BASE);
    }
    T(4,DE_SCR_H-DE_TASKBAR_H-16,
      "Tab=icon  Enter=open  F2=Launcher  Alt+arrows=move win  Ctrl+Alt+Bksp=Shell",
      C_OVERLAY0, C_BASE);
}

/* ─── Window chrome ──────────────────────────────────────── */
static void draw_chrome(de_win_t *w, int focused){
    color32_t bd=focused?C_BLUE:C_SURFACE1;
    color32_t tb=focused?C_MANTLE:C_CRUST;
    color32_t tf=focused?C_TEXT:C_SUBTEXT;
    R(w->x+4,w->y+4,w->w,w->h,RGB(0x08,0x08,0x12)); /* shadow */
    R(w->x,w->y,w->w,w->h,C_BASE);
    R(w->x,w->y,w->w,DE_TITLEBAR_H,tb);
    HL(w->x,w->y+DE_TITLEBAR_H,w->w,bd);
    T(w->x+36,w->y+3,w->title,tf,tb);
    /* Control buttons */
    int bx=w->x+w->w-20;
    R(bx,w->y+3,16,15,RGB(0xC0,0x20,0x20));
    T(bx+4,w->y+3,"x",C_TEXT,RGB(0xC0,0x20,0x20));
    R(bx-20,w->y+3,16,15,RGB(0x20,0x80,0x20));
    T(bx-16,w->y+3,w->maximized?"v":"^",C_TEXT,RGB(0x20,0x80,0x20));
    R(bx-40,w->y+3,16,15,RGB(0x80,0x60,0x10));
    T(bx-36,w->y+3,"_",C_TEXT,RGB(0x80,0x60,0x10));
    BOX(w->x,w->y,w->w,w->h,bd);
    if(focused) BOX(w->x+1,w->y+1,w->w-2,w->h-2,C_SURFACE0);
}

/* ─── Terminal ───────────────────────────────────────────── */
static void term_addl(de_win_t *w, const char *txt, color32_t col, int prompt){
    if(w->tcount<DE_TERM_HIST){
        kstrncpy(w->tlines[w->tcount].text,txt,DE_TERM_COLS+3);
        w->tlines[w->tcount].color=col;
        w->tlines[w->tcount].is_prompt=(uint8_t)prompt;
        w->tcount++;
    } else {
        for(int i=0;i<DE_TERM_HIST-1;i++) w->tlines[i]=w->tlines[i+1];
        kstrncpy(w->tlines[DE_TERM_HIST-1].text,txt,DE_TERM_COLS+3);
        w->tlines[DE_TERM_HIST-1].color=col;
        w->tlines[DE_TERM_HIST-1].is_prompt=(uint8_t)prompt;
    }
    w->tscroll=w->tcount;
}

void de_capture_char(char c){
    if(capturing && cap_len<4095) cap_buf[cap_len++]=c;
}

static void draw_terminal(de_win_t *w){
    int cx=CX(w),cy=CY(w),cw2=CW(w),ch=CH(w);
    R(cx,cy,cw2,ch,C_CRUST);
    int rows=(ch-22)/16; if(rows<1)rows=1;
    int start=w->tscroll-rows; if(start<0)start=0;
    for(int i=0;i<rows&&(start+i)<w->tcount;i++){
        de_tline_t *ln=&w->tlines[start+i];
        int ly=cy+i*16+2;
        if(ln->is_prompt){
            T(cx+4,ly,"$ ",C_GREEN,C_CRUST);
            T(cx+20,ly,ln->text,C_TEXT,C_CRUST);
        } else {
            T(cx+4,ly,ln->text,ln->color,C_CRUST);
        }
    }
    /* Scrollbar */
    if(w->tcount>rows){
        int sbh=ch-22;
        int th=sbh*rows/w->tcount; if(th<6)th=6;
        int ty=cy+(sbh-th)*start/w->tcount;
        R(cx+cw2-5,cy,5,sbh,C_SURFACE0);
        R(cx+cw2-4,ty,3,th,C_SURFACE2);
    }
    /* Input line */
    int iy=cy+ch-20;
    HL(cx,iy-1,cw2,C_SURFACE1);
    R(cx,iy,cw2,20,C_MANTLE);
    T(cx+4,iy+2,"$ ",C_GREEN,C_MANTLE);
    T(cx+20,iy+2,w->tinput,C_TEXT,C_MANTLE);
    /* Cursor blink */
    if((pit_get_ticks()/50)%2==0)
        R(cx+20+w->tinput_pos*8,iy+2,2,14,C_TEXT);
}

static void term_exec(de_win_t *w){
    if(!w->tinput[0]) return;
    /* Add to history */
    if(w->thist_count<32) kstrcpy(w->thist[w->thist_count++],w->tinput);
    else {
        for(int i=0;i<31;i++) kstrcpy(w->thist[i],w->thist[i+1]);
        kstrcpy(w->thist[31],w->tinput);
    }
    w->thist_idx=w->thist_count;
    term_addl(w,w->tinput,C_LAVENDER,1);
    if(!kstrcmp(w->tinput,"clear")){
        w->tcount=0; w->tscroll=0;
    } else if(!kstrcmp(w->tinput,"exit")||!kstrcmp(w->tinput,"quit")){
        DE.running=0;
    } else {
        /* Capture output */
        cap_len=0; capturing=1;
        dispatch(w->tinput);
        capturing=0;
        if(cap_len>0){
            cap_buf[cap_len]=0;
            char *p=cap_buf;
            while(*p){
                char *e=p; while(*e&&*e!='\n') e++;
                char sv=*e; *e=0;
                if(*p) term_addl(w,p,C_TEXT,0);
                *e=sv; p=(*e=='\n')?e+1:e;
                if(!*p) break;
            }
        }
    }
    w->tinput[0]=0; w->tinput_pos=0;
}

static void term_key(de_win_t *w, int k){
    int rows=CH(w)/16-2;
    if(k==KEY_PGUP){w->tscroll-=rows/2;if(w->tscroll<0)w->tscroll=0;return;}
    if(k==KEY_PGDN){w->tscroll+=rows/2;if(w->tscroll>w->tcount)w->tscroll=w->tcount;return;}
    if(k==KEY_END){w->tscroll=w->tcount;return;}
    if(k==KEY_HOME&&w->tinput_pos==0){w->tscroll=0;return;}
    if(k=='\n'||k=='\r'){term_exec(w);return;}
    if(k=='\b'||k==127){
        if(w->tinput_pos>0){
            int p=w->tinput_pos-1;
            int l=(int)kstrlen(w->tinput);
            for(int i=p;i<l;i++) w->tinput[i]=w->tinput[i+1];
            w->tinput_pos--;
        }
        return;
    }
    if(k==KEY_DEL){
        int l=(int)kstrlen(w->tinput);
        if(w->tinput_pos<l){
            for(int i=w->tinput_pos;i<l;i++) w->tinput[i]=w->tinput[i+1];
        }
        return;
    }
    if(k==KEY_LEFT){ if(w->tinput_pos>0)w->tinput_pos--; return;}
    if(k==KEY_RIGHT){ if(w->tinput[w->tinput_pos])w->tinput_pos++; return;}
    if(k==KEY_HOME){ w->tinput_pos=0; return;}
    if(k==KEY_UP){
        if(w->thist_idx>0){
            w->thist_idx--;
            kstrcpy(w->tinput,w->thist[w->thist_idx]);
            w->tinput_pos=(int)kstrlen(w->tinput);
        }
        return;
    }
    if(k==KEY_DOWN){
        if(w->thist_idx<w->thist_count-1){
            w->thist_idx++;
            kstrcpy(w->tinput,w->thist[w->thist_idx]);
            w->tinput_pos=(int)kstrlen(w->tinput);
        } else {
            w->thist_idx=w->thist_count;
            w->tinput[0]=0; w->tinput_pos=0;
        }
        return;
    }
    if(k=='\t'){
        /* Tab completion from cwd */
        char *last=w->tinput; char *p=w->tinput;
        while(*p){if(*p==' ')last=p+1;p++;}
        int plen=(int)kstrlen(last);
        char ns[32][VFS_NAME_MAX]; int cnt=0;
        vfs_listdir("/",&ns[0],&cnt);
        char best[VFS_NAME_MAX]={0}; int matches=0;
        for(int i=0;i<cnt;i++){
            char nm[VFS_NAME_MAX]; kstrcpy(nm,ns[i]);
            int nl=(int)kstrlen(nm); if(nl&&nm[nl-1]=='/') nm[nl-1]=0;
            if(plen==0||kstrncmp(nm,last,(size_t)plen)==0){
                if(++matches==1) kstrcpy(best,ns[i]);
            }
        }
        if(matches==1){
            int bl=(int)kstrlen(best); int add=bl-plen;
            int tl=(int)kstrlen(w->tinput);
            if(tl+add<253){
                kstrncpy(w->tinput+tl,best+plen,(size_t)add);
                w->tinput[tl+add]=' '; w->tinput[tl+add+1]=0;
                w->tinput_pos=tl+add+1;
            }
        }
        return;
    }
    if(k==3){term_addl(w,"^C",C_RED,0);w->tinput[0]=0;w->tinput_pos=0;return;}
    if(k==12){w->tcount=0;w->tscroll=0;w->tinput[0]=0;w->tinput_pos=0;return;}
    /* UTF-8 Russian */
    extern char keyboard_utf8_buf[4];
    if(k==0x200){
        int ul=(int)kstrlen(keyboard_utf8_buf);
        int tl=(int)kstrlen(w->tinput);
        if(tl+ul<253){
            for(int i=tl+ul;i>=w->tinput_pos+ul;i--)
                w->tinput[i]=w->tinput[i-ul];
            for(int i=0;i<ul;i++)
                w->tinput[w->tinput_pos+i]=keyboard_utf8_buf[i];
            w->tinput_pos+=ul;
        }
        return;
    }
    if(k>=0x20&&k<=0x7E){
        int tl=(int)kstrlen(w->tinput);
        if(tl<253){
            for(int i=tl;i>=w->tinput_pos;i--) w->tinput[i+1]=w->tinput[i];
            w->tinput[w->tinput_pos]=(char)k;
            w->tinput_pos++;
        }
    }
}

/* ─── File Manager ───────────────────────────────────────── */
static void fm_load(de_win_t *w){
    w->fm_count=0;
    if(kstrcmp(w->fm_path,"/")!=0){
        kstrcpy(w->fm_ent[0].name,"..");
        w->fm_ent[0].is_dir=1; w->fm_ent[0].size=0;
        w->fm_count=1;
    }
    char ns[FM_MAX_ENTRIES][VFS_NAME_MAX]; int cnt=0;
    if(vfs_listdir(w->fm_path,&ns[0],&cnt)<0) return;
    for(int i=0;i<cnt&&w->fm_count<FM_MAX_ENTRIES;i++){
        kstrncpy(w->fm_ent[w->fm_count].name,ns[i],FM_NAME_LEN-1);
        int nl=(int)kstrlen(ns[i]);
        w->fm_ent[w->fm_count].is_dir=(nl>0&&ns[i][nl-1]=='/');
        char fp[128]; kstrcpy(fp,w->fm_path);
        if(fp[kstrlen(fp)-1]!='/') kstrcat(fp,"/");
        kstrcat(fp,ns[i]);
        vfs_stat_t st; if(vfs_stat(fp,&st)==0) w->fm_ent[w->fm_count].size=st.size;
        else w->fm_ent[w->fm_count].size=0;
        w->fm_count++;
    }
    if(w->fm_sel>=w->fm_count) w->fm_sel=w->fm_count-1;
    if(w->fm_sel<0) w->fm_sel=0;
    w->fm_preview[0]=0;
}

static void fm_preview(de_win_t *w){
    if(w->fm_sel<0||w->fm_sel>=w->fm_count||w->fm_ent[w->fm_sel].is_dir){
        w->fm_preview[0]=0; return;
    }
    char fp[128]; kstrcpy(fp,w->fm_path);
    if(fp[kstrlen(fp)-1]!='/') kstrcat(fp,"/");
    kstrcat(fp,w->fm_ent[w->fm_sel].name);
    int fd=vfs_open(fp,O_RDONLY); if(fd<0) return;
    int n=vfs_read(fd,(uint8_t*)w->fm_preview,510);
    vfs_close(fd);
    if(n>0) w->fm_preview[n]=0; else w->fm_preview[0]=0;
}

static void draw_files(de_win_t *w){
    int cx=CX(w),cy=CY(w),cw2=CW(w),ch=CH(w);
    R(cx,cy,cw2,ch,C_BASE);
    /* Path bar */
    R(cx,cy,cw2,18,C_MANTLE);
    TF(cx+4,cy+1,C_LAVENDER,C_MANTLE," %s",w->fm_path);
    HL(cx,cy+18,cw2,C_SURFACE0);
    /* Two panels */
    int lw2=(cw2*3)/5, rw2=cw2-lw2-4, rh=17;
    int start=w->fm_scroll, mr=(ch-22)/rh;
    for(int i=0;i<mr&&(start+i)<w->fm_count;i++){
        fm_entry_t *e=&w->fm_ent[start+i];
        int ry=cy+22+i*rh;
        int sel2=(start+i==w->fm_sel);
        color32_t bg=sel2?C_SURFACE1:((i%2==0)?C_BASE:C_MANTLE);
        R(cx,ry,lw2,rh,bg);
        if(sel2) HL(cx,ry,lw2,C_BLUE);
        T(cx+4,ry+1,e->is_dir?"[D]":"[F]",e->is_dir?C_YELLOW:C_TEXT,bg);
        char nm2[FM_NAME_LEN]; kstrcpy(nm2,e->name);
        int nl2=(int)kstrlen(nm2);
        if(nl2>1&&nm2[nl2-1]=='/') nm2[nl2-1]=0;
        int maxn=(lw2-60)/8; if(maxn<4)maxn=4;
        if((int)kstrlen(nm2)>maxn){nm2[maxn-2]='.';nm2[maxn-1]='.';nm2[maxn]=0;}
        T(cx+32,ry+1,nm2,sel2?C_TEXT:(e->is_dir?C_YELLOW:C_TEXT),bg);
        if(!e->is_dir&&e->size>0){
            char sz[12];
            if(e->size>=1024){kuitoa(e->size/1024,sz,10);kstrcat(sz,"K");}
            else{kuitoa(e->size,sz,10);}
            T(cx+lw2-44,ry+1,sz,C_SUBTEXT,bg);
        }
    }
    VL(cx+lw2+1,cy+20,ch-20,C_SURFACE1);
    /* Preview panel */
    int px2=cx+lw2+4, py2=cy+22;
    R(px2,cy+20,rw2,ch-20,C_MANTLE);
    T(px2+4,py2,"Preview",C_LAVENDER,C_MANTLE); py2+=20;
    HL(px2,py2,rw2,C_SURFACE0); py2+=4;
    if(w->fm_sel>=0&&w->fm_sel<w->fm_count){
        fm_entry_t *e=&w->fm_ent[w->fm_sel];
        char nm3[FM_NAME_LEN]; kstrcpy(nm3,e->name);
        int nl3=(int)kstrlen(nm3);
        if(nl3>1&&nm3[nl3-1]=='/') nm3[nl3-1]=0;
        TF(px2+4,py2,C_LAVENDER,C_MANTLE,"%.16s",nm3); py2+=16;
        TF(px2+4,py2,C_SUBTEXT,C_MANTLE,"%s",e->is_dir?"folder":"file"); py2+=16;
        if(!e->is_dir&&e->size>0){
            char sz2[16]; kuitoa(e->size,sz2,10); kstrcat(sz2," B");
            T(px2+4,py2,sz2,C_SUBTEXT,C_MANTLE); py2+=16;
        }
        py2+=8;
        if(w->fm_preview[0]&&!e->is_dir){
            T(px2+4,py2,"---",C_SURFACE2,C_MANTLE); py2+=12;
            const char *pp=w->fm_preview; int plines=0;
            int mpl=(ch-(py2-cy))/13; if(mpl<0)mpl=0;
            while(*pp&&plines<mpl){
                char ln2[18]; int li=0;
                while(*pp&&*pp!='\n'&&li<(rw2/8)-1) ln2[li++]=*pp++;
                ln2[li]=0; if(*pp=='\n') pp++;
                T(px2+4,py2,ln2,C_SUBTEXT,C_MANTLE);
                py2+=13; plines++;
            }
        }
    }
    /* Scrollbar */
    if(w->fm_count>mr){
        int sbh=ch-22; int th=sbh*mr/w->fm_count; if(th<6)th=6;
        int ty=cy+22+(sbh-th)*start/w->fm_count;
        R(cx+lw2-4,cy+22,4,sbh,C_SURFACE0);
        R(cx+lw2-3,ty,2,th,C_SURFACE2);
    }
    HL(cx,cy+ch-16,cw2,C_SURFACE0);
    R(cx,cy+ch-15,cw2,15,C_MANTLE);
    T(cx+4,cy+ch-14,"Enter=open  Bksp=up  PgUp/Dn=scroll",C_SUBTEXT,C_MANTLE);
}

static void fm_key(de_win_t *w, int k){
    int mr=CH(w)/17;
    if(k==KEY_UP&&w->fm_sel>0){
        w->fm_sel--;
        if(w->fm_sel<w->fm_scroll) w->fm_scroll--;
        fm_preview(w);
    }
    if(k==KEY_DOWN&&w->fm_sel<w->fm_count-1){
        w->fm_sel++;
        if(w->fm_sel>=w->fm_scroll+mr) w->fm_scroll++;
        fm_preview(w);
    }
    if(k==KEY_PGUP){
        w->fm_sel-=mr; if(w->fm_sel<0)w->fm_sel=0;
        w->fm_scroll-=mr; if(w->fm_scroll<0)w->fm_scroll=0;
        fm_preview(w);
    }
    if(k==KEY_PGDN){
        w->fm_sel+=mr; if(w->fm_sel>=w->fm_count)w->fm_sel=w->fm_count-1;
        w->fm_scroll+=mr;
        if(w->fm_scroll>w->fm_count-mr&&w->fm_count>mr)w->fm_scroll=w->fm_count-mr;
        if(w->fm_scroll<0)w->fm_scroll=0;
        fm_preview(w);
    }
    if(k=='\n'||k=='\r'){
        if(w->fm_sel<0||w->fm_sel>=w->fm_count) return;
        fm_entry_t *e=&w->fm_ent[w->fm_sel];
        if(e->is_dir){
            if(kstrcmp(e->name,"..")==0){
                char *last=w->fm_path, *p=w->fm_path;
                while(*p){if(*p=='/')last=p;p++;}
                if(last!=w->fm_path)*last=0;
                else{w->fm_path[0]='/';w->fm_path[1]=0;}
            } else {
                char nm4[FM_NAME_LEN]; kstrcpy(nm4,e->name);
                int nl4=(int)kstrlen(nm4);
                if(nl4>0&&nm4[nl4-1]=='/') nm4[nl4-1]=0;
                if(w->fm_path[kstrlen(w->fm_path)-1]!='/') kstrcat(w->fm_path,"/");
                kstrcat(w->fm_path,nm4);
            }
            w->fm_sel=0; w->fm_scroll=0; fm_load(w);
        } else {
            char fp[128]; kstrcpy(fp,w->fm_path);
            if(fp[kstrlen(fp)-1]!='/') kstrcat(fp,"/");
            kstrcat(fp,e->name);
            de_open_app(APP_VIEWER,fp);
        }
    }
    if(k=='\b'){
        char *last=w->fm_path, *p=w->fm_path;
        while(*p){if(*p=='/')last=p;p++;}
        if(last!=w->fm_path)*last=0;
        else{w->fm_path[0]='/';w->fm_path[1]=0;}
        w->fm_sel=0; w->fm_scroll=0; fm_load(w);
    }
}

/* ─── System Monitor ─────────────────────────────────────── */
static void sysmon_upd(de_win_t *w){
    uint32_t now=pit_get_ticks();
    sysmon_t *s=&w->sysmon;
    if(now-s->last_tick<50) return;
    s->last_tick=now;
    static uint32_t cseed=0xBEEF;
    cseed=cseed*1664525u+1013904223u;
    s->cpu[s->head]=(uint8_t)(10+(cseed>>24)%30);
    uint32_t used=heap_used_bytes(), total=used+heap_free_bytes();
    s->mem[s->head]=(total>0)?(uint8_t)((used/(total/100))):0u;
    s->head=(s->head+1)%SYSMON_HISTORY;
}

static void draw_graph(int gx,int gy,int gw,int gh,
                       uint8_t *data,int head,
                       color32_t lc,color32_t bgc,
                       const char *lbl,uint8_t val){
    R(gx,gy,gw,gh,bgc); BOX(gx,gy,gw,gh,C_SURFACE1);
    for(int qi=1;qi<4;qi++) HL(gx+1,gy+gh*qi/4,gw-2,C_SURFACE0);
    for(int qi=0;qi<SYSMON_HISTORY-1;qi++){
        int i1=(head+qi)%SYSMON_HISTORY;
        int i2=(head+qi+1)%SYSMON_HISTORY;
        int x1=gx+1+qi*(gw-2)/SYSMON_HISTORY;
        int y1=gy+gh-1-(int)data[i1]*(gh-2)/100;
        int y2=gy+gh-1-(int)data[i2]*(gh-2)/100;
        int ymin=y1<y2?y1:y2, ymax=y1>y2?y1:y2;
        VL(x1,ymin,ymax-ymin+1,lc);
        /* Fill under curve */
        color32_t fc=RGB(((lc>>16)&0xFF)/4,
                         ((lc>>8)&0xFF)/4,
                         ((lc   )&0xFF)/4);
        VL(x1,y1,gy+gh-y1,fc);
    }
    char vb[8]; kuitoa(val,vb,10); kstrcat(vb,"%");
    TF(gx+4,gy+2,lc,bgc,"%s %s",lbl,vb);
}

static void draw_sysmon(de_win_t *w){
    int cx=CX(w),cy=CY(w),cw2=CW(w),ch=CH(w);
    R(cx,cy,cw2,ch,C_BASE);
    sysmon_upd(w);
    sysmon_t *s=&w->sysmon;
    uint8_t ccpu=s->cpu[(s->head+SYSMON_HISTORY-1)%SYSMON_HISTORY];
    uint8_t cmem=s->mem[(s->head+SYSMON_HISTORY-1)%SYSMON_HISTORY];
    int gh=(ch-50)/2; if(gh<30)gh=30;
    draw_graph(cx+4,cy+4,cw2-8,gh,
               s->cpu,s->head,C_BLUE,C_CRUST,"CPU",ccpu);
    draw_graph(cx+4,cy+gh+14,cw2-8,gh,
               s->mem,s->head,C_GREEN,C_CRUST,"RAM",cmem);
    int ty=cy+gh*2+22;
    uint32_t up=sched_uptime_ticks()/100;
    TF(cx+8,ty,C_SUBTEXT,C_BASE,
       "Uptime %02u:%02u:%02u  Heap free %u B",
       up/3600,(up/60)%60,up%60,heap_free_bytes()); ty+=14;
    TF(cx+8,ty,C_SUBTEXT,C_BASE,
       "Disk %d  Net %s",
       disk_count,net.initialized?"UP":"--");
}

/* ─── Editor / Viewer ────────────────────────────────────── */
static void ed_load(de_win_t *w, const char *path){
    kstrncpy(w->ed_path,path,127);
    int fd=vfs_open(path,O_RDONLY);
    if(fd<0){kstrcpy(w->ed_buf,"(not found)");w->ed_len=11;return;}
    w->ed_len=vfs_read(fd,(uint8_t*)w->ed_buf,sizeof(w->ed_buf)-1);
    vfs_close(fd);
    if(w->ed_len<0)w->ed_len=0;
    w->ed_buf[w->ed_len]=0;
}

static void draw_editor(de_win_t *w){
    int cx=CX(w),cy=CY(w),cw2=CW(w),ch=CH(w);
    R(cx,cy,cw2,ch,RGB(0x14,0x14,0x20));
    R(cx,cy,cw2,18,C_MANTLE);
    TF(cx+4,cy+1,C_LAVENDER,C_MANTLE," %s",w->ed_path);
    HL(cx,cy+18,cw2,C_SURFACE0);
    const char *p=w->ed_buf;
    int skip=w->ed_scroll, lnum=1;
    while(*p&&skip>0){while(*p&&*p!='\n')p++;if(*p=='\n')p++;skip--;lnum++;}
    int row=0, mr=(ch-22)/16; if(mr<1)mr=1;
    file_fmt_t fmt=fmt_detect((uint8_t*)w->ed_buf,(uint32_t)w->ed_len,w->ed_path);
    while(*p&&row<mr){
        char line[82]; int li=0;
        while(*p&&*p!='\n'&&li<80) line[li++]=*p++;
        line[li]=0; if(*p=='\n') p++;
        int ly=cy+20+row*16;
        char lnb[6]; kitoa(lnum,lnb,10);
        int lnl=(int)kstrlen(lnb);
        for(int qi=0;qi<4-lnl;qi++) T(cx+2+qi*8,ly,"0",C_SURFACE2,RGB(0x14,0x14,0x20));
        T(cx+2+(4-lnl)*8,ly,lnb,C_SURFACE2,RGB(0x14,0x14,0x20));
        VL(cx+36,ly,16,C_SURFACE1);
        color32_t lc=C_TEXT;
        if(fmt==FMT_INI){
            if(line[0]=='[') lc=C_YELLOW;
            else if(line[0]=='#') lc=C_OVERLAY0;
        } else if(fmt==FMT_C_SOURCE||fmt==FMT_SHELL){
            if(line[0]=='#'||kstrncmp(line,"//",2)==0) lc=C_OVERLAY0;
        }
        T(cx+40,ly,line,lc,RGB(0x14,0x14,0x20));
        row++; lnum++;
    }
    /* Scrollbar */
    int tot_lines=0; const char *pp=w->ed_buf;
    while(*pp){if(*pp=='\n')tot_lines++;pp++;} tot_lines++;
    if(tot_lines>mr){
        int sbh=ch-22; int th=sbh*mr/tot_lines; if(th<6)th=6;
        int ty=cy+20+(sbh-th)*w->ed_scroll/tot_lines;
        R(cx+cw2-5,cy+20,5,sbh,C_SURFACE0);
        R(cx+cw2-4,ty,3,th,C_SURFACE2);
    }
    HL(cx,cy+ch-16,cw2,C_SURFACE0);
    R(cx,cy+ch-15,cw2,15,C_MANTLE);
    TF(cx+4,cy+ch-14,C_SUBTEXT,C_MANTLE,
       "%s  line %d  PgUp/Dn/arrows",fmt_name(fmt),w->ed_scroll+1);
}

static void ed_key(de_win_t *w, int k){
    if(k==KEY_PGUP){w->ed_scroll-=6;if(w->ed_scroll<0)w->ed_scroll=0;}
    if(k==KEY_PGDN){w->ed_scroll+=6;}
    if(k==KEY_UP&&w->ed_scroll>0) w->ed_scroll--;
    if(k==KEY_DOWN) w->ed_scroll++;
    if(k==KEY_HOME) w->ed_scroll=0;
}

/* ─── Settings ───────────────────────────────────────────── */
static void draw_settings(de_win_t *w){
    int cx=CX(w),cy=CY(w),cw2=CW(w),ch=CH(w);
    R(cx,cy,cw2,ch,C_BASE);
    const char *tabs[]={"Themes","System","About"};
    int ntabs=3, tw=cw2/ntabs;
    for(int i=0;i<ntabs;i++){
        color32_t tb=(i==w->cfg_tab)?C_SURFACE1:C_MANTLE;
        color32_t tf=(i==w->cfg_tab)?C_TEXT:C_SUBTEXT;
        R(cx+i*tw,cy,tw,22,tb);
        HL(cx+i*tw,cy+22,tw,C_SURFACE1);
        int tl=(int)kstrlen(tabs[i])*8;
        T(cx+i*tw+(tw-tl)/2,cy+3,tabs[i],tf,tb);
    }
    HL(cx,cy+22,cw2,C_SURFACE0);
    int sy=cy+32;
    if(w->cfg_tab==0){
        const char *tnames[]={"0-caramel","1-matrix","2-ocean","3-nord","4-retro","5-dracula","6-solarize","7-gruvbox"};
        static const color32_t tc[]={
            RGB(0xFF,0xC0,0x30),RGB(0x00,0xFF,0x00),RGB(0x00,0xC0,0xFF),
            RGB(0xA0,0xC0,0xD0),RGB(0xFF,0xA0,0x00),RGB(0xFF,0x79,0xC6),
            RGB(0x00,0xCC,0xCC),RGB(0xD7,0x99,0x21)
        };
        T(cx+8,sy,"Темы (нажми 0-7):",C_LAVENDER,C_BASE); sy+=20;
        for(int i=0;i<8;i++){
            int tx=cx+8+(i%4)*100, ty=sy+(i/4)*46;
            RR(tx,ty,90,36,C_SURFACE0);
            R(tx+4,ty+4,82,18,tc[i]);
            T(tx+8,ty+24,tnames[i],C_TEXT,C_SURFACE0);
        }
        sy+=100; T(cx+8,sy,"Press 0-7 to change theme",C_SUBTEXT,C_BASE);
    } else if(w->cfg_tab==1){
        sdk_cpuid_t cpu; sdk_cpuid(&cpu);
        T(cx+8,sy,"System Info:",C_LAVENDER,C_BASE); sy+=20;
        TF(cx+8,sy,C_TEXT,C_BASE,"OS      CaramelUK v10.0 Lollipop"); sy+=16;
        TF(cx+8,sy,C_SUBTEXT,C_BASE,"CPU     %s",cpu.brand[0]?cpu.brand:cpu.vendor); sy+=16;
        TF(cx+8,sy,C_TEXT,C_BASE,"RAM     %u KB free",heap_free_bytes()/1024); sy+=16;
        TF(cx+8,sy,C_TEXT,C_BASE,"VBE     %ux%u x32bpp",vbe.width,vbe.height); sy+=16;
        TF(cx+8,sy,C_TEXT,C_BASE,"Disk    %d  Net %s",disk_count,net.initialized?"UP":"--"); sy+=16;
        uint32_t up=sched_uptime_ticks()/100;
        TF(cx+8,sy,C_TEXT,C_BASE,"Uptime  %uh %um %us",up/3600,(up/60)%60,up%60);
    } else {
        T(cx+8,sy,"CaramelUK v10.0  Lollipop",C_LAVENDER,C_BASE); sy+=24;
        T(cx+8,sy,"x86-32 OS from scratch — C + ASM",C_TEXT,C_BASE); sy+=18;
        const char *h[]={"v1 VGA shell","v2 IDT/PIT/themes","v3 VBE/VFS/net",
            "v4 ATA/CaramelFS","v5 Scrollback/DE","v6 SDK/8themes",
            "v7 Snake/Tetris","v8 Cyrillic/FAT32","v9 RU/AI/ping",
            "v10 Full GUI DE (this!)",NULL};
        for(int i=0;h[i]&&sy<cy+ch-16;i++){
            T(cx+16,sy,h[i],i==9?C_YELLOW:C_SUBTEXT,C_BASE); sy+=14;
        }
    }
    (void)ch;
}
static void settings_key(de_win_t *w, int k){
    if(k>='0'&&k<='7'&&w->cfg_tab==0){
        terminal_set_scheme((scheme_id_t)(k-'0'));
        char tb[4]={k,0}; sysconf_set("console","theme",tb);
        const char *tn[]={"caramel","matrix","ocean","nord",
                          "retro","dracula","solarized","gruvbox"};
        char msg[32]; kstrcpy(msg,"Theme: "); kstrcat(msg,tn[k-'0']);
        de_notify(msg,C_YELLOW);
    }
    if(k==KEY_LEFT||k=='h'){w->cfg_tab--;if(w->cfg_tab<0)w->cfg_tab=2;}
    if(k==KEY_RIGHT||k=='l'){w->cfg_tab=(w->cfg_tab+1)%3;}
}

/* ─── About ──────────────────────────────────────────────── */
static void draw_about(de_win_t *w){
    int cx=CX(w),cy=CY(w),cw2=CW(w),ch=CH(w);
    R(cx,cy,cw2,ch,C_BASE);
    int ay=cy+16;
    T(cx+8,ay,"  CaramelUK v10.0  Lollipop",C_LAVENDER,C_BASE); ay+=20;
    T(cx+8,ay,"  CaramelDE — Полноценный GUI",C_SAPPHIRE,C_BASE); ay+=20;
    HL(cx,ay,cw2,C_SURFACE1); ay+=8;
    T(cx+8,ay,"x86-32 OS: C + ASM без libc",C_TEXT,C_BASE); ay+=16;
    T(cx+8,ay,"Запуск через GRUB Multiboot",C_SUBTEXT,C_BASE); ay+=20;
    T(cx+8,ay,"CaramelDE v10 возможности:",C_LAVENDER,C_BASE); ay+=16;
    const char *fl[]={
        "Taskbar: часы, раскладка, окна",
        "Рабочий стол с 6 иконками",
        "Терминал: история, Tab, UTF-8",
        "Файловый менеджер: 2 панели",
        "Редактор с подсветкой синтаксиса",
        "Системный монитор: графики CPU/RAM",
        "Настройки: 8 тем, инфо о системе",
        "Alt+Tab, перемещение окон, уведомления",
        NULL
    };
    for(int i=0;fl[i]&&ay<cy+ch-20;i++){
        T(cx+16,ay,fl[i],C_TEXT,C_BASE); ay+=14;
    }
    (void)cw2;
}

/* ─── Launcher ───────────────────────────────────────────── */
static const struct{const char *name,*desc;app_id_t app;color32_t ic;}
LA[6]={
    {"Terminal","caramelsh командная строка",APP_TERMINAL,C_SKY    },
    {"Files",   "Файловый менеджер",         APP_FILES,   C_YELLOW },
    {"Editor",  "Редактор / просмотрщик",    APP_EDITOR,  C_GREEN  },
    {"Monitor", "Системный монитор",         APP_SYSMON,  C_MAUVE  },
    {"Settings","Настройки DE",              APP_SETTINGS,C_PEACH  },
    {"About",   "О CaramelUK",               APP_ABOUT,   C_LAVENDER},
};
#define NLA 6

static void draw_launcher(void){
    int lw=400, lh=NLA*50+56;
    int lx=(DE_SCR_W-lw)/2, ly=(DE_SCR_H-lh)/2;
    /* Dim background */
    for(int py=DE_TASKBAR_H;py<DE_SCR_H-DE_TASKBAR_H;py+=2)
        for(int px=0;px<DE_SCR_W;px+=2) vbe_putpixel(px,py,RGB(0,0,0));
    RR(lx,ly,lw,lh,C_MANTLE);
    BOX(lx,ly,lw,lh,C_BLUE);
    T(lx+12,ly+10,"  Launcher",C_LAVENDER,C_MANTLE);
    T(lx+lw-90,ly+10,"Esc=закрыть",C_SUBTEXT,C_MANTLE);
    HL(lx,ly+28,lw,C_SURFACE0);
    for(int i=0;i<NLA;i++){
        int iy=ly+32+i*50;
        int sel=(i==DE.launcher_sel);
        color32_t bg=sel?C_SURFACE0:C_MANTLE;
        color32_t fg=sel?C_TEXT:C_SUBTEXT;
        R(lx+4,iy,lw-8,46,bg);
        if(sel){HL(lx+4,iy,lw-8,C_BLUE);VL(lx+4,iy,46,C_BLUE);}
        R(lx+10,iy+5,34,34,LA[i].ic);
        char sym[2]={LA[i].name[0],0};
        T(lx+20,iy+13,sym,C_CRUST,LA[i].ic);
        T(lx+54,iy+6,LA[i].name,sel?C_LAVENDER:fg,bg);
        T(lx+54,iy+24,LA[i].desc,C_SUBTEXT,bg);
    }
    T(lx+12,ly+lh-16,"Enter=открыть  1-6=быстрый  стрелки=навигация",C_SUBTEXT,C_MANTLE);
}

/* ─── Alt+Tab ────────────────────────────────────────────── */
static void draw_alttab(void){
    if(!DE.alttab_open||DE.win_count==0) return;
    int n=DE.win_count, bw=96, bh=64, gap=6;
    int total=n*(bw+gap)-gap;
    int sx=(DE_SCR_W-total)/2, sy=(DE_SCR_H-bh)/2-16;
    R(sx-14,sy-14,total+28,bh+44,C_CRUST);
    BOX(sx-14,sy-14,total+28,bh+44,C_SURFACE0);
    T(sx,sy-10,"Alt+Tab — Switch Window",C_SUBTEXT,C_CRUST);
    static const color32_t ac[]={0,C_SKY,C_YELLOW,C_GREEN,C_MAUVE,C_PEACH,C_LAVENDER,C_PINK};
    for(int i=0;i<n;i++){
        de_win_t *w=&DE.wins[i];
        int ox=sx+i*(bw+gap);
        int sel=(i==DE.alttab_sel);
        color32_t bg=sel?C_SURFACE2:C_SURFACE0;
        RR(ox,sy,bw,bh,bg);
        if(sel) BOX(ox,sy,bw,bh,C_BLUE);
        color32_t acolor=(w->app<8)?ac[w->app]:C_SURFACE1;
        R(ox+4,sy+4,bw-8,bh-22,acolor);
        char ttl2[10]; kstrncpy(ttl2,w->title,8); ttl2[8]=0;
        T(ox+4,sy+bh-16,ttl2,sel?C_TEXT:C_SUBTEXT,bg);
    }
}

/* ─── open_app ───────────────────────────────────────────── */
int de_open_app(app_id_t app, const char *path){
    if(DE.win_count>=DE_MAX_WIN) return -1;
    de_win_t *w=&DE.wins[DE.win_count];
    kmemset(w,0,sizeof(de_win_t));
    w->id=next_id++; w->app=app;
    int n2=DE.win_count;
    w->w=560; w->h=380;
    w->x=60+n2*22; w->y=DE_TASKBAR_H+28+n2*18;
    if(w->x+w->w>DE_SCR_W) w->x=60;
    if(w->y+w->h>DE_SCR_H-DE_TASKBAR_H) w->y=DE_TASKBAR_H+28;
    w->px=w->x; w->py=w->y; w->pw=w->w; w->ph=w->h;
    switch(app){
    case APP_TERMINAL:
        kstrcpy(w->title,"Terminal");
        term_addl(w,"CaramelUK v10.0 caramelsh",C_GREEN,0);
        term_addl(w,"Type 'help'. 'exit' closes DE.",C_SUBTEXT,0);
        w->thist_idx=0; break;
    case APP_FILES:
        kstrcpy(w->title,"Files");
        kstrcpy(w->fm_path,(path&&path[0])?path:"/");
        fm_load(w); fm_preview(w); break;
    case APP_EDITOR:
        kstrcpy(w->title,"Editor");
        if(path&&path[0]){kstrcpy(w->title,path);ed_load(w,path);}
        break;
    case APP_VIEWER:
        kstrcpy(w->title,(path&&path[0])?path:"Viewer");
        if(path&&path[0]) ed_load(w,path);
        break;
    case APP_SYSMON:
        kstrcpy(w->title,"System Monitor");
        w->sysmon.last_tick=pit_get_ticks(); break;
    case APP_SETTINGS:
        kstrcpy(w->title,"Settings");
        w->cfg_tab=0; break;
    case APP_ABOUT:
        kstrcpy(w->title,"About");
        w->w=440; w->h=340; break;
    default:
        kstrcpy(w->title,"Window"); break;
    }
    DE.active=DE.win_count;
    DE.win_count++;
    de_notify(w->title,C_BLUE);
    return w->id;
}

static void win_close(int idx){
    if(idx<0||idx>=DE.win_count) return;
    for(int i=idx;i<DE.win_count-1;i++) DE.wins[i]=DE.wins[i+1];
    DE.win_count--;
    if(DE.active>=DE.win_count) DE.active=DE.win_count-1;
}

static void win_max(de_win_t *w){
    if(w->maximized){
        w->x=w->px;w->y=w->py;w->w=w->pw;w->h=w->ph;w->maximized=0;
    } else {
        w->px=w->x;w->py=w->y;w->pw=w->w;w->ph=w->h;
        w->x=0;w->y=DE_TASKBAR_H;w->w=DE_SCR_W;w->h=DE_SCR_H-DE_TASKBAR_H;
        w->maximized=1;
    }
}

static void draw_win_content(de_win_t *w){
    int cx=CX(w),cy=CY(w),cw2=CW(w),ch=CH(w);
    R(cx,cy,cw2,ch,C_BASE);
    switch(w->app){
    case APP_TERMINAL: draw_terminal(w); break;
    case APP_FILES:    draw_files(w);    break;
    case APP_EDITOR:
    case APP_VIEWER:   draw_editor(w);   break;
    case APP_SYSMON:   draw_sysmon(w);   break;
    case APP_SETTINGS: draw_settings(w); break;
    case APP_ABOUT:    draw_about(w);    break;
    default:
        T(cx+8,cy+8,"(empty)",C_SUBTEXT,C_BASE); break;
    }
}

static void full_redraw(void){
    draw_desktop();
    for(int i=0;i<DE.win_count;i++){
        de_win_t *w=&DE.wins[i];
        if(w->minimized) continue;
        draw_chrome(w,i==DE.active);
        draw_win_content(w);
    }
    if(DE.alttab_open) draw_alttab();
    if(DE.launcher_open) draw_launcher();
    draw_notifs();
    draw_taskbar();
}

/* ─── Main loop ──────────────────────────────────────────── */
void de_init(void){
    kmemset(&DE,0,sizeof(de_state_t));
    DE.active=-1; DE.running=1;
    DE.last_clock=pit_get_ticks();
    vbe_clear(C_BASE);
}

void de_run(void){
    de_init();
    full_redraw();
    de_open_app(APP_TERMINAL,NULL);
    full_redraw();
    uint32_t last_ref=0;
    while(DE.running){
        clock_update();
        uint32_t now=pit_get_ticks();
        if(now-last_ref>=10){
            last_ref=now;
            for(int i=0;i<DE.win_count;i++)
                if(DE.wins[i].app==APP_SYSMON) sysmon_upd(&DE.wins[i]);
            draw_taskbar(); draw_notifs();
        }
        int k=keyboard_poll(); if(!k){__asm__ volatile("pause");continue;}
        int alt2=keyboard_alt(), ctrl2=keyboard_ctrl();
        /* Exit */
        if(ctrl2&&alt2&&(k=='\b'||k==8)){DE.running=0;return;}
        if(alt2&&k==KEY_F1){DE.running=0;return;}
        /* F2 launcher */
        if(k==KEY_F2){
            DE.launcher_open=!DE.launcher_open;
            DE.launcher_sel=0; full_redraw(); continue;
        }
        /* Alt+Tab */
        if(alt2&&k==KEY_TAB){
            if(!DE.alttab_open){DE.alttab_open=1;DE.alttab_sel=DE.active<0?0:DE.active;}
            if(DE.win_count>0) DE.alttab_sel=(DE.alttab_sel+1)%DE.win_count;
            full_redraw(); continue;
        }
        if(DE.alttab_open&&!alt2){
            DE.active=DE.alttab_sel; DE.alttab_open=0; full_redraw(); continue;
        }
        /* Alt combos */
        if(alt2){
            if(k=='\n'||k=='\r'){de_open_app(APP_TERMINAL,NULL);full_redraw();continue;}
            if(k=='f'||k=='F'){de_open_app(APP_FILES,"/");full_redraw();continue;}
            if(k=='m'||k=='M'){de_open_app(APP_SYSMON,NULL);full_redraw();continue;}
            if(k=='e'||k=='E'){de_open_app(APP_EDITOR,NULL);full_redraw();continue;}
            if(k=='s'||k=='S'){de_open_app(APP_SETTINGS,NULL);full_redraw();continue;}
            if(k==KEY_F4&&DE.win_count>0){win_close(DE.active);full_redraw();continue;}
            if(k==KEY_F5&&DE.active>=0&&DE.active<DE.win_count){
                win_max(&DE.wins[DE.active]); full_redraw(); continue;
            }
            /* Move window */
            if(DE.active>=0&&DE.active<DE.win_count&&!DE.wins[DE.active].maximized){
                de_win_t *aw=&DE.wins[DE.active];
                if(k==KEY_LEFT){aw->x-=16;if(aw->x<0)aw->x=0;full_redraw();continue;}
                if(k==KEY_RIGHT){aw->x+=16;if(aw->x+aw->w>DE_SCR_W)aw->x=DE_SCR_W-aw->w;full_redraw();continue;}
                if(k==KEY_UP){aw->y-=16;if(aw->y<DE_TASKBAR_H)aw->y=DE_TASKBAR_H;full_redraw();continue;}
                if(k==KEY_DOWN){aw->y+=16;if(aw->y+aw->h>DE_SCR_H)aw->y=DE_SCR_H-aw->h;full_redraw();continue;}
            }
        }
        /* Launcher input */
        if(DE.launcher_open){
            if(k==KEY_ESC){DE.launcher_open=0;full_redraw();continue;}
            if(k==KEY_UP&&DE.launcher_sel>0){DE.launcher_sel--;draw_launcher();continue;}
            if(k==KEY_DOWN&&DE.launcher_sel<NLA-1){DE.launcher_sel++;draw_launcher();continue;}
            if(k>='1'&&k<='6') DE.launcher_sel=k-'1';
            if(k=='\n'||k=='\r'||(k>='1'&&k<='6')){
                DE.launcher_open=0;
                de_open_app(LA[DE.launcher_sel].app,NULL);
                full_redraw(); continue;
            }
            continue;
        }
        /* Desktop icon navigation */
        if(DE.active<0||DE.win_count==0){
            if(k==KEY_TAB||k==KEY_RIGHT){
                icon_sel=(icon_sel+1)%NICONS;
                draw_desktop(); draw_taskbar(); continue;
            }
            if(k==KEY_LEFT){
                icon_sel=(icon_sel-1+NICONS)%NICONS;
                draw_desktop(); draw_taskbar(); continue;
            }
            if((k=='\n'||k=='\r')&&icon_sel>=0){
                de_open_app(ICONS[icon_sel].app,NULL);
                full_redraw(); continue;
            }
        }
        /* Ctrl+Tab cycle */
        if(ctrl2&&k==KEY_TAB&&DE.win_count>0){
            DE.active=(DE.active+1)%DE.win_count;
            full_redraw(); continue;
        }
        /* Ctrl+number */
        if(ctrl2&&k>='1'&&k<='9'){
            int idx=k-'1';
            if(idx<DE.win_count){DE.active=idx;full_redraw();continue;}
        }
        /* Pass to active window */
        if(DE.active>=0&&DE.active<DE.win_count){
            de_win_t *w=&DE.wins[DE.active];
            switch(w->app){
            case APP_TERMINAL: term_key(w,k); break;
            case APP_FILES:    fm_key(w,k);   break;
            case APP_EDITOR:
            case APP_VIEWER:   ed_key(w,k);   break;
            case APP_SETTINGS: settings_key(w,k); break;
            default: break;
            }
            draw_chrome(w,1);
            draw_win_content(w);
            draw_taskbar();
            draw_notifs();
        }
    }
}
