#ifndef CFS_H
#define CFS_H

/*  CaramelFS — simple flat-block filesystem for v4
 *
 *  Layout on disk (sectors):
 *    0:       Superblock
 *    1-7:     Inode table  (128 inodes × 32 bytes = 4096 bytes = 8 sectors)
 *    8-15:    Block bitmap (1 bit per block)
 *    16+:     Data blocks  (512 bytes each)
 *
 *  Max: 128 files/dirs, 512-byte blocks, 64 blocks per file max.
 *  Simple enough to fit in a kernel, real enough to persist across reboots.
 */
#include <stdint.h>
#include <stddef.h>

#define CFS_MAGIC        0xCAFE4001
#define CFS_BLOCK_SIZE   512
#define CFS_INODE_MAX    128
#define CFS_BLOCKS_MAX   512        /* data blocks total */
#define CFS_DIRECT_BLOCKS 16       /* direct block pointers per inode */
#define CFS_NAME_MAX     56

#define CFS_TYPE_FREE  0
#define CFS_TYPE_FILE  1
#define CFS_TYPE_DIR   2

/* On-disk superblock (512 bytes, sector 0) */
typedef struct __attribute__((packed)) {
    uint32_t magic;
    uint32_t version;
    uint32_t total_blocks;
    uint32_t free_blocks;
    uint32_t inode_count;
    uint32_t free_inodes;
    uint32_t data_start_lba;   /* first data block LBA */
    uint32_t bitmap_lba;       /* block bitmap LBA */
    uint32_t inode_table_lba;  /* inode table LBA */
    char     label[32];
    uint8_t  _pad[512 - 9*4 - 32];
} cfs_super_t;

/* On-disk inode (32 bytes each, 16 per sector) */
typedef struct __attribute__((packed)) {
    char     name[CFS_NAME_MAX];     /* 56 bytes */
    uint8_t  type;                   /* CFS_TYPE_* */
    uint8_t  perms;
    uint32_t size;                   /* bytes */
    int32_t  parent;                 /* parent inode index, -1=root */
    uint32_t blocks[CFS_DIRECT_BLOCKS]; /* data block indices (0=unused) */
    uint32_t _pad;
} cfs_inode_t;

/* In-memory state */
typedef struct {
    int           disk_drive;   /* which disk_drives[] index */
    cfs_super_t   sb;
    cfs_inode_t   inodes[CFS_INODE_MAX];
    uint8_t       bitmap[CFS_BLOCKS_MAX / 8];
    int           mounted;
} cfs_state_t;

extern cfs_state_t cfs;

/* Format disk with CFS (destroys all data) */
int cfs_format(int drive, const char *label);

/* Mount (read superblock + inode table) */
int cfs_mount(int drive);

/* Flush inode table + superblock to disk */
int cfs_sync(void);

/* Inode operations */
int  cfs_lookup(const char *path);               /* returns inode index or -1 */
int  cfs_create(const char *path, uint8_t type);
int  cfs_unlink(int inode_idx);
int  cfs_read  (int inode_idx, uint32_t offset, uint8_t *buf, uint32_t len);
int  cfs_write (int inode_idx, uint32_t offset, const uint8_t *buf, uint32_t len);
int  cfs_listdir(int dir_idx, char names[][CFS_NAME_MAX], int *count);

/* High-level path API (used by VFS layer) */
int  cfs_path_read (const char *path, uint32_t offset, uint8_t *buf, uint32_t len);
int  cfs_path_write(const char *path, uint32_t offset, const uint8_t *buf, uint32_t len);
int  cfs_path_create(const char *path);
int  cfs_path_mkdir (const char *path);
int  cfs_path_unlink(const char *path);
int  cfs_path_size  (const char *path);

#endif
